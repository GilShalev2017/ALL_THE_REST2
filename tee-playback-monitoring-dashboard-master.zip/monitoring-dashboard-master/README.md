# FD19 Monitoring Dashboard 

This repo is for TEE 19 monitoring code & terraform configuration to bring up the resources on AWS.

Following are the resources created: 
- Static website hosting on S3 bucket (contains the build from the repo code)
- AWS Cloudfront for S3 static website 
- Bucket for logging of S3 & Amazon Cloudfront 
- Route53 record creation for Amazon Cloudfront