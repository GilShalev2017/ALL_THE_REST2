import { LinkContainer } from "react-router-bootstrap";
import React, { Component, Fragment } from "react";
import "./App.css";
import Routes from "./Routes";
import { Link, withRouter } from "react-router-dom";
import { Nav, Navbar, NavItem } from "react-bootstrap";
import { Auth } from "aws-amplify";
import SideBar from './components/SideBar';

class App extends Component {
    constructor(props) {
        super(props);

        this.state = {
            isAuthenticated: false,
            isAuthenticating: true,
            hasChangedPassword: false,
            currentUser: null
        };
    }

    async componentDidMount() {
        try {
            await Auth.currentSession();
            this.userHasAuthenticated(true);
            this.userHasChangedPassword(true);
        }
        catch(e) {
            if (e !== 'No current user') {
                alert(e);
            }
        }

        this.setState({ isAuthenticating: false });
    }

    userHasAuthenticated = authenticated => {
        this.setState({ isAuthenticated: authenticated });
    }

    userHasChangedPassword = changedPassword => {
        this.setState({ hasChangedPassword: changedPassword });
    }

    setCurrentUser = user => {
        this.setState({ currentUser: user });
    }

    handleLogout = async event => {
        await Auth.signOut();

        localStorage.clear();

        this.userHasAuthenticated(false);

        this.userHasChangedPassword(true);

        this.props.history.push("/login");

    }

    render() {
        const childProps = {
            isAuthenticated: this.state.isAuthenticated,
            userHasAuthenticated: this.userHasAuthenticated,
            hasChangedPassword: this.state.hasChangedPassword,
            userHasChangedPassword: this.userHasChangedPassword,
            currentUser: this.state.currentUser,
            setCurrentUser: this.setCurrentUser,
        };

        return (
            !this.state.isAuthenticating &&
            <div className="App container">
                {this.state.isAuthenticated && this.state.hasChangedPassword
                    ? <Fragment>
                        <SideBar pageWrapId={"page-wrap"} outerContainerId={"App"} />
                    </Fragment>
                    : <Fragment></Fragment>
                }
                <Navbar fluid collapseOnSelect>
                    <Navbar.Header>
                        <Navbar.Brand>
                            <Link to="/">TEE19 Control</Link>
                        </Navbar.Brand>
                        <Navbar.Toggle />
                    </Navbar.Header>
                    <Navbar.Collapse>
                        <Nav pullRight>
                            {this.state.isAuthenticated
                                ? <Fragment>
                                    <LinkContainer to="/settings">
                                        <NavItem>Settings</NavItem>
                                    </LinkContainer>
                                    <NavItem onClick={this.handleLogout}>Logout</NavItem>
                                </Fragment>
                                : <Fragment>
                                    <LinkContainer to="/login">
                                        <NavItem>Login</NavItem>
                                    </LinkContainer>
                                </Fragment>
                            }
                        </Nav>
                    </Navbar.Collapse>
                </Navbar>
                <Routes childProps={childProps} />
            </div>
        );
    }
}

export default withRouter(App);