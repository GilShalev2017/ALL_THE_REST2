import joint from 'jointjs/index';

// It is used to hold all custom shapes
joint.shapes.customShapes = {};

joint.shapes.customShapes.BaseShape = joint.shapes.devs.Model.extend({

    defaults: joint.util.deepSupplement({

        type: 'devs.Atomic',
        size: { width: 80, height: 80 },
        attrs: {
            '.body': { fill: 'salmon' },
            '.label': { text: 'Atomic' },
            '.inPorts .port-body': { fill: 'PaleGreen' },
            '.outPorts .port-body': { fill: 'Tomato' }
        }

    }, joint.shapes.devs.Model.prototype.defaults)

});


joint.shapes.devs.Link = joint.dia.Link.extend({

    defaults: {
        type: 'devs.Link',
        attrs: { '.connection' : { 'stroke-width' :  2 }}
    }
});

joint.shapes.devs.ModelView = joint.dia.ElementView.extend(joint.shapes.basic.PortsViewInterface);
joint.shapes.devs.BaseShapeView = joint.shapes.devs.ModelView;


// Node with a half-circle gauge
joint.shapes.standard.Rectangle.define('custom.node.gauge', {
    attrs: {
        body: {
            refWidth: '100%',
            refHeight: '100%',
            strokeWidth: 2,
            stroke: '#F39C12',
            fill: '#FFFFFF',
            rx: 5,
            ry: 5
        },
        label: {
            textVerticalAnchor: 'middle',
            textAnchor: 'middle',
            refX: '50%',
            refY: '50%',
            fontSize: 18,
            fontWeight: 'bold',
            fill: 'black'
        },
        gaugelabel: {
            textVerticalAnchor: 'bottom',
            textAnchor: 'middle',
            refX: '50%',
            refY: '-20',
            fontSize: 14,
            fontWeight: 'bold',
            fill: 'black'
        },
        innergauge: {
            refCx: '50%',
            cy: '-20',
            r: '54',
            fill: 'none',
            stroke: '#999999',
            strokeWidth: 20,
            clipPath: "url(#cut-off-bottom)"
        },
        gauge: {
            refCx: '50%',
            cy: '-20',
            r: '54',
            fill: 'none',
            stroke: 'green',
            strokeWidth: 20,
            strokeDasharray: "339.292",
            strokeDashoffset: "0",
            clipPath: "url(#cut-off-bottom)"
        }
    }
}, {
    markup: [{
        tagName: 'rect',
        selector: 'body',
    }, {
        tagName: 'text',
        selector: 'label'
    }, {
        tagName: 'circle',
        selector: 'innergauge'
    }, {
        tagName: 'circle',
        selector: 'gauge'
    }, {
        tagName: 'text',
        selector: 'gaugelabel'
    }]
});

joint.shapes.custom.node.gauge.prototype.setValue = function(v) {
    var c = 339.292/2;
    this.attr("gauge/strokeDashoffset", c* (100-v) / 100);
    this.attr("gaugelabel/text", v +"ms");
    console.log("Setting node to", v);
};

// Node with a histogram
joint.shapes.standard.Rectangle.define('custom.node.histogram', {
    attrs: {
        body: {
            refWidth: '100%',
            refHeight: '100%',
            strokeWidth: 2,
            stroke: 'darkgrey',
//            fill: 'lightgrey',
            fill: '#FFFFFF',
            rx: 6,
            ry: 6
        },
        body2: {
            refWidth: '100%',
            refHeight: '40%',
            refY: '60%',
            strokeWidth: 2,
            stroke: 'darkgrey',
            // fill: '#F39C12',
//            fill: '#FFFFFF',
            fill: 'lightgrey',
            rx: 6,
            ry: 6
        },
        label: {
            textVerticalAnchor: 'middle',
            textAnchor: 'middle',
            refX: '50%',
            refY: '35%',
            fontSize: 20,
            fontWeight: 'bold',
            fill: 'black'
        },
        instances: {
            textVerticalAnchor: 'middle',
            textAnchor: 'middle',
            refX: '50%',
            refY: '82%',
            fontSize: 20,
            fontWeight: 'bold',
            fill: 'black'
        },
        active_in: {
            textVerticalAnchor: 'middle',
            textAnchor: 'start',
            refX: '5%',
            refY: '82%',
            fontSize: 20,
            fontWeight: 'bold',
            fill: 'black'
        },
        active_out: {
            textVerticalAnchor: 'middle',
            textAnchor: 'end',
            refX: '95%',
            refY: '82%',
            fontSize: 20,
            fontWeight: 'bold',
            fill: 'black'
        },
        fps: {
            textVerticalAnchor: 'middle',
            textAnchor: 'end',
            refX: '95%',
            refY: '82%',
            fontSize: 12,
            fontWeight: 'bold',
            fill: 'white'
        },
        metric: {
            textVerticalAnchor: 'bottom',
            textAnchor: 'middle',
            refX: '50%',
            refY: '-15',
            fontSize: 24,
            fontWeight: 'bold',
            fill: 'black'
        }
    }
}, {
    markup: [{
        tagName: 'rect',
        selector: 'body',
    }, {
        tagName: 'rect',
        selector: 'body2',
    }, {
        tagName: 'text',
        selector: 'label'
    }, {
        tagName: 'text',
        selector: 'instances'
    }, {
        tagName: 'text',
        selector: 'active_in'
    }, {
        tagName: 'text',
        selector: 'active_out'
    }, {
        tagName: 'text',
        selector: 'fps'
    }, {
        tagName: 'text',
        selector: 'metric'
    }]
});

joint.shapes.custom.node.histogram.prototype.setValue = function(v) {
    this.attr("metric/text", v +"ms");
};

joint.shapes.custom.node.histogram.prototype.setStatus = function(a, b) {
    var s = "";
    if (!a & !b) s = "-/-";
    else {
      if (a) s += a; else s += "0";
      s += "/";
      if (b) s += b; else s += "-";
    }

    var c;
    if (b === 0) c = "lightgrey"; // Unused
    else if (a === b) c = "#40ff40"; // Ok
    else c = "red"; // Not good

    this.attr("metric/text", s);
    this.attr("body2/fill", c);
};

joint.shapes.custom.node.histogram.prototype.setInstances = function(v) {
    this.attr("instances/text", "#" + v);
};

joint.shapes.custom.node.histogram.prototype.setFps = function(v) {
    this.attr("fps/text", v +"fps");
};

joint.shapes.custom.node.histogram.prototype.setActiveInOut = function(max, v_in, v_out) {
    var c = "#40ff40"; // Ok
    if ((v_in < max) || (v_out < max))
        c = "red";
    var s = max ? max+"/"+max : "-/-";

    this.attr("active_in/text", "→ "+v_in);
    this.attr("active_out/text", v_out+" →");
    this.attr("body2/fill", c);
    this.attr("metric/text", s);
};

joint.shapes.custom.node.histogram.prototype.setActiveOut = function(max, v_out) {
    var c = "#40ff40"; // Ok
    if (v_out < max)
        c = "red";

    this.attr("active_out/text", v_out+" →");
    this.attr("body2/fill", c);
};

joint.shapes.custom.node.histogram.prototype.setHighlight = function(highlight) {
    this.attr("body/fill", highlight ? "#CECEFE" : "#FFFFFF");
};
