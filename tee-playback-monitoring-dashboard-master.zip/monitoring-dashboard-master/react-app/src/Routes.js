import React from "react";
import {Route, Switch} from "react-router-dom";
import Home from "./containers/Home";
import NotFound from "./containers/NotFound";
import Login from "./containers/Login";
import NewDeployment from "./containers/NewDeployment";
import Dashboard from "./containers/Dashboard";
import GameStatus from "./containers/GameStatus";
import UpdateDeployment from "./containers/UpdateDeployment";
import DeploymentOverview from "./containers/DeploymentOverview";
import ResetPassword from "./containers/ResetPassword";
import Settings from "./containers/Settings";
import ChangePassword from "./containers/ChangePassword";
import AppliedRoute from "./components/AppliedRoute";
import AuthenticatedRoute from "./components/AuthenticatedRoute";
import UnauthenticatedRoute from "./components/UnauthenticatedRoute";
import CameraConfiguration from "./containers/CameraConfiguration";
import CameraConfigurationVCam from "./containers/CameraConfigurationVCam";
import CameraConfigurationPCam from "./containers/CameraConfigurationPCam";
import Games from "./containers/Games";
import NewDeploymentForSelectedGame from "./containers/NewDeploymentForSelectedGame";
import LifeCycleOrchestration from "./containers/LifeCycleOrchestration";
import GamesManagement from "./containers/GamesManagement";
import NewDeploymentForSelectedGameVCAMConfig from "./containers/NewDeploymentForSelectedGameVCAMConfig";
import NewDeploymentForSelectedGameConfirm from "./containers/NewDeploymentForSelectedGameConfirm";
import DeploymentDashboard from "./containers/DeploymentDashboard";
import SystemLevelDashboard from "./containers/SystemLevelDashboard";
import ComponentLevelDashboard from "./containers/ComponentLevelDashboard";
import BackupData from "./containers/BackupData";
import Playback from "./containers/Playback";

export default ({childProps}) =>
    <Switch>
        <AppliedRoute path="/" exact component={GamesManagement} props={childProps}/>
        <AppliedRoute path="/deployments" exact component={Home} props={childProps}/>
        <AppliedRoute path="/login" exact component={Login} props={childProps}/>
        <AppliedRoute path="/deployments/new" exact component={NewDeployment} props={childProps}/>
        <AppliedRoute path="/deployments/:id" exact component={DeploymentOverview} props={childProps}/>
        <AppliedRoute path="/dashboard" exact component={Dashboard} props={childProps}/>
        <AppliedRoute path="/deployments/new/update" exact component={UpdateDeployment} props={childProps}/>
        <AppliedRoute path="/deployments/:id/cameraConfig" exact component={CameraConfiguration} props={childProps}/>
        <AppliedRoute path="/deployments/:id/cameraConfig/VCam" exact component={CameraConfigurationVCam}
                      props={childProps}/>
        <AppliedRoute path="/deployments/:id/cameraConfig/PCam" exact component={CameraConfigurationPCam}
                      props={childProps}/>
        <AppliedRoute path="/games" exact component={GamesManagement} props={childProps}/>
        <AppliedRoute path="/games/:id/scheduleDeployment" exact component={NewDeploymentForSelectedGame}
                      props={childProps}/>
        <AppliedRoute path="/games/:id/planGame/deploymentBasics" exact component={NewDeploymentForSelectedGame}
                      props={childProps}/>
        <AppliedRoute path="/games/:id/gameStatus" exact component={GameStatus} props={childProps}/>
        <AppliedRoute path="/lifecycle" exact component={LifeCycleOrchestration} props={childProps}/>
        <AppliedRoute path="/games/:id/planGame/preDeploymentConfig" exact
                      component={NewDeploymentForSelectedGameVCAMConfig} props={childProps}/>
        <AppliedRoute path="/games/:id/planGame/confirm" exact component={NewDeploymentForSelectedGameConfirm}
                      props={childProps}/>
        <AppliedRoute path="/deployments/:id/dashboard" exact component={DeploymentDashboard} props={childProps}/>
        <AppliedRoute path="/deployments/:id/status" exact component={GameStatus} props={childProps}/>
        <AppliedRoute path="/deployments/:id/systemLevelDashboard" exact component={SystemLevelDashboard}
                      props={childProps}/>
        <AppliedRoute path="/deployments/:id/componentLevelDashboard/:component" exact component={ComponentLevelDashboard}
                      props={childProps}/>
        <AppliedRoute path="/deployments/:id/backupData" exact component={BackupData} props={childProps}/>
        <AppliedRoute path="/deployments/:id/playback" exact component={Playback} props={childProps}/>
        <UnauthenticatedRoute
            path="/login/reset"
            exact
            component={ResetPassword}
            props={childProps}
        />
        <AuthenticatedRoute
            path="/settings"
            exact
            component={Settings}
            props={childProps}
        />
        <AuthenticatedRoute
            path="/settings/password"
            exact
            component={ChangePassword}
            props={childProps}
        />
        { /* Finally, catch all unmatched routes */ }
        <Route component={NotFound}/>
    </Switch>;