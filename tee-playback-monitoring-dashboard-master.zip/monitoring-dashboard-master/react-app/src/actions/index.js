export function addComponent(text) {
    return {
        type : "ADD_COMPONENT",
        nodeName : text
    }
}