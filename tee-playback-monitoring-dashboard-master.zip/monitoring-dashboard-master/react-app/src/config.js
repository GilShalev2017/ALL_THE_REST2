export default {
    s3: {
        REGION: "YOUR_S3_UPLOADS_BUCKET_REGION",
        BUCKET: "YOUR_S3_UPLOADS_BUCKET_NAME"
    },
    apiGateway: {
        REGION: "us-east-1",
        URL: "https://dev.deployment.fd19.sports.intel.com/fd19",
        URL_TEST: "https://7uax2ihlo3.execute-api.us-east-1.amazonaws.com/fd19",
        URL_TEMP: "https://yx0fqdbve3.execute-api.us-west-2.amazonaws.com/anand/v1",
        URL_SYSTEM: "https://0eafafgiia.execute-api.us-east-1.amazonaws.com/dev",
        URL_SERVICE: "https://7uax2ihlo3.execute-api.us-east-1.amazonaws.com/fd19/k8s",
        URL_BACKUP: "https://t1dol5f09e.execute-api.us-east-1.amazonaws.com/dev",
        API_KEY: "o01fByGEag6VHqBsPowgB9cJALYe5otj8IbfLVh1"
    },
    cognito: {
        REGION: "us-east-1",
        USER_POOL_ID: "us-east-1_YuSwcvMEa",
        APP_CLIENT_ID: "1ejfov5307vl90egmqu768kb5h",
        IDENTITY_POOL_ID: "us-east-1:27167b77-110a-4f2a-a533-1e0d40a055a4"
    }
};