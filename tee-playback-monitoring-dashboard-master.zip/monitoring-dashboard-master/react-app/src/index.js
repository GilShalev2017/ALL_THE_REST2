import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import { BrowserRouter as Router } from "react-router-dom";
import Amplify from "aws-amplify";
import config from "./config";
import { Provider } from 'react-redux';
import './assets/jointjs.css';
import configureStore from './store/configureStore';

const store = configureStore();

Amplify.configure({
    Auth: {
        mandatorySignIn: true,
        region: config.cognito.REGION,
        userPoolId: config.cognito.USER_POOL_ID,
        identityPoolId: config.cognito.IDENTITY_POOL_ID,
        userPoolWebClientId: config.cognito.APP_CLIENT_ID
    },
    Storage: {
        region: config.s3.REGION,
        bucket: config.s3.BUCKET,
        identityPoolId: config.cognito.IDENTITY_POOL_ID
    },
    API: {
        endpoints: [
            {
                name: "fd19",
                endpoint: config.apiGateway.URL,
                region: config.apiGateway.REGION
            },
            {
                name: "temp",
                endpoint: config.apiGateway.URL_TEMP,
                region: config.apiGateway.REGION
            },
            {
                name: "system",
                endpoint: config.apiGateway.URL_SYSTEM,
                region: config.apiGateway.REGION
            },
            {
                name: "service",
                endpoint: config.apiGateway.URL_SERVICE,
                region: config.apiGateway.REGION
            },
            {
                name: "backup",
                endpoint: config.apiGateway.URL_BACKUP,
                region: config.apiGateway.REGION,
                apiKey: config.apiGateway.API_KEY
            }
        ]
    }
});

ReactDOM.render(
    <Provider store={store}>
        <Router>
            <App />
        </Router>
    </Provider>,
    document.getElementById("root")
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();
