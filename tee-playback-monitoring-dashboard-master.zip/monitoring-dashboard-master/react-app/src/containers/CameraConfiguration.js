import React, {Component} from "react";
import {API} from "aws-amplify";
import {PageHeader} from "react-bootstrap";
import LoaderButton from "../components/LoaderButton";
import "./CameraConfiguration.css";
import {ListGroup, ListGroupItem} from "react-bootstrap";

export default class CameraConfiguration extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');

        this.state = {
            isLoading: true,
            deployment: props.location.state.data,
            userId: currentUserId,
            streams: null,
            vCamStreams: null,
            pCamStreams: null
        };
    }

    async componentDidMount() {
        try {
            const streams = await this.streams();

            console.log("streams: " + JSON.stringify(streams));

            this.setState({
                streams
            });
            var vCamStreams = [];
            var pCamStreams = [];
            var mediaStreams = streams.mediaStreams;
            for (var i = 0; i < mediaStreams.length; ++i) {
                var stream = mediaStreams[i];
                var key = Object.keys(stream)[0];
                if (key === "vcam") {
                    vCamStreams.push(stream);
                } else if (key === "pcam") {
                    pCamStreams.push(stream);
                }
            }
            this.setState({streams});
            this.setState({vCamStreams});
            this.setState({pCamStreams});
        } catch (e) {
            alert(e.message);
        }

        this.setState({isLoading: false});
    }

    streams() {
        return API.get("fd19", `/games/${this.state.deployment.game_id}/streams`);
    }

    validateForm() {
        return true;
    }

    handleSubmit = async event => {
        event.preventDefault();

        this.setState({isLoading: true});
    }

    addVCamConfig = async event => {
        event.preventDefault();
        this.props.history.push({
            pathname: "/deployments/" + this.state.deployment_id + "/cameraConfig/VCam",
            state: {
                data: this.state.deployment
            }
        });
    }

    addPCamConfig = async event => {
        event.preventDefault();
        this.props.history.push({
            pathname: "/deployments/" + this.state.deployment_id + "/cameraConfig/PCam",
            state: {
                data: this.state.deployment
            }
        });
    }

    saveAll = async event => {
        event.preventDefault();

        console.log("Call POST /streams here");
    }

    renderVirtualCameraConfig() {
        return (
            <div className="config">
                <ListGroup>
                    {this.state.streams && this.renderVirtualCameraList(this.state.vCamStreams)}
                </ListGroup>
                <button className="addConfigButton" onClick={this.addVCamConfig}>+ Add VCam Configuration</button>
            </div>
        );
    }

    renderVirtualCameraList(cameraList) {
        return [{}].concat(cameraList).map(
            (item, i) =>
                i !== 0
                    ? <ListGroupItem key={i}
                                     className={"historyItem"}
                                     header={item.vcam.experience.cameraScriptName}>
                        <span className="cameraDetail">Description: {item.vcam.experience.description ? this.getDescription(item.vcam.experience.description): item.vcam.experience.cameraScriptName}</span>
                        {item.vcam.experience.description && this.renderVCamParamDetails(item, item.vcam.experience.description)}
                        <span className="cameraDetail">Resolution: {item.vcam.stream.output.resolution.width + "x" + item.vcam.stream.output.resolution.height}</span>
                        <span className="cameraDetail">Bitrate: {item.vcam.stream.output.bitRate + "Mbps"}</span>
                    </ListGroupItem>
                    : ""
        );
    }

    getDescription(str) {
        var myStr;
        myStr = str.substring(0, str.indexOf('('));
        console.log("Description: " + myStr);
        return myStr;
    }

    getParameters(description) {
        var regExp = /\{([^}]+)\}/g;
        var matches = description.match(regExp);
        var paramList = [];
        for (var i = 0; i < matches.length; i++) {
            var match = matches[i];
            var temp = match.substring(1, match.length - 1);
            paramList.push(temp);
        }
        return paramList;
    }

    renderVCamParamDetails(camera, description) {
        var paramList = this.getParameters(description);
        console.log("Param list: " + paramList);
        return this.createCameraDetails(camera, paramList);
    }


    createCameraDetails = (camera, paramList) => {
        let detailList = [];
        for (let i = 0; i < paramList.length; i++) {
            detailList.push(<span className="cameraDetail" key={"detail" + i}>{paramList[i]}: {camera.vcam.experience[paramList[i]]}</span>);
        }
        return detailList;
    }

    renderPhysicalCameraConfig() {
        return (
            <div className="config">
                <ListGroup>
                    {this.state.streams && this.renderPhysicalCameraList(this.state.pCamStreams)}
                </ListGroup>
                <button className="addConfigButton" onClick={this.addVCamConfig}>+ Add PCam Configuration</button>
            </div>
        );
    }

    renderPhysicalCameraList(cameraList) {
        return [{}].concat(cameraList).map(
            (item, i) =>
                i !== 0
                    ? <ListGroupItem key={i}
                                     header={"Camera ID: " + item.pcam.camera_id}>
                    </ListGroupItem>
                    : ""
        );
    }

    renderLander() {
        return (
            <div className="lander">
                <h1>TEE19 Control</h1>
            </div>
        );
    }

    renderCameraConfig() {
        return (
            <div className="configuration">
                <h2 className="configLabel">Virtual Camera Streams</h2>

                {!this.state.isLoading && this.renderVirtualCameraConfig()}

                <h2 className="configLabel">Physical Camera Streams</h2>

                {!this.state.isLoading && this.renderPhysicalCameraConfig()}

                <div className="buttonGroup">
                    <LoaderButton
                        className="saveButton"
                        block
                        bsStyle="primary"
                        bsSize="large"
                        onClick={this.saveAll}
                        text="Save"
                    />
                </div>
            </div>
        );
    }

    renderCameraConfigPage() {
        return (
            <div>
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Stream Configuration</PageHeader>
                {!this.state.isLoading && this.renderCameraConfig(this.state.deployment)}
            </div>
        );
    }

    render() {
        return (
            <div className="CameraConfiguration">
                {this.props.isAuthenticated ? this.renderCameraConfigPage() : this.renderLander()}
            </div>
        );
    }
}