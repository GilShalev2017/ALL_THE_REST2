import React, { Component } from "react";
import { API } from "aws-amplify";
import "./Deployment.css";

export default class Deployment extends Component {
    constructor(props) {
        super(props);

        this.state = {
            isLoading: true,
            deployment: null
        };
    }

    async componentDidMount() {
        try {
            const deployment = await this.deployment();

            this.setState({
                deployment
            });
        } catch (e) {
            alert(e.message);
        }

        this.setState({ isLoading: false });
    }

    deployment() {
        return API.get("fd19", `/deployments/${this.props.match.params.id}`);
    }

    validateForm() {
        return this.deployment != null;
    }

    renderDeployment(deployment) {
        return this.props.history.push({
            pathname: '/deployments/new/update',
            state: {
                data: this.state.deployment,
                message: "",
            }
        });
    }

    renderLander() {
        return (
            <div className="lander">
                <h1>TEE19 Control</h1>
            </div>
        );
    }

    render() {
        return (
            <div className="deployment">
                {!this.state.isLoading && this.renderDeployment(this.state.deployment)}
            </div>
        );
    }
}