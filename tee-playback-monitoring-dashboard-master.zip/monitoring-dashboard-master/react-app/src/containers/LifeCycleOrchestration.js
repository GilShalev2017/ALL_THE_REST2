import React, { Component } from "react";
import { PageHeader } from "react-bootstrap";
import "./LifeCycleOrchestration.css";
import life_cycle_orchestration from "../assets/life_cycle_orchestration.png"

const styles = {
    image: {
        width: '100%',
        height: '100%'
    }
};


export default class LifeCycleOrchestration extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');

        this.state = {
            isLoading: null,
            userId: currentUserId,
            deployment: props.location.state.data,
        };

        console.log("deployment:  " + JSON.stringify(this.state.deployment));
    }

    renderLander() {
        return (
            <div className="lander">
                <h1>TEE19 Control</h1>
            </div>
        );
    }

    renderPage() {
        return (
            <div>
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Life Cycle Orchestration</PageHeader>
                {!this.state.isLoading ? this.renderLifeCycleOrchestration() : ""}
            </div>
        );
    }

    renderLifeCycleOrchestration() {
        return (
            <div className="lifeCycle">
                <img src={life_cycle_orchestration} style={styles.image}/>
            </div>
        );
    }

    render() {
        return (
            <div className="LifeCycleOrchestration">
                {this.props.isAuthenticated ? this.renderPage() : this.renderLander()}
            </div>
        );
    }
}