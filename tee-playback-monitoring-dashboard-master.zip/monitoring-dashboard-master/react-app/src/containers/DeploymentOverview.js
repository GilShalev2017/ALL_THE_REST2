import React, {Component} from "react";
import {API} from "aws-amplify";
import {PageHeader} from "react-bootstrap";
import LoaderButton from "../components/LoaderButton";
import "./DeploymentOverview.css";
import Modal from 'react-modal';
import {ListGroup, ListGroupItem} from "react-bootstrap";

const customStyles = {
    content: {
        top: '45%',
        left: '55%',
        right: 'auto',
        bottom: 'auto',
        transform: 'translate(-50%, -50%)',
        width: '50%',
        height: '75%'
    }
};

Modal.setAppElement('#root');

export default class Deployments extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');
        const zone = new Date().toLocaleTimeString('en-us', {timeZoneName: 'short'}).split(' ')[2];

        this.state = {
            isLoading: true,
            isUpdating: null,
            isDeleting: null,
            isCanceling: null,
            deployment: null,
            userId: currentUserId,
            jsonModalIsOpen: false,
            historyModalIsOpen: false,
            eksModalIsOpen: false,
            isDownloading: null,
            timeZone: zone
        };

        this.openJSONModal = this.openJSONModal.bind(this);
        this.afterOpenJSONModal = this.afterOpenJSONModal.bind(this);
        this.closeJSONModal = this.closeJSONModal.bind(this);
        this.openHistoryModal = this.openHistoryModal.bind(this);
        this.afterOpenHistoryModal = this.afterOpenHistoryModal.bind(this);
        this.closeHistoryModal = this.closeHistoryModal.bind(this);
        this.openEksModal = this.openEksModal.bind(this);
        this.afterOpenEksModal = this.afterOpenEksModal.bind(this);
        this.closeEksModal = this.closeEksModal.bind(this);
    }

    openJSONModal() {
        this.setState({jsonModalIsOpen: true});
    }

    afterOpenJSONModal() {
        this.subtitle.style.color = '#595959';
    }

    closeJSONModal() {
        this.setState({jsonModalIsOpen: false});
    }

    openHistoryModal() {
        this.setState({historyModalIsOpen: true});
    }

    afterOpenHistoryModal() {
        this.subtitle.style.color = '#595959';
    }

    closeHistoryModal() {
        this.setState({historyModalIsOpen: false});
    }

    openEksModal() {
        this.setState({eksModalIsOpen: true});
    }

    afterOpenEksModal() {
        this.subtitle.style.color = '#595959';
    }

    closeEksModal() {
        this.setState({eksModalIsOpen: false});
    }

    async loadLifeCycleOrchestration(deployment, event) {
        try {
            this.props.history.push({
                pathname: "/deployments/" + deployment.deployment_id + "/status",
                state: {
                    deploymentId: deployment.deployment_id,
                    data: deployment,
                    status: "current"
                }
            });
        } catch (e) {
            alert(e);
        }
    }

    downloadJSON = event => {
        var objectData = this.state.deployment;
        let filename = "deployment_" + objectData.deployment_id + ".json";
        let contentType = "application/json;charset=utf-8;";
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            var blob = new Blob([decodeURIComponent(encodeURI(JSON.stringify(objectData, null, 4)))], {type: contentType});
            navigator.msSaveOrOpenBlob(blob, filename);
        } else {
            var a = document.createElement('a');
            a.download = filename;
            a.href = 'data:' + contentType + ',' + encodeURIComponent(JSON.stringify(objectData, null, 4));
            a.target = '_blank';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        }
    }

    async componentDidMount() {
        try {
            const deployment = await this.deployment();

            this.setState({
                deployment
            });
        } catch (e) {
            alert(e.message);
        }

        this.setState({isLoading: false});
    }

    deployment() {
        return API.get("fd19", `/deployments/${this.props.match.params.id}`);
    }

    validateForm() {
        return this.deployment != null;
    }

    handleChange = event => {
        this.setState({
            [event.target.id]: event.target.value
        });
    }

    handleSubmit = async event => {
        event.preventDefault();

        this.setState({isLoading: true});
    }

    handleDelete = async event => {
        event.preventDefault();

        const confirmed = window.confirm(
            "Are you sure you want to delete the deployment for " + this.state.deployment.deployment_id + "?"
        );

        if (!confirmed) {
            return;
        }

        this.setState({isDeleting: true});

        try {
            var deploymentId = this.state.deployment.deployment_id;
            const response = await this.deleteDeployment(deploymentId);
            console.log(response);
            this.props.history.push("/deployments");
        } catch (e) {
            console.log(e.message);
            this.setState({isDeleting: false});
        }
    }

    handleUpdate = async event => {
        event.preventDefault();
        this.setState({isUpdating: true});
        this.props.history.push({
            pathname: '/deployments/new/update',
            state: {
                data: this.state.deployment,
                isCreating: false,
                message: ""
            }
        });
    }

    deleteDeployment(deploymentId) {
        return API.del("fd19", "/deployments/" + deploymentId).then(response => {
            console.log("API response: " + JSON.stringify(response));
        }).catch(error => {
            alert(error.response.data.message);
        });
    }

    generateListFromObject(data) {
        var items = [];
        for (var key in data) {
            var item = data[key];
            item["key"] = key;
            items.push(item);
        }
        return items;
    }

    renderDashboardLink(link) {
        return (
            <div className="row">
                <p className="infoKey">UI Metrics :</p>
                <p className="infoValue"><a href={link} target="_blank" rel="noopener noreferrer">Monitoring Dashboard</a>
                </p>
            </div>
        );
    }

    renderFlinkUI(link) {
        return (
            <div className="row">
                <p className="infoKey">Flink UI :</p>
                <p className="infoValue"><a href={link} target="_blank" rel="noopener noreferrer">Flink Dashboard</a>
                </p>
            </div>
        );
    }

    renderLoggingDashboard(link) {
        return (
            <div className="row">
                <p className="infoKey">UI Logs :</p>
                <p className="infoValue"><a href={link} target="_blank" rel="noopener noreferrer">Logging Dashboard</a>
                </p>
            </div>
        );
    }

    renderComputeClusters(data) {
        var items = this.generateListFromObject(data);
        return [{}].concat(items).map(
            (item, i) =>
                i !== 0
                    ? <div key={item.key}>
                        <div className="infoItem">{item.key}</div>
                        <div className="row">
                            <p className="infoKey">Type :</p>
                            <p className="infoValue">{item.type}</p>
                        </div>
                        <div className="row">
                            <p className="infoKey">Cluster Size :</p>
                            <p className="infoValue">{item.cluster_size}</p>
                        </div>
                        <div className="row">
                            <p className="infoKey">Server Type :</p>
                            <p className="infoValue">{item.server_type}</p>
                        </div>
                        {(item.kibana_ui_metrics && item.kibana_ui_metrics !== "##MISSING##") && this.renderDashboardLink(item.kibana_ui_metrics)}
                        {(item.flink_ui && item.flink_ui !== "##MISSING##") && this.renderFlinkUI(item.flink_ui)}
                        {(item.kibana_ui_logs && item.kibana_ui_logs !== "##MISSING##") && this.renderLoggingDashboard(item.kibana_ui_logs)}
                    </div> : ''
        );
    }

    renderSharedStorage(data) {
        var items = this.generateListFromObject(data);
        return [{}].concat(items).map(
            (item, i) =>
                i !== 0
                    ? <div key={item.key}>
                        <div className="infoItem">{item.key}</div>
                        <div className="row">
                            <p className="infoKey">Cluster Size :</p>
                            <p className="infoValue">{item.cluster_size}</p>
                        </div>
                        <div className="row">
                            <p className="infoKey">Mount Point :</p>
                            <p className="infoValue">{item.mount_point}</p>
                        </div>
                        <div className="row">
                            <p className="infoKey">Server Type :</p>
                            <p className="infoValue">{item.server_type}</p>
                        </div>
                    </div> : ''
        );
    }

    renderCostSection(deployment) {
        return (
            <div className="overviewBlockCost">
                <div className="overviewRow">
                    <p>Estimated Cost : {"$" + deployment.estimated_cost.total_cost_per_hour + "/hr x " + deployment.estimated_cost.total_active_hours + " active hours = $" + deployment.estimated_cost.total_estimated_cost}</p>
                    <button
                        className={"noThanksButton " + ((deployment.deployment_status !== "requested") ? 'hidden' : 'true')}
                        onClick={this.handleDelete}>Oops, no thanks
                    </button>
                </div>
                <p className="overviewCostInfo">Estimated cost is based on the number and type of cloud server
                    instances required for the deployment and based of AWS listed prices, it does not include data
                    traffic or long term storage charges.</p>
            </div>
        );
    }

    renderDeployment(deployment) {
        return (
            <div className="overview">
                <div className="column">
                    <div className="overviewBlockOne">
                        <div className="overviewRow">
                            <p>ID : </p>
                            <p className="overviewValueID">{deployment.deployment_id}</p>
                        </div>
                        <div className="overviewRow">
                            <p>Region : </p>
                            <p className="overviewValue">{deployment.region}</p>
                        </div>
                        <div className="overviewRow">
                            <p>Active By :</p>
                            <p className="overviewValue">{new Date(deployment.active_by).toLocaleString()}</p>
                            <p className="overviewTimeZoneLabel">{this.state.timeZone}</p>
                        </div>
                        <div className="overviewRow">
                            <p>Active Till :</p>
                            <p className="overviewValue">{new Date(deployment.active_till).toLocaleString()}</p>
                            <p className="overviewTimeZoneLabel">{this.state.timeZone}</p>
                        </div>
                        <div className="overviewRow">
                            <p>Last Modified :</p>
                            <p className="overviewValue">{new Date(deployment.last_modified).toLocaleString()}</p>
                            <p className="overviewTimeZoneLabel">{this.state.timeZone}</p>
                        </div>
                    </div>
                </div>
                <div className="column">
                    <div className="overviewBlockTwo">
                        <div className="overviewRow">
                            <p>Status :</p>
                            <p className="overviewValue">{deployment.deployment_status}</p>
                            <div>
                                <button className="historyButton" onClick={this.openHistoryModal}>History</button>
                                <Modal
                                    isOpen={this.state.historyModalIsOpen}
                                    onAfterOpen={this.afterOpenHistoryModal}
                                    onRequestClose={this.closeHistoryModal}
                                    style={customStyles}
                                    contentLabel="Modal">
                                    <h2 ref={subtitle => this.subtitle = subtitle}>Deployment History</h2>
                                    <LoaderButton
                                        className="closeButton"
                                        block
                                        bsStyle="link"
                                        bsSize="large"
                                        onClick={this.closeHistoryModal}
                                        text="Close"
                                        loadingText="Canceling…"
                                    />
                                    <div className="historyContent">
                                        <ListGroup>
                                            {(this.state.historyModalIsOpen && this.state.deployment.deployment_history) && this.renderDeploymentHistory(this.state.deployment.deployment_history)}
                                        </ListGroup>
                                    </div>
                                </Modal>
                            </div>
                        </div>
                        <div className="overviewRow">
                            <p>Requested By :</p>
                            <p className="overviewValue">{deployment.requested_by && deployment.requested_by}</p>
                        </div>
                        <div className="overviewRow">
                            <p>Stadium Cameras :</p>
                            <p className="overviewValue">{deployment.stadium_cameras && 'Max cameras supported: ' + deployment.stadium_cameras.max_cameras}</p>
                        </div>
                        <div className="overviewRow">
                            <p>Virtual Cameras :</p>
                            <p className="overviewValue">{deployment.virtual_cameras && 'Max cameras supported: ' + deployment.virtual_cameras.max_cameras}</p>
                        </div>
                        <div className="overviewRow">
                            <p>CVT :</p>
                            <p className="overviewValue">{deployment.cvt && 'Max cameras supported: ' + deployment.cvt.max_cameras}</p>
                        </div>
                    </div>
                </div><br/>
                {deployment.estimated_cost && this.renderCostSection(deployment)}
                <div className="column">
                    <div className="computeClustersBlock">
                        <div className="overviewRow">
                            <p className="overViewKey">Compute Clusters</p>
                            <div>
                                <button
                                    className={"eksButton " + ((deployment.deployment_status !== "deployed") && (deployment.deployment_status !== "active") ? 'hidden' : 'true')}
                                    onClick={this.openEksModal}>Kubernetes Access
                                </button>
                                <Modal
                                    isOpen={this.state.eksModalIsOpen}
                                    onAfterOpen={this.afterOpenEksModal}
                                    onRequestClose={this.closeEksModal}
                                    style={customStyles}
                                    contentLabel="Modal">
                                    <h2 ref={subtitle => this.subtitle = subtitle}>Kubernetes Access</h2>
                                    <LoaderButton
                                        className="closeButton"
                                        block
                                        bsStyle="link"
                                        bsSize="large"
                                        onClick={this.closeEksModal}
                                        text="Close"
                                        loadingText="Canceling…"
                                    />
                                    <div className="eksContent">
                                        {(this.state.eksModalIsOpen && this.state.deployment.eks) && this.renderEksAccess(this.state.deployment)}
                                    </div>
                                </Modal>
                            </div>
                        </div>
                        <div>
                            {this.renderComputeClusters(deployment.compute_clusters)}
                        </div>
                    </div>
                </div>
                <div className="column">
                    <div className="sharedStorageBlock">
                        <p className="overViewKey">Shared Storage</p>
                        <div>
                            {this.renderSharedStorage(deployment.shared_storage)}
                        </div>
                    </div>
                </div>
                <br/><br/>
                <div className="buttonGroup">
                    <LoaderButton
                        className={"saveButton " + ((deployment.deployment_status !== "requested"
                        && deployment.deployment_status !== "confirmed") ? 'buttonDisabled' : '')}
                        block
                        bsStyle="primary"
                        bsSize="large"
                        isLoading={this.state.isUpdating}
                        onClick={this.handleUpdate}
                        text="Edit"
                    />
                    <LoaderButton
                        className={"deleteButton " + ((deployment.deployment_status === "pending"
                        || deployment.deployment_status === "deployed" || deployment.deployment_status === "active"
                        || deployment.deployment_status === "terminating") ? 'buttonDisabled' : '')}
                        block
                        bsStyle="danger"
                        bsSize="large"
                        isLoading={this.state.isDeleting}
                        onClick={this.handleDelete}
                        text="Delete"
                        loadingText="Deleting…"
                    />
                </div>
            </div>
        );
    }

    renderLander() {
        return (
            <div className="lander">
                <h1>TEE19 Control</h1>
            </div>
        );
    }

    renderPage() {
        return (
            <div>
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Deployment Overview</PageHeader>
                <div className="deployment">
                    <button className="button" onClick={this.openJSONModal}>View JSON</button>
                    <Modal
                        isOpen={this.state.jsonModalIsOpen}
                        onAfterOpen={this.afterOpenJSONModal}
                        onRequestClose={this.closeJSONModal}
                        style={customStyles}
                        contentLabel="Modal">
                        <h2 ref={subtitle => this.subtitle = subtitle}>JSON Content</h2>
                        <button className="button" onClick={this.downloadJSON}>Download</button>
                        <LoaderButton
                            className="closeButton"
                            block
                            bsStyle="link"
                            bsSize="large"
                            onClick={this.closeJSONModal}
                            text="Close"
                            loadingText="Canceling…"
                        />
                        <div>
                            <pre>{JSON.stringify(this.state.deployment, null, 4)}</pre>
                        </div>
                    </Modal>
                    <button className="lifeCycleButton" onClick={(e) => this.loadLifeCycleOrchestration(this.state.deployment, e)}>Life Cycle</button>
                    {!this.state.isLoading && this.renderDeployment(this.state.deployment)}
                </div>
            </div>
        );
    }

    renderDeploymentHistory(historyList) {
        var cleanList = [];
        var last = { state: "", action_list: [] };
        var tz = this.state.timeZone;
        historyList.forEach(function(item) {
            var state = item.message.split(' -> ')[1];
            if (state !== last.state) {
                last = { state: state, message: item.message, action_list: [] };
                cleanList.push(last);
            }
            last.action_list.push("Action: " + item.action + " - " + new Date(item.timestamp).toLocaleString() + "  " + tz);
        });

        function renderActions(actions) {
            return actions.map((action, index) => (
                 <span key={index}>{action}<br/></span>
            ));
        };

        return [{}].concat(cleanList).map(
            (item, i) => {
                if (i !== 0) {
                    const actions = renderActions(item.action_list);
                    return (<ListGroupItem key={i}
                                     className={"historyItem"}
                                     header={item.message}>
                        <span>{actions}</span>
                    </ListGroupItem>);
                }
                return "";
            }
        );
    }

    renderEksAccess(deployment) {
        return (
            <div className="eksAccess">
                <h4>Kubectl</h4>
                <p>The Kubernetes 'kubectl' command line tool is the recommended way for directly
                    accessing the Compute Clusters.
                    Instructions for installing kubectl can be found <a
                        href="https://gitlab.devtools.intel.com/sports/k8s/k8s-tutorial/blob/master/INSTALLATION.md"
                        target="_blank" rel="noopener noreferrer">here</a></p>
                <p>The following AWS command line will configure kubectl to access the Kubernetes for the
                    ‘{deployment.deployment_id}’ deployment:</p>
                <div className="code">
                    aws eks update-kubeconfig --name {deployment.eks.cluster_name} --region {deployment.region} \<br />
                    --role {deployment.eks.user_role_arn}
                </div>
                <h4>Troubleshooting</h4>
                <p>If your version of 'aws' is too old you may receive the error below. Follow the&nbsp;
                    <a href="https://gitlab.devtools.intel.com/sports/k8s/k8s-tutorial/blob/master/INSTALLATION.md"
                       target="_blank" rel="noopener noreferrer">instructions</a>
                    &nbsp;to install a newer version.</p>
                <div className="error">
                    aws: error: argument operation: Invalid choice, valid choices are:<br />
                    <br />
                    create-cluster | delete-cluster<br />
                    describe-cluster | list-clusters<br />
                    help<br />
                </div>
                <p>If you do not have AWS access credentials (or the wrong ones) you will get the error below:</p>
                <div className="error">
                    An error occurred (ResourceNotFoundException) when calling the DescribeCluster operation: No cluster
                    found for name: {deployment.eks.cluster_name}.
                </div>
                <h4>Examples</h4>
                <p>Here are some example kubectl commands:</p>
                <div className="code">
                    # List node<br />
                    kubectl get nodes<br />
                    <br />
                    # List pods<br />
                    kubectl get pods<br />
                    <br />
                    # Find the settings and docker image version used for the decoder-0 pod<br />
                    kubectl describe pod decoder-0<br />
                    <br />
                    # Get last 10 lines of logs from the decoder-0 pod<br />
                    kubectl logs --tail=10 decoder-0<br />
                    <br />
                    # Open a shell inside the decoder-0 container<br />
                    kubectl exec -it decoder-0 -- /bin/bash
                </div>
            </div>
        );
    }

    render() {
        return (
            <div className="Deployments">
                {this.props.isAuthenticated ? this.renderPage() : this.renderLander()}
            </div>
        );
    }
}