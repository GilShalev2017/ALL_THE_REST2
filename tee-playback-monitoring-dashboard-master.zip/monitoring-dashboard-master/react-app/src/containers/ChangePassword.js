import React, { Component } from "react";
import { Auth } from "aws-amplify";
import { FormGroup, FormControl, ControlLabel } from "react-bootstrap";
import LoaderButton from "../components/LoaderButton";
import "./ChangePassword.css";

export default class ChangePassword extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');

        this.state = {
            password: "",
            oldPassword: "",
            isChanging: false,
            confirmPassword: "",
            userId: currentUserId
        };
    }

    validateForm() {
        return (
            this.state.oldPassword.length > 0 &&
            this.state.password.length > 0 &&
            this.state.password === this.state.confirmPassword
        );
    }

    handleChange = event => {
        this.setState({
            [event.target.id]: event.target.value
        });
    };

    handleChangeClick = async event => {
        event.preventDefault();

        this.setState({ isChanging: true });

        try {
            if (this.props.hasChangedPassword) {
                const currentUser = await Auth.currentAuthenticatedUser();
                await Auth.changePassword(
                    currentUser,
                    this.state.oldPassword,
                    this.state.password
                );
                this.props.history.push("/");
            } else {
                Auth.completeNewPassword(this.props.currentUser, this.state.password, this.props.currentUser.challengeParam.requiredAttributes)
                    .then(() => {
                        this.props.history.push("/");
                        this.props.userHasChangedPassword(true)
                    }).catch(error => {
                        alert(error.message);
                        console.log("Error: " + JSON.stringify(error))
                        this.setState({ isChanging: false });
                });
            }
        } catch (e) {
            alert(e.message);
            console.log("Error: " + JSON.stringify(e))
            this.setState({ isChanging: false });
        }
    };

    render() {
        return (
            <div className="ChangePassword">
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <form onSubmit={this.handleChangeClick}>
                    {!this.props.hasChangedPassword
                        ? <div>
                            Change your password below.<br/><br/>
                        </div>
                        : <div></div>
                    }
                    <FormGroup bsSize="large" controlId="oldPassword">
                        <ControlLabel>Old Password</ControlLabel>
                        <FormControl
                            type="password"
                            onChange={this.handleChange}
                            value={this.state.oldPassword}
                        />
                    </FormGroup>
                    <hr />
                    <div>
                        New passwords must be at least 12 characters long.<br />
                        They must contain:
                        <ul>
                        <li>a lower case letter</li>
                        <li>an upper case letter</li>
                        <li>a number</li>
                        <li>a special character</li>
                        </ul>
                    </div>
                    <hr />
                     
                    <FormGroup bsSize="large" controlId="password">
                        <ControlLabel>New Password</ControlLabel>
                        <FormControl
                            type="password"
                            value={this.state.password}
                            onChange={this.handleChange}
                        />
                    </FormGroup>
                    <FormGroup bsSize="large" controlId="confirmPassword">
                        <ControlLabel>Confirm Password</ControlLabel>
                        <FormControl
                            type="password"
                            onChange={this.handleChange}
                            value={this.state.confirmPassword}
                        />
                    </FormGroup>
                    <LoaderButton
                        block
                        type="submit"
                        bsSize="large"
                        text="Change Password"
                        loadingText="Changing…"
                        disabled={!this.validateForm()}
                        isLoading={this.state.isChanging}
                    />
                </form>
            </div>
        );
    }
}