import React, {Component} from "react";
import {API} from "aws-amplify";
import {PageHeader} from "react-bootstrap";
import "./ComponentLevelDashboard.css";
import 'react-table/react-table.css';
import Menu from '../components/Menu';
import ComponentGraph from '../components/ComponentGraph';

export default class ComponentLevelDashboard extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');
        const zone = new Date().toLocaleTimeString('en-us', {timeZoneName: 'short'}).split(' ')[2];

        this.state = {
            isLoading: true,
            deployment: null,
            userId: currentUserId,
            timeZone: zone
        };
    }

    async componentDidMount() {
        try {
            const deployment = await this.deployment();

            this.setState({
                deployment
            });
        } catch (e) {
            alert(e.message);
        }

        this.setState({isLoading: false});
    }

    deployment() {
        return API.get("fd19", `/deployments/${this.props.match.params.id}`);
    }

    renderComponentLevelDashboard() {
        return (
            <div className="overview">
                <div className="col-md-2">
                    <Menu url={
                        [
                            {
                                "id": 1,
                                "componentName": "Add Item"
                            }
                        ]
                    }pollInterval={2000} />
                </div>
                <div className="ComponentGraph">
                    <ComponentGraph deployment={this.state.deployment} component={this.props.match.params.component}/>
                </div>
            </div>
        );
    }

    async loadLifeCycle(deployment, event) {
        try {
            this.props.history.push({
                pathname: "/deployments/" + deployment.deployment_id + "/status",
                state: {
                    deploymentId: deployment.deployment_id,
                    data: deployment,
                    status: "current"
                }
            });
        } catch (e) {
            alert(e);
        }
    }

    renderLander() {
        return (
            <div className="lander">
                <h1>TEE19 Control</h1>
            </div>
        );
    }

    renderPage() {
        return (
            <div>
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Component Level Dashboard</PageHeader>
                <button className="backToLifeCycleButton" onClick={(e) => this.loadLifeCycle(this.state.deployment, e)}>Life Cycle</button>
                <div className="dashboard">
                    {!this.state.isLoading && this.renderComponentLevelDashboard()}
                </div>
            </div>
        );
    }

    render() {
        return (
            <div className="ComponentLevelDashboard">
                {this.props.isAuthenticated ? this.renderPage() : this.renderLander()}
            </div>
        );
    }
}