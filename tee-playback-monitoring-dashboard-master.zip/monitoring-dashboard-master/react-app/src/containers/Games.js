import React, {Component} from "react";
import {PageHeader, ListGroup, ListGroupItem} from "react-bootstrap";
import "./Games.css";
import {API} from "aws-amplify";
import LoaderButton from "../components/LoaderButton";
import Select from 'react-select';

export default class Games extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');
        const zone = new Date().toLocaleTimeString('en-us', {timeZoneName: 'short'}).split(' ')[2];
        const leagueList = ["NFL", "NBA"];

        this.state = {
            isLoading: true,
            games: [],
            userId: currentUserId,
            isCreating: null,
            deployment: null,
            timeZone: zone,
            leagues: leagueList,
            league: "NFL",
            venues: [],
            venueLabel: "All Supported Venues",
            venueID: "default"
        };
    }

    async componentDidMount() {
        if (!this.props.isAuthenticated) {
            return;
        }
        try {
            var venueResponse = await this.venues();
            if (venueResponse) {
                var venuesList = venueResponse.venues;
                var venues = [];
                for (var i = 0; i < venuesList.length; i++) {
                    if (venuesList[i].venue_config.deployed === true ) {
                        venues.push(venuesList[i]);
                    }
                }
                this.setState({venues});
            }
            var response = await this.games();
            if (response.games) {
                var games = this.sortGamesByStartTimeAscending(response.games);
                this.setState({games});
            }
        } catch (e) {
            console.log(e);
        }

        this.setState({isLoading: false});
    }

    sortGamesByStartTimeAscending(array) {
        return array.sort(function (a, b) {
            var gameDataA = a.game_data;
            var gameDataB = b.game_data;
            var x = gameDataA.start_time;
            var y = gameDataB.start_time;
            return ((x < y) ? -1 : ((x > y) ? 1 : 0));
        });
    }

    formatDate(date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;

        return [year, month, day].join('-');
    }

    games() {
        var startDate = this.formatDate(new Date());
        var dt = new Date();
        dt.setMonth(dt.getMonth() + 12);
        var endDate = this.formatDate(dt);
        return API.get("temp", "/eventconfig/nfl/events?start_date=" + startDate + "&end_date=" + endDate + "&deployed=true");
    }

    gamesByVenue(venueID) {
        var startDate = this.formatDate(new Date());
        var dt = new Date();
        dt.setMonth(dt.getMonth() + 12);
        var endDate = this.formatDate(dt);
        var venueList = [];
        venueList.push(venueID);
        return API.get("temp", "/eventconfig/nfl/events?start_date=" + startDate + "&end_date=" + endDate + "&venue_list=" + venueList[0] + "&deployed=true");
    }

    venues() {
        return API.get("temp", "/eventconfig/nfl/venues");
    }

    async scheduleDeployment(game, event) {
        try {
            this.props.history.push({
                pathname: "/games/" + game.game_id + "/scheduleDeployment",
                state: {
                    data: game
                }
            });
        } catch (e) {
            alert(e);
        }
    }

    generateOptionsForSelect(arr) {
        var items = [];
        for (var i = 0; i < arr.length; i++) {
            var item = {label: arr[i], value: arr[i]};
            items.push(item);
        }
        return items;
    }

    generateVenuesForSelect(arr) {
        var items = [];
        var defaultSelection = {label: "All Supported Venues", value: "default"};
        items.push(defaultSelection);
        for (var i = 0; i < arr.length; i++) {
            var venueLocation = arr[i].venue_location;
            var item = {label: venueLocation.name + ", " + venueLocation.city + ", " + venueLocation.state, value: arr[i].venue_id};
            items.push(item);
        }
        return items;
    }

    handleChangeLeague = event => {
        this.setState({league: event.label});
    }

    async handleChangeVenue(event) {
        this.setState({
            venueLabel: event.label,
            venueID: event.value
        });

        try {
            var gamesResponse = null;
            var games = [];
            if (event.value === "default") {
                gamesResponse = await this.games();
            } else {
                gamesResponse = await this.gamesByVenue(event.value);
            }
            if (gamesResponse.games) {
                games = this.sortGamesByStartTimeAscending(gamesResponse.games);
            }
            this.setState({games});
        } catch (e) {
            console.log(e);
        }
    }

    renderGamesList(games) {
        return [{}].concat(games).map(
            (game, i) =>
                i !== 0
                    ? <ListGroupItem
                        className="gameItem"
                        key={game.game_data.away.name + game.game_data.home.name + i}
                        header={game.game_data.away.name + " vs " + game.game_data.home.name}>
                        <span className="gameDetailTitle">{"Start time: "}</span><span className="gameDetail">{new Date(game.game_data.start_time).toLocaleString() + "  " + this.state.timeZone}</span><br/>
                        <span className="gameDetailTitle">{"Venue location: "}</span><span className="gameDetail">{game.venue_location.name + ", " + game.venue_location.city + ", " + game.venue_location.state}</span><br/>
                        <span className="gameDetailTitle">{"League: " }</span><span className="gameDetail">{game.game_data.league}</span><br/>
                        <span className="gameDetailTitle">{"Year: " } </span><span className="gameDetail">{game.game_data.year}</span><br/>
                        <LoaderButton
                            className="scheduleDeploymentButton"
                            bsStyle="primary"
                            bsSize="small"
                            onClick={(e) => this.scheduleDeployment(game, e)}
                            text="Schedule Deployment">
                        </LoaderButton>
                    </ListGroupItem>
                    : ""
        );
    }

    renderLander() {
        return (
            <div className="lander">
                <h1>TEE19 Control</h1>
            </div>
        );
    }

    renderPage() {
        return (
            <div>
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Games</PageHeader>
                {!this.state.isLoading ? this.renderGames() : ""}
            </div>
        );
    }

    renderVenueSelection() {
        return (
            <div className="col-md-4">
                <Select options={this.generateVenuesForSelect(this.state.venues)}
                        autoFocus
                        value={{label: this.state.venueLabel, value: this.state.venueID}}
                        onChange={(e) => this.handleChangeVenue(e)}/>
            </div>
        );
    }

    renderGames() {
        return (
            <div className="events">
                <div className="dropdownRow">
                    <div className="leagueSelection">
                        <div className="col-md-4">
                            <Select options={this.generateOptionsForSelect(this.state.leagues)}
                                    autoFocus
                                    value={{label: this.state.league, value: this.state.league}}
                                    onChange={this.handleChangeLeague}
                            />
                        </div>
                    </div>
                    <div className="venueSelection">
                        {this.state.venues.length > 0 && this.renderVenueSelection()}
                    </div>
                </div>
                <div className="gameList">
                    <ListGroup>
                        {(this.state.games.length > 0) ? this.renderGamesList(this.state.games) : "There is no available game."}
                    </ListGroup>
                </div>
            </div>
        );
    }

    render() {
        return (
            <div className="Games">
                {this.props.isAuthenticated ? this.renderPage() : this.renderLander()}
            </div>
        );
    }
}