import React, {Component} from "react";
import {API} from "aws-amplify";
import {PageHeader} from "react-bootstrap";
import LoaderButton from "../components/LoaderButton";
import "./CameraConfigurationVCam.css";

export default class CameraConfigurationVCam extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');

        this.state = {
            isLoading: true,
            deployment: props.location.state.data,
            userId: currentUserId,
            templates: null
        };
    }

    async componentDidMount() {
        try {
            const templates = await this.templates();

            console.log("templates: " + JSON.stringify(templates));

            this.setState({
                templates
            });
        } catch (e) {
            alert(e.message);
        }

        this.setState({isLoading: false});
    }

    templates() {
        return API.get("fd19", `/games/${this.state.deployment.game_id}/streams/templates`);
    }

    validateForm() {
        return true;
    }

    handleSubmit = async event => {
        event.preventDefault();

        this.setState({isLoading: true});
    }

    addConfigVCam = async event => {
        event.preventDefault();
        console.log("Add VCam config");
    }

    renderCameraConfigVCamContent(deployment) {
        return (
            <div className="config">

                <LoaderButton
                    className="saveButton"
                    block
                    bsStyle="primary"
                    bsSize="large"
                    onClick={this.addConfigVCam}
                    text="Add"
                />
            </div>
        );
    }

    renderLander() {
        return (
            <div className="lander">
                <h1>TEE19 Control</h1>
            </div>
        );
    }

    renderCameraConfigVCam() {
        return (
            <div className="configuration">
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Virtual Camera Configuration</PageHeader>
                {!this.state.isLoading && this.renderCameraConfigVCamContent(this.state.deployment)}
            </div>
        );
    }

    render() {
        return (
            <div className="CameraConfigurationVCam">
                {this.props.isAuthenticated ? this.renderCameraConfigVCam() : this.renderLander()}
            </div>
        );
    }
}