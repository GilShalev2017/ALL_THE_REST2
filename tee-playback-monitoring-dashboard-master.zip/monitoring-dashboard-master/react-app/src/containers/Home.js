import React, {Component} from "react";
import {PageHeader, ListGroup, ListGroupItem} from "react-bootstrap";
import "./Home.css";
import {API} from "aws-amplify";
import {LinkContainer} from "react-router-bootstrap";
import LoaderButton from "../components/LoaderButton";
import Modal from 'react-modal';

const customStyles = {
    content: {
        top: '45%',
        left: '55%',
        right: 'auto',
        bottom: 'auto',
        transform: 'translate(-50%, -50%)',
        width: '50%',
        height: '75%'
    }
};

export default class Home extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');
        const zone = new Date().toLocaleTimeString('en-us', {timeZoneName: 'short'}).split(' ')[2];

        this.state = {
            isLoading: true,
            deployments: [],
            userId: currentUserId,
            availableDeployments: [],
            requestedDeployments: [],
            pastDeployments: [],
            isCreating: null,
            deployment: null,
            historyModalOpen: false,
            timeZone: zone
        };

        this.openModal = this.openModal.bind(this);
        this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
    }

    async componentDidMount() {
        if (!this.props.isAuthenticated) {
            return;
        }
        try {
            var deployments = await this.deployments();
            this.groupDeployments(deployments);
        } catch (e) {
            console.log(e);
        }

        this.setState({isLoading: false});
    }

    async openModal(deploymentId, event) {
        event.preventDefault();

        try {
            const deployment = await this.deployment(deploymentId);
            this.setState({
                deployment
            });
            this.setState({historyModalOpen: true});
        } catch (e) {
            alert(e.message);
        }
    }

    afterOpenModal() {
        this.subtitle.style.color = '#595959';
    }

    async closeModal(event) {
        event.preventDefault();
        this.setState({historyModalOpen: false});
    }

    groupDeployments(deploymentList) {
        var deployments = this.sortByKeyDescending(deploymentList, "active_by");
        var availableDeployments = [];
        var requestedDeployments = [];
        var pastDeployments = [];
        for (var i = 0; i < deployments.length; ++i) {
            var dep = deployments[i];
            if (dep.deployment_status === "active" || dep.deployment_status === "deployed") {
                availableDeployments.push(dep);
            } else if (dep.deployment_status === "requested" || dep.deployment_status === "confirmed" || dep.deployment_status === "pending") {
                requestedDeployments.push(dep);
            } else {
                pastDeployments.push(dep);
            }
        }
        this.setState({deployments});
        this.setState({availableDeployments});
        this.setState({requestedDeployments});
        this.setState({pastDeployments});
    }

    sortByKeyDescending(array, key) {
        return array.sort(function (a, b) {
            var x = a[key];
            var y = b[key];
            return ((x < y) ? -1 : ((x > y) ? 1 : 0));
        });
    }

    deployments() {
        return API.get("fd19", "/deployments");
    }

    deployment(deploymentId) {
        return API.get("fd19", `/deployments/${deploymentId}`);
    }

    handleView(deploymentId, event) {
        event.preventDefault();
        this.props.history.push({
            pathname: "/deployments/" + deploymentId,
        });
    }

    async handleDelete(deploymentId, event) {
        event.preventDefault();

        const confirmed = window.confirm(
            "Are you sure you want to delete the deployment for " + deploymentId + "?"
        );

        if (!confirmed) {
            return;
        }

        this.setState({isDeleting: true});

        try {
            const response = await this.deleteDeployment(deploymentId);
            console.log(response);
            var deployments = await this.deployments();
            this.groupDeployments(deployments);
        } catch (e) {
            console.log(e.message);
            this.setState({isDeleting: false});
        }
    }

    async shutdownInfra(deploymentId) {
        try {
            var activeTillValue = "now";
            await this.updateDeployment(deploymentId, {
                active_till: activeTillValue
            });
        } catch (e) {
            alert(e.message);
        }
    }

    async gotoShutdownInfra(deploymentId, event) {
        event.preventDefault();

        const confirmed = window.confirm(
            "Are you sure you want to shut down the infrastructure for " + deploymentId + "?"
        );

        if (!confirmed) {
            return;
        }

        try {
            await this.shutdownInfra(deploymentId);
        } catch (e) {
            alert(e.message);
        }
    }

    async configureCamera(deploymentId, event) {
        event.preventDefault();

        try {
            const deployment = await this.deployment(deploymentId);
            this.setState({
                deployment
            });
            this.props.history.push({
                pathname: "/deployments/" + deploymentId + "/cameraConfig",
                state: {
                    data: this.state.deployment
                }
            });
        } catch (e) {
            alert(e.message);
        }
    }

    deleteDeployment(deploymentId) {
        return API.del("fd19", "/deployments/" + deploymentId).then(response => {
            console.log("API response: " + JSON.stringify(response));
        }).catch(error => {
            alert(error.response.data.message);
        });
    }

    handleCreateDeployment = async event => {
        event.preventDefault();

        this.setState({isCreating: true});

        this.props.history.push("/deployments/new");
    }

    renderDeploymentHistory(historyList) {
        var cleanList = [];
        var last = {state: "", action_list: []};
        var tz = this.state.timeZone;
        historyList.forEach(function (item) {
            var state = item.message.split(' -> ')[1];
            if (state !== last.state) {
                last = {state: state, message: item.message, action_list: []};
                cleanList.push(last);
            }
            last.action_list.push("Action: " + item.action + " - " + new Date(item.timestamp).toLocaleString() + "  " + tz);
        });

        function renderActions(actions) {
            return actions.map((action, index) => (
                <div>{action}</div>
            ));
        };

        return [{}].concat(cleanList).map(
            (item, i) => {
                if (i !== 0) {
                    const actions = renderActions(item.action_list);
                    return (<ListGroupItem key={i}
                                           className={"historyItem"}
                                           header={item.message}>
                        <div>{actions}</div>
                    </ListGroupItem>);
                }
                return "";
            }
        );
    }

    renderActiveByActiveTillInfo(deploymentType, deployment) {
        return (
            <span>
                {deploymentType === "available" && this.renderActiveTill(deployment)}
                {deploymentType === "requested" && this.renderActiveByActiveTill(deployment)}
            </span>
        );
    }

    renderActiveByActiveTill(deployment) {
        return (
            <span>
                {"Active by: " + new Date(deployment.active_by).toLocaleString() + "  " + this.state.timeZone}<br/>
                {"Active till: " + new Date(deployment.active_till).toLocaleString() + "  " + this.state.timeZone}<br/>
            </span>
        );
    }

    renderActiveTill(deployment) {
        return (
            <span>
                {"Active till: " + new Date(deployment.active_till).toLocaleString() + "  " + this.state.timeZone}<br/>
            </span>
        );
    }

    renderDeploymentsList(deploymentType, deployments) {
        return [{}].concat(deployments).map(
            (deployment, i) =>
                i !== 0
                    ? <ListGroupItem key={i}
                            className={"deploymentlistItem " + (deployment.deployment_status === "active" ? 'deploymentlistItemActive' : '')}
                            header={deployment.deployment_id}>
                            {"Status: " + deployment.deployment_status}
                            <LoaderButton className="viewHistoryBtn"
                                          block
                                          bsStyle="link"
                                          bsSize="small"
                                          onClick={(e) => this.openModal(deployment.deployment_id, e)}
                                          text="View history">
                            </LoaderButton>
                            {this.renderActiveByActiveTillInfo(deploymentType, deployment)}
                            {deployment.requested_by && "Requested by: " + deployment.requested_by}
                            <span className="deploymentButtonGroup">
                                <LoaderButton
                                    className={"deleteDeploymentButton " + ((deployment.deployment_status === "pending"
                                    || deployment.deployment_status === "deployed" || deployment.deployment_status === "active"
                                    || deployment.deployment_status === "terminating") ? 'hidden' : 'true')}
                                    bsStyle="danger"
                                    bsSize="small"
                                    onClick={(e) => this.handleDelete(deployment.deployment_id, e)}
                                    text="Delete">
                                </LoaderButton>
                                <LoaderButton
                                    className={"terminateDeploymentButton " + ((deployment.deployment_status !== "deployed" && deployment.deployment_status !== "active") ? 'hidden' : 'true')}
                                    bsStyle="danger"
                                    bsSize="small"
                                    onClick={(e) => this.gotoShutdownInfra(deployment.deployment_id, e)}
                                    text="Terminate">
                                </LoaderButton>
                                <LoaderButton
                                    className={"configureCameraButton " + ((deployment.deployment_status !== "active") ? 'hidden' : 'true')}
                                    bsStyle="primary"
                                    bsSize="small"
                                    onClick={(e) => this.configureCamera(deployment.deployment_id, e)}
                                    text="Stream Configuration">
                                </LoaderButton>
                                <LoaderButton
                                    className="viewDeploymentButton"
                                    bsStyle="primary"
                                    bsSize="small"
                                    onClick={(e) => this.handleView(deployment.deployment_id, e)}
                                    text="View">
                                </LoaderButton>
                            </span>
                        </ListGroupItem>
                    : ""
        );
    }

    renderLander() {
        return (
            <div className="lander">
                <h1>TEE19 Control</h1>
            </div>
        );
    }

    renderDeployments() {
        return (
            <div className="deployments">
                <h4 className="deploymentGroupTitle">Available Deployments</h4>
                {(this.state.availableDeployments.length > 0) ? this.renderDeploymentsSection("available", this.state.availableDeployments) : "There is no available deployment."}
                <h4 className="deploymentGroupTitle">Requested Deployments</h4>
                {(this.state.requestedDeployments.length > 0) ? this.renderDeploymentsSection("requested", this.state.requestedDeployments) : "There is no requested deployment."}
                <div className="createButtonGroup">
                    <LoaderButton
                        className="createDeploymentButton"
                        block
                        bsStyle="primary"
                        bsSize="large"
                        type="submit"
                        isLoading={this.state.isCreating}
                        onClick={this.handleCreateDeployment}
                        text="Create New Deployment Request"
                    />
                </div>
                <h4 className="deploymentGroupTitle">Past Deployments</h4>
                {(this.state.pastDeployments.length > 0) ? this.renderDeploymentsSection("past", this.state.pastDeployments) : "There is no past deployment."}
                <Modal
                    isOpen={this.state.historyModalOpen}
                    onAfterOpen={this.afterOpenModal}
                    onRequestClose={this.closeModal}
                    style={customStyles}
                    contentLabel="Modal">
                    <h2 ref={subtitle => this.subtitle = subtitle}>Deployment History</h2>
                    <LoaderButton
                        className="closeButton"
                        block
                        bsStyle="link"
                        bsSize="large"
                        onClick={(e) => this.closeModal(e)}
                        text="Close"
                        loadingText="Canceling…"
                    />
                    <div className="historyContent">
                        <ListGroup>
                            {(this.state.historyModalOpen && this.state.deployment.deployment_history) && this.renderDeploymentHistory(this.state.deployment.deployment_history)}
                        </ListGroup>
                    </div>
                </Modal>
            </div>
        );
    }

    renderDeploymentsSection(deploymentType, deployments) {
        return (
            <div>
                <ListGroup>
                    {this.renderDeploymentsList(deploymentType, deployments)}
                </ListGroup>
            </div>
        );
    }

    renderPage() {
        return (
            <div>
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Deployments</PageHeader>
                {!this.state.isLoading ? this.renderDeployments() : ""}
            </div>
        );
    }

    render() {
        return (
            <div className="Home">
                {this.props.isAuthenticated ? this.renderPage() : this.renderLander()}
            </div>
        );
    }
}