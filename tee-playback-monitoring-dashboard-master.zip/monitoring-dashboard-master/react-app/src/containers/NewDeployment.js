import React, {Component} from "react";
import {FormGroup, FormControl, ControlLabel, PageHeader} from "react-bootstrap";
import LoaderButton from "../components/LoaderButton";
import "./NewDeployment.css";
import { API, Auth } from "aws-amplify";
import DateTimePicker from 'react-datetime-picker';

export default class NewDeployment extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');
        const zone = new Date().toLocaleTimeString('en-us',{timeZoneName:'short'}).split(' ')[2];

        var dt = new Date();
        var activeByDate = this.setActiveByDate(dt);
        var curr = new Date();
        var activeTillDate = this.setActiveTillDate(curr, zone);
        var eventId = "";

        this.state = {
            isLoading: null,
            deploymentId: currentUserId,
            userId: currentUserId,
            activeBy: activeByDate,
            activeTill: activeTillDate,
            stadiumCamerasMax: 1,
            virtualCamerasMax: 1,
            data: {},
            userEmail: {},
            timeZone: zone,
            gameId: eventId
        };
    }

    async componentDidMount() {
        const userInfo = await Auth.currentUserInfo();
        const userEmail = userInfo.attributes.email;
        this.setState({ userEmail })
    }

    setActiveByDate(dt) {
        var hour = dt.getHours() + 2;
        var minute = dt.getMinutes() + 30;
        var roundedMinute = (Math.round(minute/30) * 30) % 60;
        var roundedHour = minute > 45 ? (hour === 23 ? 0 : ++hour) : hour;
        dt.setHours(roundedHour);
        dt.setMinutes(roundedMinute);
        return dt;
    }

    setActiveTillDate(curr, zone) {
        var lastDayOfWeek;
        var first = curr.getDate() - curr.getDay();
        if (zone === "PST") {
            lastDayOfWeek = first + 5;      // For Pacific visitors, set to Friday of current week
        } else {                            // if (zone === "GMT+2")
            lastDayOfWeek = first + 4;      // For Israel visitors, set to Thursday of current week
        }
        var dt = new Date(curr.setDate(lastDayOfWeek));
        dt.setHours(17, 0, 0);
        return dt;
    }

    setValidDefaultActiveByDate(dt) {
        dt.setHours(dt.getHours() + 2);
        return dt;
    }

    validateForm() {
        return this.state.deploymentId.length > 0;
    }

    handleChange = event => {
        this.setState({
            [event.target.id]: event.target.value
        });
    }

    handleActiveByDateChange = event => {
        this.setState({activeBy: event});
    }

    handleActiveTillDateChange = event => {
        this.setState({activeTill: event});
    }

    handleSubmit = async event => {
        event.preventDefault();

        this.setState({isLoading: true});

        var oneHour = 59 * 60 * 1000;
        var validActiveByDate = this.setValidDefaultActiveByDate(new Date());

        if (this.state.activeBy < validActiveByDate) {
            alert("Active By value needs to be at least 2 hours from the current time.");
            this.setState({isLoading: false});
        } else if ((this.state.activeTill - this.state.activeBy) < oneHour) {
            alert("Active Till value needs to be at least 1 hour later than Active By value.");
            this.setState({isLoading: false});
        } else {
            try {
                var game_ids = [];
                if (this.state.gameId !== "") {
                    game_ids.push(this.state.gameId);
                }
                await this.createDeployment({
                    deployment_id: this.state.deploymentId,
                    active_by: this.state.activeBy,
                    active_till: this.state.activeTill,
                    stadium_cameras: {max_cameras: parseInt(this.state.stadiumCamerasMax)},
                    virtual_cameras: {max_cameras: parseInt(this.state.virtualCamerasMax)},
                    requested_by: this.state.userEmail,
                    allowed_game_ids: game_ids
                });

                this.props.history.push({
                    pathname: '/deployments/new/update',
                    state: {
                        data: this.state.data,
                        isCreating: true,
                        message: "A deployment request was created. You can make further changes by using the form below."
                    }
                });

            } catch (e) {
                alert(e.message);
                this.setState({isLoading: false});
            }
        }
    }

    createDeployment(deployment) {
        return API.post("fd19", "/deployments", {
            body: deployment
        }).then(response => this.setState({
            isLoading: false,
            data: response
        })).catch(error => {
            console.log(error.response)
        });
    }

    render() {
        return (
            <div className="NewDeployment">
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>New Deployment</PageHeader>
                <form onSubmit={this.handleSubmit}>
                    <FormGroup controlId="deploymentId" bsSize="large">
                        <div className="createRow">
                            <p className="createItemLabel">
                                <ControlLabel>Deployment ID :</ControlLabel>
                            </p>
                            <p className="createItemValue">
                                <FormControl
                                    autoFocus
                                    type="text"
                                    value={this.state.deploymentId}
                                    onChange={this.handleChange}
                                />
                            </p>
                        </div>
                    </FormGroup>
                    <FormGroup controlId="activeBy" bsSize="large">
                        <div className="createRow">
                            <p className="createItemLabel">
                                <ControlLabel>Active By :</ControlLabel>
                            </p>
                            <div className="createItemValueDate">
                                <DateTimePicker
                                    clearIcon={null}
                                    disableClock={true}
                                    onChange={this.handleActiveByDateChange}
                                    value={new Date(this.state.activeBy)}
                                />
                            </div>
                            <p className="timeZoneLabel">{this.state.timeZone}</p>
                        </div>
                    </FormGroup>
                    <FormGroup controlId="activeTill" bsSize="large">
                        <div className="createRow">
                            <p className="createItemLabel">
                                <ControlLabel>Active Till :</ControlLabel>
                            </p>
                            <div className="createItemValueDate">
                                <DateTimePicker
                                    clearIcon={null}
                                    disableClock={true}
                                    onChange={this.handleActiveTillDateChange}
                                    value={new Date(this.state.activeTill)}
                                />
                            </div>
                            <p className="timeZoneLabel">{this.state.timeZone}</p>
                        </div>
                    </FormGroup>
                    <FormGroup controlId="stadiumCamerasMax" bsSize="large">
                        <div className="createRow">
                            <p className="createItemLabel">
                                <ControlLabel>Stadium Cameras Max :</ControlLabel>
                            </p>
                            <p className="createItemValue">
                                <FormControl
                                    type="text"
                                    value={this.state.stadiumCamerasMax}
                                    onChange={this.handleChange}
                                />
                            </p>
                        </div>
                    </FormGroup>
                    <FormGroup controlId="virtualCamerasMax" bsSize="large">
                        <div className="createRow">
                            <p className="createItemLabel">
                                <ControlLabel>Virtual Cameras Max :</ControlLabel>
                            </p>
                            <p className="createItemValue">
                                <FormControl
                                    type="text"
                                    value={this.state.virtualCamerasMax}
                                    onChange={this.handleChange}
                                />
                            </p>
                        </div>
                    </FormGroup>
                    <LoaderButton
                        className="submitButton"
                        block
                        bsStyle="primary"
                        bsSize="large"
                        disabled={!this.validateForm()}
                        type="submit"
                        isLoading={this.state.isLoading}
                        text="Submit Request"
                        loadingText="Creating…"
                    />
                </form>
            </div>
        );
    }
}