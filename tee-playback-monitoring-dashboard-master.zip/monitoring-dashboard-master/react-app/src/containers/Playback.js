import React, {Component} from "react";
import {PageHeader} from "react-bootstrap";
import {API} from "aws-amplify";
import "./Playback.css";
import ReactTable from 'react-table';
import 'react-table/react-table.css';


export default class Playback extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');
        const zone = new Date().toLocaleTimeString('en-us', {timeZoneName: 'short'}).split(' ')[2];

        this.state = {
            isLoading: true,
            userId: currentUserId,
            deployment: props.location.state ? props.location.state.data : null,
            dms_list: [],
            timeZone: zone
        };
    }

    async componentDidMount() {
        try {
            var deployment = this.state.deployment;
            if (!deployment) {
                deployment = await this.deployment();
                this.setState({
                    deployment
                });
                console.log("deployment in Playback:  " + JSON.stringify(this.state.deployment));
            }
            const dms_list = await this.playbackData();

            dms_list.forEach((item) => {
                // console.log("Entry- type:",item.type,"created_on:", item.created_on, "storage_location:", item.storage_location);
                console.log("Data Set Entry: " + JSON.stringify(item));
            });

            this.setState({
                dms_list
            });
            //TODO: Do stuff with dms_list
        } catch (e) {
            alert(e);
        }

        this.setState({isLoading: false});
    }

    async loadLifeCycle(deployment, event) {
        try {
            this.props.history.push({
                pathname: "/deployments/" + deployment.deployment_id + "/status",
                state: {
                    deploymentId: deployment.deployment_id,
                    data: deployment,
                    status: "current"
                }
            });
        } catch (e) {
            alert(e);
        }
    }

    deployment() {
        console.log("deployment id in Playback: " + this.props.match.params.id);
        return API.get("fd19", `/deployments/${this.props.match.params.id}`);
    }

    playbackData() {
        var myInit = {
            headers: {
                "x-api-key": "o01fByGEag6VHqBsPowgB9cJALYe5otj8IbfLVh1"
            },
            'queryStringParameters': {
                  "type": "logs"
            }
        }
        return API.get("backup", `/dataset`, myInit);
    }

    renderLander() {
        return (
            <div className="lander">
                <h1>TEE19 Control</h1>
            </div>
        );
    }

    renderPage() {
        return (
            <div>
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Playback</PageHeader>
                <button className="backToLifeCycleButton" onClick={(e) => this.loadLifeCycle(this.state.deployment, e)}>
                    Life Cycle
                </button>
                <div className="playback">
                    {!this.state.isLoading && this.renderPlayback()}
                </div>
            </div>
        );
    }

    renderPlayback() {
        return (
            <div className="overview">
                <h1>Hello World</h1>
            </div>
        );
    }

    render() {
        return (
            <div className="Playback">
                {this.props.isAuthenticated ? this.renderPage() : this.renderLander()}
            </div>
        );
    }
}