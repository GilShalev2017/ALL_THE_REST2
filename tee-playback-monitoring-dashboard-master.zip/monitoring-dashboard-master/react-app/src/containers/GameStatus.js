import React, { Component } from "react";
import { PageHeader } from "react-bootstrap";
import "./GameStatus.css";
import {API} from "aws-amplify";
import stateOne from "../assets/state1_bg.png";
import stateTwo from "../assets/state2_bg.png";
import stateThreeA from "../assets/state3a_bg.png";
import stateThreeB from "../assets/state3b_bg.png";
import stateFourA from "../assets/state4a_bg.png";
import stateFourB from "../assets/state4b_bg.png";
import stateFiveA from "../assets/state5a_bg.png";
import stateFiveB from "../assets/state5b_bg.png";
import stateSix from "../assets/state6_bg.png";
import stateSeven from "../assets/state7_bg.png";
import stateEight from "../assets/state8_bg.png";
import stateNine from "../assets/state9_bg.png";
import stateTen from "../assets/state10_bg.png";
import stateEleven from "../assets/state11_bg.png";
import stateSevenCircle from "../assets/state7_circle_bg.png";
import arrowOne from "../assets/arrow1.png";
import arrowGreen from "../assets/arrow_green.png";
import arrowBlue from "../assets/arrow_blue.png";
import arrowTurquoise from "../assets/arrow_turquoise.png";
import end from "../assets/end_bg.png";

const styles = {
    stateOneBg: {
        backgroundImage: 'url(' + stateOne + ')',
    },

    stateTwoBg: {
        backgroundImage: 'url(' + stateTwo + ')'
    },

    stateThreeABg: {
        backgroundImage: 'url(' + stateThreeA + ')'
    },

    stateThreeBBg: {
        backgroundImage: 'url(' + stateThreeA + ')'
    },

    stateFourABg: {
        backgroundImage: 'url(' + stateFourA + ')'
    },

    stateFourBBg: {
        backgroundImage: 'url(' + stateFourA + ')'
    },

    stateFiveABg: {
        backgroundImage: 'url(' + stateFiveA + ')'
    },

    stateFiveBBg: {
        backgroundImage: 'url(' + stateFiveA + ')'
    },

    stateSixBg: {
        backgroundImage: 'url(' + stateSix + ')',
    },

    stateSevenBg: {
        backgroundImage: 'url(' + stateSeven + ')',
    },

    stateEightBg: {
        backgroundImage: 'url(' + stateEight + ')',
    },

    stateNineBg: {
        backgroundImage: 'url(' + stateNine + ')',
    },

    stateTenBg: {
        backgroundImage: 'url(' + stateTen + ')',
    },

    stateElevenBg: {
        backgroundImage: 'url(' + stateEleven + ')',
    },

    stateSevenCircleBg: {
        backgroundImage: 'url(' + stateSevenCircle + ')',
    },

    arrowOne: {
        backgroundImage: 'url(' + arrowOne + ')',
    },

    arrowGreen: {
        backgroundImage: 'url(' + arrowGreen + ')',
    },

    arrowBlue: {
        backgroundImage: 'url(' + arrowBlue + ')',
    },

    arrowTurquoise: {
        backgroundImage: 'url(' + arrowTurquoise + ')',
    },

    end: {
        backgroundImage: 'url(' + end + ')',
    },
};


export default class GameStatus extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');

        this.state = {
            isLoading: null,
            userId: currentUserId,
            deploymentId: props.location.state.deploymentId,
            gameData: props.location.state.data,
            status: props.location.state.status,
            deployment: null,
            deploymentStatus: null
        };
    }

    async componentDidMount() {
        if (this.state.deploymentId) {
            try {
                const deployment = await this.deployment(this.state.deploymentId);

                this.setState({
                    deployment
                });

                this.setState({deploymentStatus: deployment.deployment_status});

                console.log("deploymentStatus: " + this.state.deploymentStatus);
            } catch (e) {
                alert(e);
            }
        }
    }

    async planGame(game, event) {
        try {
            this.props.history.push({
                pathname: "/games/" + game.game_id + "/planGame/deploymentBasics",
                state: {
                    data: game
                }
            });
        } catch (e) {
            alert(e);
        }
    }

    deployment(deploymentId) {
        return API.get("fd19", `/deployments/${deploymentId}`);
    }

    gotoDeploymentOverview(game, event) {
        try {
            this.props.history.push({
                pathname: "/deployments/" + game.deployment_id,
            });
        } catch (e) {
            alert(e);
        }
    }

    gotoDeploymentDashboard(game, event) {
        try {
            this.props.history.push({
                pathname: "/deployments/" + game.deployment_id + "/dashboard",
            });
        } catch (e) {
            alert(e);
        }
    }


    openInNewTab(url) {
        var win = window.open(url, '_blank');
        win.focus();
    }

    gotoDashboard(deploymentId, event) {
        console.log("toplevel_ui_metrics: " + this.state.deployment.toplevel_ui_metrics);
        if (this.state.deployment.toplevel_ui_metrics) {
            this.openInNewTab(this.state.deployment.toplevel_ui_metrics)
        } else {
            alert("toplevel_ui_metrics: " + this.state.deployment.toplevel_ui_metrics);
        }
    }

    gotoSystemLevelDashboard(deploymentId, event) {
        try {
            this.props.history.push({
                pathname: "/deployments/" + deploymentId + "/systemLevelDashboard",
            });
        } catch (e) {
            alert(e);
        }
    }

    gotoBackupData(deploymentId, event) {
        try {
            this.props.history.push({
                pathname: "/deployments/" + deploymentId + "/backupData",
                state: {
                    data: this.state.deployment
                }
            });
        } catch (e) {
            alert(e);
        }
    }

    updateDeployment(deploymentId, deployment) {
        console.log("PUT body: " + JSON.stringify(deployment));
        return API.put("fd19", "/deployments/" + deploymentId, {
            body: deployment
        }).then(response => {
            console.log("API response: " + JSON.stringify(response));
            alert("Infra shutdown for " + deploymentId + " has been confirmed. \nActive_till: " + response.active_till);
        }).catch(error => {
            console.log(error.response)
        });
    }

    async shutdownInfra(deploymentId) {
        try {
            var activeTillValue = "now";
            await this.updateDeployment(deploymentId, {
                active_till: activeTillValue
            });
        } catch (e) {
            alert(e.message);
        }
    }

    async gotoShutdownInfra(deploymentId, event) {
        event.preventDefault();

        const confirmed = window.confirm(
            "Are you sure you want to shut down the infrastructure for " + deploymentId + "?"
        );

        if (!confirmed) {
            return;
        }

        try {
            await this.shutdownInfra(deploymentId);
        } catch (e) {
            alert(e.message);
        }
    }

    renderGameInfo(title, content) {
        return(
           <div className="gameInfoItem">
               <span className="gameInfoTitle">{title}</span>
               <span>{content}</span>
           </div>
        );
    }

    renderDiagram() {
        return (
            <div>
                <div className="partOneLabel">
                    Set-Up Day Pre-Production
                </div>
                <div className="diagramContainerPartOne">
                    <div className="diagramContainerPartOneA">
                        <div className={"stateContainer " + ((this.state.status === "current" ) ? 'stateDisabled' : '')}
                             onClick={(e) => this.planGame(this.state.gameData, e)}>
                            <img className="stateImage" src={stateOne} style={styles.stateOneBg}/>
                            <div className="stateText">Design/plan a game</div>
                        </div>
                    </div>
                    <div className="diagramContainerPartOneB">
                        <div className="arrowContainerInitial">
                            <img className="arrowImage" src={arrowOne} style={styles.arrowOne}/>
                        </div>
                        <div className={"stateContainer " + ((this.state.deploymentStatus !== "pending" && this.state.deploymentStatus !== "deployed" && this.state.deploymentStatus !== "active" && this.state.deploymentStatus !== "terminating" && this.state.deploymentStatus !== "terminated") ? 'stateDisabled' : '')}
                             onClick={(e) => this.gotoDeploymentDashboard(this.state.gameData, e)}>
                            <img className="stateImage" src={stateTwo} style={styles.stateTwoBg}/>
                            <div className="stateText">Init and config infra & applications</div>
                        </div>
                        <div className="arrowContainer">
                            <img className="arrowImage" src={arrowOne} style={styles.arrowOne}/>
                        </div>
                        <span className={"checkMarkIcon " + ((this.state.deploymentStatus !== "active" ) ? 'stateHidden' : '')}>&#10003;</span>
                        <div className={"stateContainer " + ((this.state.deploymentStatus !== "deployed" && this.state.deploymentStatus !== "active" && this.state.deploymentStatus !== "terminating" && this.state.deploymentStatus !== "terminated") ? 'stateDisabled' : '')}
                             onClick={(e) => this.gotoDeploymentOverview(this.state.gameData, e)}>
                            <img className="stateImage" src={stateThreeA} style={styles.stateThreeABg}/>
                            <div className="stateText">System is “Available”</div>
                        </div>
                        <div className="arrowContainer">
                            <img className="arrowImage" src={arrowOne} style={styles.arrowOne}/>
                        </div>
                        <div className="stateContainer stateDisabled">
                            <img className="stateImage" src={stateFourA} style={styles.stateFourABg}/>
                            <div className="stateText">System is “Configured”</div>
                        </div>
                        <div className="arrowContainer">
                            <img className="arrowImage" src={arrowOne} style={styles.arrowOne}/>
                        </div>
                        <div className="stateContainer stateDisabled">
                            <img className="stateImage" src={stateFiveA} style={styles.stateFiveABg}/>
                            <div className="stateText">Manual Checklist & System E2E Test</div>
                        </div>
                        <div className="arrowContainer">
                            <img className="arrowImage" src={arrowOne} style={styles.arrowOne}/>
                        </div>
                        <div className="stateContainer stateDisabled">
                            <img className="stateImage" src={stateTen} style={styles.stateTenBg}/>
                            <div className="stateText">Scale-Down / Hibernate</div>
                        </div>
                    </div>
                </div>
                <div className="partTwoLabel">
                    Game Day Pre-Production
                </div>
                <div className="diagramContainerPartTwo">
                    <div className="arrowContainerInitial">
                        <img className="arrowImage" src={arrowOne} style={styles.arrowOne}/>
                    </div>
                    <div className="stateContainer stateDisabled">
                        <img className="stateImage" src={stateEleven} style={styles.stateElevenBg}/>
                        <div className="stateText">Scale-Up / Wake-Up</div>
                    </div>
                    <div className="arrowContainer">
                        <img className="arrowImage" src={arrowOne} style={styles.arrowOne}/>
                    </div>
                    <div className="stateContainer stateDisabled">
                        <img className="stateImage" src={stateThreeB} style={styles.stateThreeBBg}/>
                        <div className="stateText">System is “Available”</div>
                    </div>
                    <div className="arrowContainer">
                        <img className="arrowImage" src={arrowOne} style={styles.arrowOne}/>
                    </div>
                    <div className="stateContainer stateDisabled">
                        <img className="stateImage" src={stateFourB} style={styles.stateFourBBg}/>
                        <div className="stateText">System is “Configured”</div>
                    </div>
                    <div className="arrowContainer">
                        <img className="arrowImage" src={arrowOne} style={styles.arrowOne}/>
                    </div>
                    <div className="stateContainer stateDisabled">
                        <img className="stateImage" src={stateFiveB} style={styles.stateFiveBBg}/>
                        <div className="stateText">Manual Checklist & System E2E Test</div>
                    </div>
                    <div className="arrowContainer">
                        <img className="arrowImage" src={arrowOne} style={styles.arrowOne}/>
                    </div>
                    <div className="stateContainer stateDisabled">
                        <img className="stateImage" src={stateSix} style={styles.stateSixBg}/>
                        <div className="stateText">System is "Ready for Production"</div>
                    </div>
                </div>
                <div className="arrowBlueContainer">
                    <img src={arrowBlue} style={styles.arrowBlue}/>
                </div>
                <div className="partThreeLabel">
                    Production States & Actions
                </div>
                <div className="diagramContainerPartThree">
                    <div className="stateCircleContainer stateDisabled">
                        <img className="stateCircleImage" src={stateSevenCircle} style={styles.stateSevenCircleBg}/>
                        <div className="stateCircleText">In game Configs</div>
                    </div>
                    <div className={"stateCircleContainer " + ((this.state.status === "upcoming" ) ? 'stateDisabled' : '')}
                         onClick={(e) => this.gotoSystemLevelDashboard(this.state.deploymentId, e)}>
                        <img className="stateCircleImage" src={stateSevenCircle} style={styles.stateSevenCircleBg}/>
                        <div className="stateCircleText">Monitoring</div>
                    </div>
                    <div className="stateCircleContainer stateDisabled">
                        <img className="stateCircleImage" src={stateSevenCircle} style={styles.stateSevenCircleBg}/>
                        <div className="stateCircleText">Healing / Recovery / Auto Scale</div>
                    </div>
                    <div className="stateCircleContainer stateDisabled">
                        <img className="stateCircleImage" src={stateSevenCircle} style={styles.stateSevenCircleBg}/>
                        <div className="stateCircleText">Logging</div>
                    </div>
                    <div className="stateContainerProduction stateDisabled">
                        <img className="stateImage" src={stateSeven} style={styles.stateSevenBg}/>
                        <div className="stateTextProduction">Production</div>
                    </div>
                </div>
                <div className="arrowTurquoiseContainer">
                    <img src={arrowTurquoise} style={styles.arrowTurquoise}/>
                </div>
                <div className="partFourLabel">
                    Post Production States
                </div>
                <div className="diagramContainerPartFour">
                    <div className="diagramContainerPartFourA">
                        <div className="endState">
                            <img className="stateImage" src={end} style={styles.end}/>
                            <div className="endStateText">End</div>
                        </div>
                    </div>
                    <div className="diagramContainerPartFourB">
                        <div className="arrowContainerEnd">
                            <img className="arrowImage" src={arrowGreen} style={styles.arrowGreen}/>
                        </div>
                        <div className={"stateContainerPostProduction " + ((this.state.deploymentStatus !== "deployed" && this.state.deploymentStatus !== "active") ? 'stateDisabled' : '')}
                             onClick={(e) => this.gotoShutdownInfra(this.state.deploymentId, e)}>
                            <img className="stateImage" src={stateNine} style={styles.stateNineBg}/>
                            <div className="stateTextPostProduction">Shutdown infra & application (compute resources)</div>
                        </div>
                        <div className="arrowContainerPostProduction">
                            <img src={arrowGreen} style={styles.arrowGreen}/>
                        </div>
                        <div className={"stateContainerPostProduction " + ((this.state.status === "upcoming" ) ? 'stateDisabled' : '')}
                             onClick={(e) => this.gotoBackupData(this.state.deploymentId, e)}>
                            <img className="stateImage" src={stateEight} style={styles.stateEightBg}/>
                            <div className="stateTextPostProduction">Backup game data/video/logs</div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
    render() {
        return (
            <div className="GameStatus">
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Game Status</PageHeader>
                <div className="gameInfo">
                    {this.state.gameData.game_id && this.renderGameInfo("Game ID: ", this.state.gameData.game_id)}
                    {this.state.deploymentId && this.renderGameInfo("Deployment ID: ", this.state.deploymentId)}
                </div>
                {this.renderDiagram()}
            </div>
        );
    }
}