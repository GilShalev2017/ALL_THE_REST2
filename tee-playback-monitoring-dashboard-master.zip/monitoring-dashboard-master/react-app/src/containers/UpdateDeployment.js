import React, {Component} from "react";
import {FormGroup, FormControl, ControlLabel, PageHeader} from "react-bootstrap";
import LoaderButton from "../components/LoaderButton";
import "./UpdateDeployment.css";
import "./react-datetime.css";
import {API} from "aws-amplify";
import Select from 'react-select';
import InputRange from 'react-input-range';
import "react-input-range/lib/css/index.css";
import DateTimePicker from 'react-datetime-picker';

export default class UpdateDeployment extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');
        const zone = new Date().toLocaleTimeString('en-us',{timeZoneName:'short'}).split(' ')[2];

        this.state = {
            isLoading: true,
            isDeleting: null,
            isCanceling: null,
            isUpdating: null,
            deploymentId: props.location.state.data.deployment_id,
            deploymentStatus: props.location.state.data.deployment_status,
            requestedBy: props.location.state.data.requested_by,
            lastModified: props.location.state.data.last_modified,
            awsRegion: props.location.state.data.region,
            activeBy: props.location.state.data.active_by,
            activeTill: props.location.state.data.active_till,
            stadiumCamerasMax: props.location.state.data.stadium_cameras.max_cameras,
            virtualCamerasMax: props.location.state.data.virtual_cameras.max_cameras,
            cvtMax: props.location.state.data.cvt.max_cameras,
            computeClusters: props.location.state.data.compute_clusters,
            sharedStorage: props.location.state.data.shared_storage,
            message: props.location.state.message,
            properties: {},
            userId: currentUserId,
            timeZone: zone,
            deployment: props.location.state.data,
            isCreating: props.location.state.isCreating,
            computerClusterCheckedValues: {}
        };
    }

    async componentDidMount() {
        var computerClusterCheckedValues = {};
        for (var key in this.state.computeClusters) {
            if(this.state.computeClusters.hasOwnProperty(key)) {
                computerClusterCheckedValues[key] = true;
            }
        }
        this.setState({computerClusterCheckedValues});
        try {
            var deploymentSchema = await this.getDeploymentSchema();
            var properties = deploymentSchema.properties;
            this.setState({properties});
        } catch (e) {
            alert(e.message);
        }

        this.setState({ isLoading: false });
    }

    getDeploymentSchema() {
        return API.get("fd19", "/deployments/schema");
    }

    validateForm() {
        return true;
    }

    handleChange = event => {
        this.setState({
            [event.target.id]: event.target.value
        });
    }

    handleChangeComputeClusters(key, tag, event) {
        var data = this.state.computeClusters;
        var item = data[key];
        if (tag === "cluster_size") {
            item[tag] = parseInt(event);
        } else if (tag === "server_type") {
            item[tag] = event.label;
        }
        data[key] = item;

        this.setState({computeClusters: data});
    }

    handleChangeComputeClustersTextbox(key, tag, event) {
        var data = this.state.computeClusters;
        var item = data[key];
        item[tag] = parseInt(event.target.value);
        data[key] = item;
        this.setState({computeClusters: data});
    }

    handleChangeComputeClustersCheckbox(key, event) {
        var checkedValuesData = this.state.computerClusterCheckedValues;
        checkedValuesData[key] = event.target.checked;
        this.setState({computerClusterCheckedValues: checkedValuesData});
        console.log("this.state.computerClusterCheckedValues[" + key + "]: " + this.state.computerClusterCheckedValues[key]);
    }

    handleChangeSharedStorage(key, tag, event) {
        var data = this.state.sharedStorage;
        var item = data[key];
        if (tag === "cluster_size") {
            item[tag] = parseInt(event);
        } else if (tag === "server_type") {
            item[tag] = event.label;
        } else {
            item[tag] = event.target.value;
        }
        data[key] = item;

        this.setState({sharedStorage: data});
    }

    handleChangeSharedStorageTextbox(key, tag, event) {
        var data = this.state.sharedStorage;
        var item = data[key];
        item[tag] = parseInt(event.target.value);
        data[key] = item;
        this.setState({sharedStorage: data});
    }

    handleChangeCameraTextbox(key, event) {
        var value = parseInt(event.target.value)
        this.setState({[key]: value});
    }

    handleChangeRegion = event => {
        this.setState({awsRegion: event.label});
    }

    handleActiveByDateChange = event => {
        this.setState({activeBy: event});
    }

    handleActiveTillDateChange = event => {
        this.setState({activeTill: event});
    }

    handleNumberSliderChange(key, event) {
        this.setState({[key]: event});
    }

    handleDelete = async event => {
        event.preventDefault();

        const confirmed = window.confirm(
            "Are you sure you want to delete the deployment for " + this.state.deploymentId + "?"
        );

        if (!confirmed) {
            return;
        }

        this.setState({ isDeleting: true });

        try {
            var deploymentId = this.state.deploymentId;
            const response = await this.deleteDeployment(deploymentId);
            console.log(response);
            this.props.history.push("/deployments");
        } catch (e) {
            console.log(e.message);
            this.setState({isDeleting: false});
        }
    }

    handleCancel = async event => {
        event.preventDefault();

        this.setState({ isCanceling: true });

        this.props.history.push("/deployments/" + this.state.deploymentId);
    }

    deleteDeployment(deploymentId) {
        return API.del("fd19", "/deployments/" + deploymentId).then(response => {
            console.log("API response: " + JSON.stringify(response));
        }).catch(error => {
            alert(error.response.data.message);
        });
    }

    handleSubmit = async event => {
        event.preventDefault();

        this.setState({isUpdating: true});

        try {
            var clusterData = this.state.computeClusters;
            for (var key in this.state.computerClusterCheckedValues) {
                if(this.state.computerClusterCheckedValues[key] === false) {
                    var item = clusterData[key];
                    item["cluster_size"] = 0;
                    clusterData[key] = item;
                }
            }
            await this.updateDeployment(this.state.deploymentId, {
                region: this.state.awsRegion,
                active_by: this.state.activeBy,
                active_till: this.state.activeTill,
                stadium_cameras: {max_cameras: parseInt(this.state.stadiumCamerasMax)},
                virtual_cameras: {max_cameras: parseInt(this.state.virtualCamerasMax)},
                cvt: {max_cameras: parseInt(this.state.cvtMax)},
                compute_clusters: this.cleanObject(clusterData),
                shared_storage: this.cleanObject(this.state.sharedStorage),
            });
            this.props.history.push("/deployments");
        } catch (e) {
            alert(e.message);
            this.setState({isUpdating: false});
        }
    }

    updateDeployment(deploymentId, deployment) {
        console.log("PUT body: " + JSON.stringify(deployment));
        return API.put("fd19", "/deployments/" + deploymentId, {
            body: deployment
        }).then(response => {
            console.log("API response: " + JSON.stringify(response));
        }).catch(error => {
            console.log(error.response)
        });
    }

    generateListFromObject(data) {
        var items = [];
        for (var key in data) {
            var item = data[key];
            item["key"] = key;
            items.push(item);
        }
        return items;
    }

    cleanObject(data) {
        var obj = {};
        for (var key in data) {
            var item = data[key];
            var currentKey = item["key"];
            delete item["key"];
            obj[currentKey] = item;
        }
        return obj;
    }

    generateOptionsForSelect(arr) {
        var items = [];
        for (var i = 0; i < arr.length; i++) {
            var item = {label: arr[i], value: arr[i]};
            items.push(item);
        }
        return items;
    }

    renderCostSection(deployment) {
        return (
            <div className="updateCostSection">
                <div className="overviewRow">
                    <p>Estimated Cost : {"$" + deployment.estimated_cost.total_cost_per_hour + "/hr x " + deployment.estimated_cost.total_active_hours + " active hours = $" + deployment.estimated_cost.total_estimated_cost}</p>
                    <button
                        className={"noThanksButton " + ((deployment.deployment_status !== "requested") ? 'hidden' : 'true')}
                        onClick={this.handleDelete}>Oops, no thanks
                    </button>
                </div>
                <p className="overviewCostInfo">Estimated cost is based on the number and type of cloud server
                    instances required for the deployment and based of AWS listed prices, it does not include data
                    traffic or long term storage charges.</p>
            </div>
        );
    }

    renderComputeClusters(data, properties) {
        var arr = this.generateListFromObject(data);
        return [{}].concat(arr).map(
            (item, i) =>
                i !== 0
                    ? <div key={item.key}>
                        <div className="clusterCheckbox" key={i}>
                            <input
                                onChange={this.handleChangeComputeClustersCheckbox.bind(this, item.key)}
                                type='checkbox'
                                defaultChecked={true}
                            />
                        </div>
                        <div className={"clusterEnabled " + ((this.state.computerClusterCheckedValues[item.key] === false ) ? 'clusterDisabled' : '')}>
                        <div className="clusterItem">{item.key}</div>
                        <div className="updateClusterRow">
                            <div className="itemKey">Type :</div>
                            <div className="updateClusterValueForType">
                                {item.type}
                            </div>
                        </div>
                        <div className="updateClusterRow">
                            <div className="itemKey">Cluster Size :</div>
                            <div className="clusterTextboxValue">
                                <input disabled={!this.state.computerClusterCheckedValues[item.key]} value={item.cluster_size ? item.cluster_size : ""} onChange={this.handleChangeComputeClustersTextbox.bind(this, item.key, "cluster_size")}/>
                            </div>
                            <div className="clusterNumberSliderValue">
                                <InputRange
                                    maxValue={properties[item.key].properties.cluster_size.maximum}
                                    minValue={properties[item.key].properties.cluster_size.minimum}
                                    value={item.cluster_size ? item.cluster_size : properties[item.key].properties.cluster_size.minimum}
                                    onChange={(e) => this.handleChangeComputeClusters(item.key, "cluster_size", e)}/>
                            </div>
                        </div>
                        <div className="updateClusterRow">
                            <div className="itemKey">Server Type :</div>
                            <div className="itemValue">
                                <div className="col-md-4">
                                    <Select options={this.generateOptionsForSelect(properties[item.key].properties.server_type.enum)}
                                            autoFocus
                                            value={{label: item.server_type, value: item.server_type}}
                                            onChange={(e) => this.handleChangeComputeClusters(item.key, "server_type", e)}
                                    />
                                </div>
                            </div>

                        </div>
                        </div>
                    </div> : ''
        );
    }

    renderRegions(data) {
        return (
            <div className="container regionValue">
                <div className="col-md-4">
                    <Select options={this.generateOptionsForSelect(data.enum)}
                            autoFocus
                            value={{label: this.state.awsRegion, value: this.state.awsRegion}}
                            onChange={this.handleChangeRegion}
                    />
                </div>
            </div>
        );
    }

    renderNumberSlider(prop, key) {
        return(
            <div className="numberSliderValue">
                <InputRange
                    maxValue={prop.maximum}
                    minValue={prop.minimum}
                    value={this.state[key] ? this.state[key] : prop.minimum }
                    onChange={(e) => this.handleNumberSliderChange(key, e)}/>
            </div>
        );
    }

    renderSharedStorage(data, properties) {
        var arr = this.generateListFromObject(data);
        return [{}].concat(arr).map(
            (item, i) =>
                i !== 0
                    ? <div key={item.key}>
                        <div className="clusterItem">{item.key}</div>
                        <div className="updateClusterRow">
                            <div className="itemKey">Cluster Size :</div>
                            <div className="clusterTextboxValue">
                                <input value={item.cluster_size ? item.cluster_size : ""} onChange={this.handleChangeSharedStorageTextbox.bind(this, item.key, "cluster_size")}/>
                            </div>
                            <div className="clusterNumberSliderValue">
                                <InputRange
                                    maxValue={properties[item.key].properties.cluster_size.maximum}
                                    minValue={properties[item.key].properties.cluster_size.minimum}
                                    value={item.cluster_size ? item.cluster_size : properties[item.key].properties.cluster_size.minimum}
                                    onChange={(e) => this.handleChangeSharedStorage(item.key, "cluster_size", e)}/>
                            </div>
                        </div>
                        <div className="updateClusterRow">
                            <div className="itemKey">Mount Point :</div>
                            <div className="itemValue">
                                <FormControl className="itemValue"
                                             autoFocus
                                             type="text"
                                             id={item.key}
                                             value={item.mount_point}
                                             onChange={(e) => this.handleChangeSharedStorage(item.key, "mount_point", e)}
                                />
                            </div>
                        </div>
                        <div className="updateClusterRow">
                            <div className="itemKey">Server Type :</div>
                            <div className="itemValue">
                                <div className="col-md-4">
                                    <Select options={this.generateOptionsForSelect(properties[item.key].properties.server_type.enum)}
                                            autoFocus
                                            value={{label: item.server_type, value: item.server_type}}
                                            onChange={(e) => this.handleChangeSharedStorage(item.key, "server_type", e)}
                                    />
                                </div>
                            </div>
                        </div>
                    </div> : ''
        );
    }

    renderButtonGroupForEditing() {
        return(
            <div className="buttonGroup">
                <LoaderButton
                    className="saveButton"
                    block
                    bsStyle="primary"
                    bsSize="large"
                    disabled={!this.validateForm()}
                    type="submit"
                    isLoading={this.state.isUpdating}
                    text="Update"
                    loadingText="Updating..."
                />
                <LoaderButton
                    className="cancelButton"
                    block
                    bsStyle="link"
                    bsSize="large"
                    isLoading={this.state.isCanceling}
                    onClick={this.handleCancel}
                    text="Cancel"
                    loadingText="Canceling…"
                />
            </div>
        );
    }

    renderButtonGroupForCreating() {
        return(
            <div className="buttonGroup">
                <LoaderButton
                    className="saveButton"
                    block
                    bsStyle="primary"
                    bsSize="large"
                    disabled={!this.validateForm()}
                    type="submit"
                    isLoading={this.state.isUpdating}
                    text="Update"
                    loadingText="Updating..."
                />
                <LoaderButton
                    className="deleteButton"
                    block
                    bsStyle="danger"
                    bsSize="large"
                    isLoading={this.state.isDeleting}
                    onClick={this.handleDelete}
                    text="Delete"
                    loadingText="Deleting…"
                />
                <LoaderButton
                    className="cancelButton"
                    block
                    bsStyle="link"
                    bsSize="large"
                    isLoading={this.state.isCanceling}
                    onClick={this.handleCancel}
                    text="Ok"
                    loadingText="Ok"
                />
            </div>
        );
    }

    renderDetailsForm() {
        return(
            <form onSubmit={this.handleSubmit}>
                {this.state.deployment.estimated_cost && this.renderCostSection(this.state.deployment)}
                <div className="columnSmall">
                    <div className="updateBlockOne">
                        <div className="updateReadOnlyTopRow">
                            <p>ID :</p>
                            <p className="updateValueID">{this.state.deploymentId}</p>
                        </div>
                        <div className="updateReadOnlyRow">
                            <p>Status :</p>
                            <p className="overviewValue">{this.state.deploymentStatus}</p>
                        </div>
                        <div className="updateReadOnlyRow">
                            <p>Requested By :</p>
                            <p className="overviewValue">{this.state.requestedBy && this.state.requestedBy}</p>
                        </div>
                        <div className="updateReadOnlyRow">
                            <p>Last Modified :</p>
                            <p className="overviewValue">{new Date(this.state.lastModified).toLocaleString()}</p>
                        </div>
                    </div>
                </div>
                <div className="columnLarge">
                    <div className="updateBlockTwo">
                        <FormGroup controlId="stadiumCamerasMax" bsSize="large">
                            <div className="updateTopRow">
                                <p className="updateItemLabel">
                                    <ControlLabel>Stadium Cameras Max :</ControlLabel>
                                </p>
                                <div className="cameraTextboxValue">
                                    <input value={this.state.stadiumCamerasMax ? this.state.stadiumCamerasMax : ""} onChange={this.handleChangeCameraTextbox.bind(this, "stadiumCamerasMax")}/>
                                </div>
                                {this.renderNumberSlider(this.state.properties.stadium_cameras.properties.max_cameras, "stadiumCamerasMax")}
                            </div>
                        </FormGroup>
                        <FormGroup controlId="virtualCamerasMax" bsSize="large">
                            <div className="updateRow">
                                <p className="updateItemLabel">
                                    <ControlLabel>Virtual Cameras Max :</ControlLabel>
                                </p>
                                <div className="cameraTextboxValue">
                                    <input value={this.state.virtualCamerasMax ? this.state.virtualCamerasMax : ""} onChange={this.handleChangeCameraTextbox.bind(this, "virtualCamerasMax")}/>
                                </div>
                                {this.renderNumberSlider(this.state.properties.virtual_cameras.properties.max_cameras, "virtualCamerasMax")}
                            </div>
                        </FormGroup>
                        <FormGroup controlId="cvtMax" bsSize="large">
                            <div className="updateRow">
                                <p className="updateItemLabel">
                                    <ControlLabel>CVT Max :</ControlLabel>
                                </p>
                                <div className="cameraTextboxValue">
                                    <input value={this.state.cvtMax ? this.state.cvtMax : ""} onChange={this.handleChangeCameraTextbox.bind(this, "cvtMax")}/>
                                </div>
                                {this.renderNumberSlider(this.state.properties.cvt.properties.max_cameras, "cvtMax")}
                            </div>
                        </FormGroup>
                    </div>
                </div>
                <div className="columnFull">
                    <div className="updateBlockThree">
                        <FormGroup controlId="awsRegion" bsSize="large">
                            <div className="updateTopRow">
                                <p className="updateRegionLabel">
                                    <ControlLabel>AWS Region : </ControlLabel>
                                </p>
                                {this.renderRegions(this.state.properties.region)}
                            </div>
                        </FormGroup>
                        <FormGroup controlId="activeBy" bsSize="large">
                            <div className="updateRegionRow">
                                <p className="updateRegionLabel">
                                    <ControlLabel>Active By: </ControlLabel>
                                </p>
                                <div className="updateRegionValue">
                                    <DateTimePicker
                                        clearIcon={null}
                                        disableClock={true}
                                        onChange={this.handleActiveByDateChange}
                                        value={new Date(this.state.activeBy)}
                                    />
                                </div>
                                <p className="updateTimeZoneLabel">{this.state.timeZone}</p>
                            </div>
                        </FormGroup>
                        <FormGroup controlId="activeTill" bsSize="large">
                            <div className="updateRegionRow">
                                <p className="updateRegionLabel">
                                    <ControlLabel>Active Till: </ControlLabel>
                                </p>
                                <div className="updateRegionValue">
                                    <DateTimePicker
                                        clearIcon={null}
                                        disableClock={true}
                                        onChange={this.handleActiveTillDateChange}
                                        value={new Date(this.state.activeTill)}
                                    />
                                </div>
                                <p className="updateTimeZoneLabel">{this.state.timeZone}</p>
                            </div>
                        </FormGroup>
                    </div>
                </div>
                <div className="columnHalf">
                    <div className="updateComputeClustersBlock">
                        <FormGroup bsSize="large">
                            <ControlLabel>Compute Clusters</ControlLabel>
                            {this.renderComputeClusters(this.state.computeClusters, this.state.properties.compute_clusters.properties)}
                        </FormGroup>
                    </div>
                </div>
                <div className="columnHalf">
                    <div className="updateSharedStorageBlock">
                        <FormGroup bsSize="large">
                            <ControlLabel>Shared Storage</ControlLabel>
                            {this.renderSharedStorage(this.state.sharedStorage, this.state.properties.shared_storage.properties)}
                        </FormGroup>
                    </div>
                </div>
                {this.state.isCreating ? this.renderButtonGroupForCreating() : this.renderButtonGroupForEditing()}
            </form>
        );
    }

    renderLander() {
        return (
            <div className="lander">
                <h1>TEE19 Control</h1>
            </div>
        );
    }

    renderPage() {
        return (
            <div>
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Deployment Details</PageHeader>
                <div className="message">{this.state.message}</div>
                {!this.state.isLoading ? this.renderDetailsForm() : ""}
            </div>
        );
    }

    render() {
        return (
            <div className="UpdateDeployment">
                {this.props.isAuthenticated ? this.renderPage() : this.renderLander()}
            </div>
        );
    }
}