import React, {Component} from "react";
import {ControlLabel, PageHeader} from "react-bootstrap";
import LoaderButton from "../components/LoaderButton";
import "./NewDeploymentForSelectedGameConfirm.css";
import {API} from "aws-amplify";

export default class NewDeploymentForSelectedGameConfirm extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');
        const zone = new Date().toLocaleTimeString('en-us', {timeZoneName: 'short'}).split(' ')[2];

        this.state = {
            isLoading: null,
            isUpdating: null,
            userId: currentUserId,
            timeZone: zone,
            gameData: props.location.state.gameData,
            deploymentData: props.location.state.deploymentData,
        };
    }

    setGameActiveByDate(dt) {
        dt.setHours(dt.getHours() - 1);
        return dt;
    }

    setGameActiveTillDate(dt) {
        dt.setHours(dt.getHours() + 6);
        return dt;
    }

    setValidDefaultActiveByDate(dt) {
        dt.setHours(dt.getHours() + 2);
        dt.setMinutes(dt.getMinutes() + 30);
        return dt;
    }

    validateForm() {
        return true;
    }

    onChange(name, values) {
        this.setState({[name]: values})
    }

    handleChange = event => {
        this.setState({
            [event.target.id]: event.target.value
        });
    }

    handleSubmit = async event => {
        event.preventDefault();

        this.setState({isUpdating: true});

        try {
            await this.createDeployment({
                deployment_name: this.state.deploymentData.deployment_name,
                active_by: this.state.deploymentData.active_by,
                active_till: this.state.deploymentData.active_till,
                stadium_cameras: this.state.deploymentData.stadium_cameras,
                virtual_cameras: this.state.deploymentData.virtual_cameras,
                requested_by: this.state.deploymentData.requested_by,
                allowed_game_ids: this.state.deploymentData.allowed_game_ids,
                game_info: this.state.deploymentData.game_info,
            });

            this.props.history.push({pathname: "/"});

        } catch (e) {
            alert(e.message);
            this.setState({isUpdating: false});
        }
    }

    createDeployment(deployment) {
        return API.post("fd19", "/deployments", {
            body: deployment
        }).then(response => this.setState({
            isUpdating: false,
            data: response
        })).catch(error => {
            console.log(error.response)
        });
    }

    deleteDeployment(deploymentId) {
        return API.del("fd19", "/deployments/" + deploymentId).then(response => {
            console.log("API response: " + JSON.stringify(response));
        }).catch(error => {
            alert(error.response.data.message);
        });
    }

    handleDelete = async event => {
        event.preventDefault();

        const confirmed = window.confirm(
            "Are you sure you want to delete the deployment for " + this.state.deploymentId + "?"
        );

        if (!confirmed) {
            return;
        }

        this.setState({isDeleting: true});

        try {
            var deploymentId = this.state.deploymentId;
            const response = await this.deleteDeployment(deploymentId);
            console.log(response);
            this.props.history.push("/");
        } catch (e) {
            console.log(e.message);
            this.setState({isDeleting: false});
        }
    }

    renderCostSection(deployment) {
        return (
            <div className="confirmCostSection">
                <div className="createRow">
                    <p>Estimated Cost
                        : {"$" + deployment.estimated_cost.total_cost_per_hour + "/hr x " + deployment.estimated_cost.total_active_hours + " active hours = $" + deployment.estimated_cost.total_estimated_cost}</p>
                    <button
                        className={"noThanksButton " + ((deployment.deployment_status !== "requested") ? 'hidden' : 'true')}
                        onClick={this.handleDelete}>Oops, no thanks
                    </button>
                </div>
                <p className="overviewCostInfo">Estimated cost is based on the number and type of cloud server
                    instances required for the deployment and based of AWS listed prices, it does not include data
                    traffic or long term storage charges.</p>
            </div>
        );
    }

    render() {
        return (
            <div className="NewDeploymentForSelectedGameConfirm">
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Game Planning</PageHeader>
                <div className="subHeader">3. Confirm</div>
                <form onSubmit={this.handleSubmit}>
                    <div className="gameInfoSection">
                        <div className="createRow">
                            <p className="newDeploymentForGameLabel">
                                <ControlLabel>Game ID :</ControlLabel>
                            </p>
                            <div className="newDeploymentForGameID">
                                {this.state.gameData.game_id}
                            </div>
                        </div>
                    </div>
                    <div className="column">
                        <div className="gameInfoBlock">
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Away Team :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.game_data.away.name}
                                </div>
                            </div>
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Home Team :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.game_data.home.name}
                                </div>
                            </div>
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Start time :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {new Date(this.state.gameData.game_data.start_time).toLocaleString() + "  " + this.state.timeZone}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="column">
                        <div className="gameInfoBlock">
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Venue Location :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.venue_location.name + ", " + this.state.gameData.venue_location.city + ", " + this.state.gameData.venue_location.state}
                                </div>
                            </div>
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>League :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.game_data.league}
                                </div>
                            </div>
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Year :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.game_data.year}
                                </div>
                            </div>
                        </div>
                    </div>
                    <br/>
                    <div className="preConfigInfoBlock">
                        <div className="createRow">
                            <p className="newDeploymentForGameLabel">
                                <ControlLabel>Active By :</ControlLabel>
                            </p>
                            <div className="newDeploymentForGameInfo">
                                {new Date(this.state.deploymentData.active_by).toLocaleString() + "  " + this.state.timeZone}
                            </div>
                        </div>
                        <div className="createRow">
                            <p className="newDeploymentForGameLabel">
                                <ControlLabel>Active Till :</ControlLabel>
                            </p>
                            <div className="newDeploymentForGameInfo">
                                {new Date(this.state.deploymentData.active_till).toLocaleString() + "  " + this.state.timeZone}
                            </div>
                        </div>
                        <div className="createRow">
                            <p className="newDeploymentForGameLabel">
                                <ControlLabel>Virtual Cameras Max :</ControlLabel>
                            </p>
                            <div className="newDeploymentForGameInfo">
                                {this.state.deploymentData.virtual_cameras.max_cameras}
                            </div>
                        </div>
                    </div>
                    <br/>
                    {this.state.deploymentData.estimated_cost && this.renderCostSection(this.state.deploymentData)}
                    <LoaderButton
                        className="submitButton"
                        block
                        bsStyle="primary"
                        bsSize="large"
                        disabled={!this.validateForm()}
                        type="submit"
                        isLoading={this.state.isUpdating}
                        text="Confirm"
                        loadingText="Confirming…"
                    />
                </form>
            </div>
        );
    }
}