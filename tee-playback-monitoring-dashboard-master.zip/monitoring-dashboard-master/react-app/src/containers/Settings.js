import React, { Component } from "react";
import { LinkContainer } from "react-router-bootstrap";
import LoaderButton from "../components/LoaderButton";
import "./Settings.css";

export default class Settings extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');

        this.state = {
            userId: currentUserId
        };
    }

    render() {
        return (
            <div className="Settings">
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <div className="settingsChangePassword">
                    <LinkContainer to="/settings/password">
                        <LoaderButton
                            block
                            bsSize="large"
                            text="Change Password"
                        />
                    </LinkContainer>
                </div>
            </div>
        );
    }
}