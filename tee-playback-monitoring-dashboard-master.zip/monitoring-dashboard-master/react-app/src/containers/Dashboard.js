import React, { Component } from "react";
import { PageHeader } from "react-bootstrap";
import "./Dashboard.css";

export default class Dashboard extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');

        this.state = {
            isLoading: null,
            userId: currentUserId
        };
    }

    render() {
        return (
            <div className="Dashboard">
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Dashboard</PageHeader>
            </div>
        );
    }
}