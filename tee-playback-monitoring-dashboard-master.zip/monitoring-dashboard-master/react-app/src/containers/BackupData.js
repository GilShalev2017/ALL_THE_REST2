import React, {Component} from "react";
import {PageHeader} from "react-bootstrap";
import {API} from "aws-amplify";
import "./BackupData.css";
import ReactTable from 'react-table';
import 'react-table/react-table.css';

const backup_table_data = [
   { type: "", name: "pCams" },
   { type: "", name: "vCams" },
   { type: "", name: "Curated Streams" },
   { type: "", name: "CVT data" },
   { type: "", name: "Points Clouds" },
   { type: "", name: "Periodic Metadata" },
   { type: "", name: "3rd party" },
   { type: "", name: "Audio" },
   { type: "", name: "Scoreboards" },
   { type: "logs", name: "Logs" },
   { type: "", name: "Monitoring" }
];


export default class BackupData extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');
        const zone = new Date().toLocaleTimeString('en-us', {timeZoneName: 'short'}).split(' ')[2];

        this.state = {
            isLoading: true,
            userId: currentUserId,
            deployment: props.location.state.data,
            game_id: props.location.state.data.game_id,
            backup: [],
            timeZone: zone
        };

        console.log("deployment in Backup Data:  " + JSON.stringify(this.state.deployment));
    }

    async componentDidMount() {
        try {
            const backup_list = await this.backup(this.state.game_id);

            // Find the most recent item for each type
            var backup_dict = {};
            backup_list.forEach((item) => {
                // console.log("Entry- type:",item.type,"created_on:", item.created_on, "storage_location:", item.storage_location);
                console.log("Data Set Entry: " + JSON.stringify(item));
                var old = backup_dict[item.type] || { created_on: ""};
                if (item.created_on > old.created_on) backup_dict[item.type] = item;
            });

            // Create array for the react-table to use
            var backup = [];
            backup_table_data.forEach((item) => {
                if (backup_dict[item.type])
                    backup.push({
                        name: item.name,
                        status: "S3 Backup Available",
                        created_on: new Date(backup_dict[item.type].created_on).toLocaleString()+" "+this.state.timeZone,
                        s3_link: backup_dict[item.type].storage_location.replace("s3://", "https://s3.console.aws.amazon.com/s3/buckets/"),
                        policy: "Delete after 14 days"
                    });
                else
                    backup.push({ name:item.name, status:"Not Available", created_on:"-" });
            });

            this.setState({
                backup
            });
//            console.log("this.state.backup: " + JSON.stringify(this.state.backup));
        } catch (e) {
            alert(e);
        }

        this.setState({isLoading: false});
    }

    async loadLifeCycle(deployment, event) {
        try {
            this.props.history.push({
                pathname: "/deployments/" + deployment.deployment_id + "/status",
                state: {
                    deploymentId: deployment.deployment_id,
                    data: deployment,
                    status: "current"
                }
            });
        } catch (e) {
            alert(e);
        }
    }

    backup(gameId) {
        var myInit = {
            headers: {
                "x-api-key": "o01fByGEag6VHqBsPowgB9cJALYe5otj8IbfLVh1"
            },
            'queryStringParameters': {
//                "gameId": gameId
// Work around for JIRA T19C-131
                  "venue": "A' OR metadata->>'gameId' = '"+gameId+"' OR type='A"
            }
        }
        return API.get("backup", `/dataset`, myInit);
    }

    renderLander() {
        return (
            <div className="lander">
                <h1>TEE19 Control</h1>
            </div>
        );
    }

    renderPage() {
        return (
            <div>
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Data Management Service</PageHeader>
                <button className="backToLifeCycleButton" onClick={(e) => this.loadLifeCycle(this.state.deployment, e)}>
                    Life Cycle
                </button>
                <div className="backup">
                    {!this.state.isLoading && this.renderBackupData(this.state.backup)}
                </div>
            </div>
        );
    }

    renderBackupData(backup) {
        const columns = [{
            Header: 'Data Type',
            accessor: 'name'
        }, {
            Header: 'Status',
            accessor: 'status'
        }, {
            Header: 'Created On',
            accessor: 'created_on',
        }, {
            Header: 'Storage Location',
            accessor: 's3_link',
            Cell: props => { if (props.value) return (<a href={props.value} target='_blank' rel="noopener noreferrer">S3 Link</a>); else return ""}
        }, {
            Header: 'Retention Policy',
            accessor: 'policy'
        }];

        return (
            <div className="overview">
                <h1>Available data sets related to Game ID: {this.state.game_id}</h1>
                <ReactTable
                    // Allow chaging background on non-empty rows
                    getTrProps={(state, rowInfo, column) => {
                        return {
                            className: rowInfo.row.created_on === "-" ? "empty" : "active"
                        }}}
                    showPagination={false}
                    resizable={false}
                    sortable={false}
                    defaultPageSize={backup.length}
                    data={backup}
                    columns={columns}/>
            </div>
        );
    }

    render() {
        return (
            <div className="BackupData">
                {this.props.isAuthenticated ? this.renderPage() : this.renderLander()}
            </div>
        );
    }
}