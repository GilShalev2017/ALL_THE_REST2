import React, {Component} from "react";
import {API} from "aws-amplify";
import {PageHeader} from "react-bootstrap";
import "./DeploymentDashboard.css";
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import deploymentStatus from "../assets/deployment_status.png"

const styles = {
    image: {
        width: '100%',
        height: '100%'
    }
};

export default class DeploymentDashboard extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');
        const zone = new Date().toLocaleTimeString('en-us', {timeZoneName: 'short'}).split(' ')[2];

        this.state = {
            isLoading: true,
            deployment: null,
            userId: currentUserId,
            timeZone: zone
        };
    }

    async componentDidMount() {
        try {
            const deployment = await this.deployment();

            this.setState({
                deployment
            });
        } catch (e) {
            alert(e.message);
        }

        this.setState({isLoading: false});
    }

    deployment() {
        return API.get("fd19", `/deployments/${this.props.match.params.id}`);
    }

    renderDeployment(deploymentSteps) {
        console.log(JSON.stringify(deploymentSteps));

        const columns = [{
            Header: 'Component',
            //accessor: 'project_name'
        }, {
            Header: 'Status',
            //accessor: 'step'
        }, {
            id: 'localTime',
            Header: 'Reported Time (Local)',
            //accessor: 'ref_name',
        }, {
            Header: 'Reported Time (UTC)',
            //accessor: 'project_id'
        }];

        return (
            <div className="overview">
                <h1>Deployment Status: {this.state.deployment.deployment_status}</h1>
                <ReactTable
                    showPagination={false}
                    resizable={false}
                    sortable={false}
                    defaultPageSize={deploymentSteps.length}
                    data={deploymentSteps}
                    columns={columns}/>
            </div>
        );
    }

    async loadLifeCycle(deployment, event) {
        try {
            this.props.history.push({
                pathname: "/deployments/" + deployment.deployment_id + "/status",
                state: {
                    deploymentId: deployment.deployment_id,
                    data: deployment,
                    status: "current"
                }
            });
        } catch (e) {
            alert(e);
        }
    }

    renderLander() {
        return (
            <div className="lander">
                <h1>TEE19 Control</h1>
            </div>
        );
    }

    renderPage() {
        return (
            <div>
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Deployment Dashboard</PageHeader>
                <button className="backToLifeCycleButton" onClick={(e) => this.loadLifeCycle(this.state.deployment, e)}>Life Cycle</button>
                <div className="dashboard">
                    {!this.state.isLoading && this.renderTempScreenshot()}
                </div>
            </div>
        );
    }

    renderTempScreenshot() {
        return(
            <div className="overview">
                <h1>Deployment Status: {this.state.deployment.deployment_status}</h1>
                <img src={deploymentStatus} style={styles.image} />
            </div>
        );
    }

    // Dynamic dashboard, currently commented out to use a temporary screenshot instead
    /*renderPage() {
        return (
            <div>
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Deployment Dashboard</PageHeader>
                <button className="backToLifeCycleButton" onClick={(e) => this.loadLifeCycle(this.state.deployment, e)}>Life Cycle</button>
                <div className="dashboard">
                    {!this.state.isLoading && this.renderDeployment(this.state.deployment.deployment_steps)}
                </div>
            </div>
        );
    }*/

    render() {
        return (
            <div className="DeploymentDashboard">
                {this.props.isAuthenticated ? this.renderPage() : this.renderLander()}
            </div>
        );
    }
}