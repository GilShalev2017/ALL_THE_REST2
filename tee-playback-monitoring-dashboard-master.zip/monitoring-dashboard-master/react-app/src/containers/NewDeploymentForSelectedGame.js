import React, {Component} from "react";
import {FormGroup, ControlLabel, PageHeader} from "react-bootstrap";
import LoaderButton from "../components/LoaderButton";
import "./NewDeploymentForSelectedGame.css";
import {API, Auth} from "aws-amplify";
import DateTimePicker from 'react-datetime-picker';

class CheckboxList extends Component {
    constructor(props) {
        super(props);
        this.state = {};
        props.values.map((v, i) => {
            this.state[v] = true;
        })
    }

    onChange(key, value) {
        this.setState({ [key]: value }, (state) => {
            this.props.onChange(this.state)
        })
    }

    render() {
        return (
            <div className="list-group-item form-group">
                {this.props.values.map((value, i) => (
                    <div className="checkbox" key={i}>
                        <label>
                            <input
                                onChange={(e) => this.onChange(value, e.target.checked)}
                                type='checkbox'
                                checked={this.state[value]}
                                value={this.state[value]}
                            />
                            {value}
                        </label>
                    </div>
                ))}
            </div>
        )
    }
}

export default class NewDeploymentForSelectedGame extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');
        const zone = new Date().toLocaleTimeString('en-us', {timeZoneName: 'short'}).split(' ')[2];

        var activeByDate = this.setGameActiveByDate(new Date(props.location.state.data.game_data.start_time));
        var activeTillDate = this.setGameActiveTillDate(new Date(props.location.state.data.game_data.start_time));

        this.state = {
            isRetrievingExperience: true,
            isLoading: null,
            userId: currentUserId,
            activeBy: activeByDate,
            activeTill: activeTillDate,
            stadiumCamerasMax: 38,
            virtualCamerasMax: 25,
            data: {},
            userEmail: {},
            timeZone: zone,
            gameData: props.location.state.data,
            experiences: [],
            showingExperiences: false
        };
    }

    experiences() {
        return API.get("fd19", "/deployments/lctest/templates");
    }

    async componentDidMount() {
        const userInfo = await Auth.currentUserInfo();
        const userEmail = userInfo.attributes.email;

        this.setState({userEmail})
        try {
            var response = await this.experiences();
            if (response.experiences) {
                var experiences = response.experiences;
                this.setState({experiences});
            }
        } catch (e) {
            console.log(e);
        }

        this.setState({isRetrievingExperience: false});
    }

    setGameActiveByDate(dt) {
        dt.setHours(dt.getHours() - 1);
        return dt;
    }

    setGameActiveTillDate(dt) {
        dt.setHours(dt.getHours() + 6);
        return dt;
    }

    setValidDefaultActiveByDate(dt) {
        dt.setHours(dt.getHours() + 2);
        dt.setMinutes(dt.getMinutes() + 30);
        return dt;
    }

    validateForm() {
        return true;
    }

    onChange(name, values) {
        this.setState({ [name]: values })
    }

    handleChange = event => {
        this.setState({
            [event.target.id]: event.target.value
        });
    }

    handleActiveByDateChange = event => {
        this.setState({activeBy: event});
    }

    handleActiveTillDateChange = event => {
        this.setState({activeTill: event});
    }

    handleSubmit = async event => {
        event.preventDefault();

        this.setState({isLoading: true});

        var oneHour = 59 * 60 * 1000;
        var currentTime = new Date();
        var defaultActiveByDate = this.setValidDefaultActiveByDate(currentTime);

        if (this.state.activeBy < defaultActiveByDate) {
            alert("Active By value needs to be at least 2.5 hours from the current time.");
            this.setState({isLoading: false});
        } else if ((this.state.activeTill - this.state.activeBy) < oneHour) {
            alert("Active Till value needs to be at least 1 hour later than Active By value.");
            this.setState({isLoading: false});
        } else {
            try {
                var game_ids = [];
                if (this.state.gameData.game_id !== "") {
                    game_ids.push(this.state.gameData.game_id);
                }
                var game_info = {};
                var game_object = {
                    venue_id: this.state.gameData.venue_id,
                    game_data: this.state.gameData.game_data,
                    venue_location: this.state.gameData.venue_location
                };
                game_info[this.state.gameData.game_id] = game_object;
                await this.createDeploymentPreDep({
                    deployment_name: this.state.gameData.game_id,
                    deployment_status: "preflight",
                    active_by: this.state.activeBy,
                    active_till: this.state.activeTill,
                    stadium_cameras: {max_cameras: parseInt(this.state.stadiumCamerasMax)},
                    virtual_cameras: {max_cameras: parseInt(this.state.virtualCamerasMax)},
                    requested_by: this.state.userEmail,
                    allowed_game_ids: game_ids,
                    game_info: game_info
                });

                this.props.history.push({
                    pathname: "/games/" + this.state.gameData.game_id + "/planGame/preDeploymentConfig",
                    state: {
                        deploymentData: this.state.data,
                        gameData: this.state.gameData
                    }
                });

            } catch (e) {
                alert(e.message);
                this.setState({isLoading: false});
            }
        }
    }

    createDeploymentPreDep(deployment) {
        return API.post("fd19", "/deployments", {
            body: deployment
        }).then(response => this.setState({
            isLoading: false,
            data: response
        })).catch(error => {
            console.log(error.response)
        });
    }


    renderExperiences() {
        const experiences = this.state.experiences;
        var experienceList = [];
        for (var i = 0; i < experiences.length; i++) {
            experienceList.push(experiences[i].title + " - " + experiences[i].description);
        }
        return (
            <div>
                <h4 className="experienceGroupTitle">Available Experiences</h4>
                <CheckboxList
                    onChange={(values) => this.onChange('experience', values)}
                    values={experienceList}
                />
            </div>
        );
    }

    render() {
        return (
            <div className="NewDeploymentForSelectedGame">
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Game Planning</PageHeader>
                <div className="subHeader">1. Deployment Basics</div>
                <form onSubmit={this.handleSubmit}>
                    <div className="gameInfoSection">
                        <div className="createRow">
                            <p className="newDeploymentForGameLabel">
                                <ControlLabel>Game ID :</ControlLabel>
                            </p>
                            <div className="newDeploymentForGameID">
                                {this.state.gameData.game_id}
                            </div>
                        </div>
                    </div>
                    <div className="column">
                        <div className="gameInfoBlock">
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Away Team :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.game_data.away.name}
                                </div>
                            </div>
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Home Team :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.game_data.home.name}
                                </div>
                            </div>
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Start time :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {new Date(this.state.gameData.game_data.start_time).toLocaleString() + "  " + this.state.timeZone}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="column">
                        <div className="gameInfoBlock">
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Venue Location :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.venue_location.name + ", " + this.state.gameData.venue_location.city + ", " + this.state.gameData.venue_location.state}
                                </div>
                            </div>
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>League :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.game_data.league}
                                </div>
                            </div>
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Year :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.game_data.year}
                                </div>
                            </div>
                        </div>

                    </div>
                    <br/>
                    <div className="deploymentBasicsSection">
                        <FormGroup controlId="activeBy" bsSize="large">
                            <div className="createRow">
                                <p className="createItemLabel">
                                    <ControlLabel>Active By :</ControlLabel>
                                </p>
                                <div className="createItemValueDate">
                                    <DateTimePicker
                                        clearIcon={null}
                                        disableClock={true}
                                        onChange={this.handleActiveByDateChange}
                                        value={new Date(this.state.activeBy)}
                                    />
                                </div>
                                <p className="timeZoneLabel">{this.state.timeZone}</p>
                            </div>
                        </FormGroup>
                        <FormGroup controlId="activeTill" bsSize="large">
                            <div className="createRow">
                                <p className="createItemLabel">
                                    <ControlLabel>Active Till :</ControlLabel>
                                </p>
                                <div className="createItemValueDate">
                                    <DateTimePicker
                                        clearIcon={null}
                                        disableClock={true}
                                        onChange={this.handleActiveTillDateChange}
                                        value={new Date(this.state.activeTill)}
                                    />
                                </div>
                                <p className="timeZoneLabel">{this.state.timeZone}</p>
                            </div>
                        </FormGroup>
                    </div>
                    <div className="experiences">
                        {(!this.state.isRetrievingExperience && this.state.experiences.length > 0 && this.state.showingExperiences) ? this.renderExperiences() : ""}
                    </div>
                    <LoaderButton
                        className="submitButton"
                        block
                        bsStyle="primary"
                        bsSize="large"
                        disabled={!this.validateForm()}
                        type="submit"
                        isLoading={this.state.isLoading}
                        text="Next"
                        loadingText="Creating…"
                    />
                </form>
            </div>
        );
    }
}