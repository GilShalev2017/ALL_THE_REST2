import React, {Component} from "react";
import {PageHeader, ListGroup, ListGroupItem} from "react-bootstrap";
import "./GamesManagement.css";
import {API} from "aws-amplify";
import LoaderButton from "../components/LoaderButton";
import Select from 'react-select';

export default class GamesManagement extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');
        const zone = new Date().toLocaleTimeString('en-us', {timeZoneName: 'short'}).split(' ')[2];
        const leagueList = ["NFL", "NBA"];

        this.state = {
            isLoading: true,
            games: [],
            userId: currentUserId,
            isCreating: null,
            deployment: null,
            timeZone: zone,
            leagues: leagueList,
            league: "NFL",
            venues: [],
            venueLabel: "All Supported Venues",
            venueID: "default",
            deployments: [],
            currentGames: [],
            pastGames: [],
        };
    }

    async componentDidMount() {
        if (!this.props.isAuthenticated) {
            return;
        }
        try {
            var venueResponse = await this.venues();
            if (venueResponse) {
                var venuesList = venueResponse.venues;
                var venues = [];
                for (var i = 0; i < venuesList.length; i++) {
                    if (venuesList[i].venue_config.deployed === true ) {
                        venues.push(venuesList[i]);
                    }
                }
                this.setState({venues});
            }

            var deployments = await this.deployments();
            this.groupDeployments(deployments);

            var deploymentIds = [];
            for (var j = 0; j < deployments.length; j++) {
                if (deployments[j].deployment_name) {
                    deploymentIds.push(deployments[j].deployment_name);
                }
            }

            var response = await this.games();
            var allGames = response.games;
            if (allGames) {
                var filteredGames = [];
                for (var k = 0; k < allGames.length; k++) {
                    if (!deploymentIds.includes(allGames[k].game_id)) {
                        filteredGames.push(allGames[k]);
                    }
                }
                var games = this.sortGamesByStartTimeAscending(filteredGames);
                this.setState({games});
            }
        } catch (e) {
            console.log(e);
        }

        this.setState({isLoading: false});
    }

    sortByKeyDescending(array, key) {
        return array.sort(function (a, b) {
            var x = a[key];
            var y = b[key];
            return ((x < y) ? -1 : ((x > y) ? 1 : 0));
        });
    }

    async groupDeployments(deploymentList) {
        var deployments = this.sortByKeyDescending(deploymentList, "active_by");
        var currentGames = [];
        var pastGames = [];
        for (var i = 0; i < deployments.length; ++i) {
            var dep = deployments[i];
            if (dep.game_info) {
                if (dep.deployment_status === "terminating" || dep.deployment_status === "terminated") {
                    pastGames.push(dep);
                } else {
                    currentGames.push(dep);
                }
            }
        }
        this.setState({deployments});
        this.setState({currentGames});
        this.setState({pastGames});
    }

    sortGamesByStartTimeAscending(array) {
        return array.sort(function (a, b) {
            var gameDataA = a.game_data;
            var gameDataB = b.game_data;
            var x = gameDataA.start_time;
            var y = gameDataB.start_time;
            return ((x < y) ? -1 : ((x > y) ? 1 : 0));
        });
    }

    formatDate(date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;

        return [year, month, day].join('-');
    }

    deployments() {
        return API.get("fd19", "/deployments");
    }

    deployment(deploymentId) {
        return API.get("fd19", `/deployments/${deploymentId}`);
    }

    games() {
        var startDate = this.formatDate(new Date());
        var dt = new Date();
        dt.setMonth(dt.getMonth() + 12);
        var endDate = this.formatDate(dt);
        return API.get("temp", "/eventconfig/nfl/events?start_date=" + startDate + "&end_date=" + endDate + "&deployed=true");
    }

    gamesByVenue(venueID) {
        var startDate = this.formatDate(new Date());
        var dt = new Date();
        dt.setMonth(dt.getMonth() + 12);
        var endDate = this.formatDate(dt);
        var venueList = [];
        venueList.push(venueID);
        return API.get("temp", "/eventconfig/nfl/events?start_date=" + startDate + "&end_date=" + endDate + "&venue_list=" + venueList[0] + "&deployed=true");
    }

    venues() {
        return API.get("temp", "/eventconfig/nfl/venues");
    }

    async gotoGameStatus(game, status, event) {
        console.log("game: " + JSON.stringify(game));
        try {
            this.props.history.push({
                pathname: "/games/" + game.game_id + "/gameStatus",
                state: {
                    deploymentId: game.deployment_id,
                    data: game,
                    status: status
                }
            });
        } catch (e) {
            alert(e);
        }
    }

    generateOptionsForSelect(arr) {
        var items = [];
        for (var i = 0; i < arr.length; i++) {
            var item = {label: arr[i], value: arr[i]};
            items.push(item);
        }
        return items;
    }

    generateVenuesForSelect(arr) {
        var items = [];
        var defaultSelection = {label: "All Supported Venues", value: "default"};
        items.push(defaultSelection);
        for (var i = 0; i < arr.length; i++) {
            var venueLocation = arr[i].venue_location;
            var item = {label: venueLocation.name + ", " + venueLocation.city + ", " + venueLocation.state, value: arr[i].venue_id};
            items.push(item);
        }
        return items;
    }

    handleChangeLeague = event => {
        this.setState({league: event.label});
    }

    async handleChangeVenue(event) {
        this.setState({
            venueLabel: event.label,
            venueID: event.value
        });

        try {
            var gamesResponse = null;
            var games = [];
            if (event.value === "default") {
                gamesResponse = await this.games();
            } else {
                gamesResponse = await this.gamesByVenue(event.value);
            }
            if (gamesResponse.games) {
                games = this.sortGamesByStartTimeAscending(gamesResponse.games);
            }
            this.setState({games});
        } catch (e) {
            console.log(e);
        }
    }

    renderGamesList(games) {
        return [{}].concat(games).map(
            (game, i) =>
                i !== 0
                    ? <ListGroupItem
                        className="gameItem"
                        key={game.game_data.away.name + game.game_data.home.name + i}
                        header={game.game_data.away.name + " vs " + game.game_data.home.name}>
                        <span className="gameDetailTitle">{"Start time: "}</span><span className="gameDetail">{new Date(game.game_data.start_time).toLocaleString() + "  " + this.state.timeZone}</span><br/>
                        <span className="gameDetailTitle">{"Venue location: "}</span><span className="gameDetail">{game.venue_location.name + ", " + game.venue_location.city + ", " + game.venue_location.state}</span><br/>
                        <span className="gameDetailTitle">{"League: " }</span><span className="gameDetail">{game.game_data.league}</span><br/>
                        <span className="gameDetailTitle">{"Year: " } </span><span className="gameDetail">{game.game_data.year}</span><br/>
                        <LoaderButton
                            className="planGameButton"
                            bsStyle="primary"
                            bsSize="small"
                            onClick={(e) => this.gotoGameStatus(game, "upcoming", e)}
                            text="Plan">
                        </LoaderButton>
                    </ListGroupItem>
                    : ""
        );
    }

    renderLander() {
        return (
            <div className="lander">
                <h1>TEE19 Control</h1>
            </div>
        );
    }

    renderPage() {
        return (
            <div>
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Games</PageHeader>
                {!this.state.isLoading ? this.renderGames() : ""}
            </div>
        );
    }

    renderVenueSelection() {
        return (
            <div className="col-md-4">
                <Select options={this.generateVenuesForSelect(this.state.venues)}
                        autoFocus
                        value={{label: this.state.venueLabel, value: this.state.venueID}}
                        onChange={(e) => this.handleChangeVenue(e)}/>
            </div>
        );
    }

    renderManageGameButton(game) {
        return (
            <LoaderButton
                className="manageGameButton"
                bsStyle="primary"
                bsSize="small"
                onClick={(e) => this.gotoGameStatus(game, "current", e)}
                text="Manage">
            </LoaderButton>
        );
    }

    renderDeploymentsList(deploymentType, deployments) {
        return [{}].concat(deployments).map(
            (deployment, i) =>
                i !== 0
                    ? <ListGroupItem
                        className={"gameItem " + (deployment.deployment_status === "active" ? 'gameItemActive' : '')}
                        key={deployment.deployment_id}
                        header={deployment.game_info[deployment.deployment_name].game_data.away.name + " vs " + deployment.game_info[deployment.deployment_name].game_data.home.name}>
                        <span className="gameDetailTitle">{"Start time: "}</span><span className="gameDetail">{new Date(deployment.game_info[deployment.deployment_name].game_data.start_time).toLocaleString() + "  " + this.state.timeZone}</span><br/>
                        <span className="gameDetailTitle">{"Venue location: "}</span><span className="gameDetail">{deployment.game_info[deployment.deployment_name].venue_location.name + ", " + deployment.game_info[deployment.deployment_name].venue_location.city + ", " + deployment.game_info[deployment.deployment_name].venue_location.state}</span><br/>
                        <span className="gameDetailTitle">{"League: " }</span><span className="gameDetail">{deployment.game_info[deployment.deployment_name].game_data.league}</span><br/>
                        <span className="gameDetailTitle">{"Year: " } </span><span className="gameDetail">{deployment.game_info[deployment.deployment_name].game_data.year}</span><br/>
                        <span className="gameDetailTitle">{"Status: " }</span><span className="gameDetail">{deployment.deployment_status}</span><br/>
                        <span className="gameDetailTitle">{"Deployment ID: " }</span><span className="gameDetail">{deployment.deployment_id}</span><br/>
                        <span className="gameDetailTitle">{"Active till: " }</span><span className="gameDetail">{new Date(deployment.active_till).toLocaleString() + "  " + this.state.timeZone}</span><br/>
                        <span className="gameDetailTitle">{"Requested by: " }</span><span className="gameDetail">{deployment.requested_by && deployment.requested_by}</span>
                        {deploymentType === "current" && this.renderManageGameButton(deployment)}
                    </ListGroupItem>
                    : ""
        );
    }

    renderGamesSection(deploymentType, deployments) {
        return (
            <div>
                <ListGroup>
                    {this.renderDeploymentsList(deploymentType, deployments)}
                </ListGroup>
            </div>
        );
    }

    renderGames() {
        return (
            <div className="events">
                <div className="dropdownRow">
                    <div className="leagueSelection">
                        <div className="col-md-4">
                            <Select options={this.generateOptionsForSelect(this.state.leagues)}
                                    autoFocus
                                    value={{label: this.state.league, value: this.state.league}}
                                    onChange={this.handleChangeLeague}
                            />
                        </div>
                    </div>
                    <div className="venueSelection">
                        {this.state.venues.length > 0 && this.renderVenueSelection()}
                    </div>
                </div>

                <h4 className="deploymentGroupTitle">Current Games</h4>
                {(this.state.currentGames.length > 0) ? this.renderGamesSection("current", this.state.currentGames) : "There is no current game."}

                <h4 className="deploymentGroupTitle">Upcoming Games</h4>
                <div className="gameList">
                    <ListGroup>
                        {(this.state.games.length > 0) ? this.renderGamesList(this.state.games) : "There is no upcoming game."}
                    </ListGroup>
                </div>

                <h4 className="deploymentGroupTitle">Past Games</h4>
                {(this.state.pastGames.length > 0) ? this.renderGamesSection("past", this.state.pastGames) : "There is no past game."}

            </div>
        );
    }

    render() {
        return (
            <div className="GamesManagement">
                {this.props.isAuthenticated ? this.renderPage() : this.renderLander()}
            </div>
        );
    }
}