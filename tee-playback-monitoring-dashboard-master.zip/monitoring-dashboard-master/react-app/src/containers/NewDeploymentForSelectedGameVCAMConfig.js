import React, {Component} from "react";
import {FormGroup, FormControl, ControlLabel, PageHeader} from "react-bootstrap";
import LoaderButton from "../components/LoaderButton";
import "./NewDeploymentForSelectedGameVCAMConfig.css";
import {API} from "aws-amplify";

export default class NewDeploymentForSelectedGameVCAMConfig extends Component {
    constructor(props) {
        super(props);

        const currentUserId = localStorage.getItem('userId');
        const zone = new Date().toLocaleTimeString('en-us', {timeZoneName: 'short'}).split(' ')[2];

        this.state = {
            isLoading: null,
            isUpdating: null,
            userId: currentUserId,
            timeZone: zone,
            data: {},
            gameData: props.location.state.gameData,
            deploymentData: props.location.state.deploymentData,
            virtualCamerasMax: props.location.state.deploymentData.virtual_cameras.max_cameras,
        };
    }

    validateForm() {
        return true;
    }

    onChange(name, values) {
        this.setState({ [name]: values })
    }

    handleChange = event => {
        this.setState({
            [event.target.id]: event.target.value
        });
    }

    createDeploymentPreflight(deployment) {
        return API.post("fd19", "/deployments", {
            body: deployment
        }).then(response => this.setState({
            isUpdating: false,
            data: response
        })).catch(error => {
            console.log(error.response)
        });
    }

    handleSubmit = async event => {
        event.preventDefault();

        this.setState({isUpdating: true});

        try {
            await this.createDeploymentPreflight({
                deployment_name: this.state.deploymentData.deployment_name,
                deployment_status: "preflight",
                active_by: this.state.deploymentData.active_by,
                active_till: this.state.deploymentData.active_till,
                stadium_cameras: this.state.deploymentData.stadium_cameras,
                requested_by: this.state.deploymentData.requested_by,
                allowed_game_ids: this.state.deploymentData.allowed_game_ids,
                game_info: this.state.deploymentData.game_info,
                virtual_cameras: {max_cameras: parseInt(this.state.virtualCamerasMax)},
            });

            this.props.history.push({
                pathname: "/games/" + this.state.gameData.game_id + "/planGame/confirm",
                state: {
                    deploymentData: this.state.data,
                    gameData: this.state.gameData
                }
            });

        } catch (e) {
            alert(e.message);
            this.setState({isUpdating: false});
        }
    }

    render() {
        return (
            <div className="NewDeploymentForSelectedGameVCAMConfig">
                <p className="userIDLabel">User ID: {this.state.userId}</p>
                <PageHeader>Game Planning</PageHeader>
                <div className="subHeader">2. Pre-Deployment Configuration</div>
                <form onSubmit={this.handleSubmit}>
                    <div className="gameInfoSection">
                        <div className="createRow">
                            <p className="newDeploymentForGameLabel">
                                <ControlLabel>Game ID :</ControlLabel>
                            </p>
                            <div className="newDeploymentForGameID">
                                {this.state.gameData.game_id}
                            </div>
                        </div>
                    </div>
                    <div className="column">
                        <div className="gameInfoBlock">
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Away Team :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.game_data.away.name}
                                </div>
                            </div>
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Home Team :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.game_data.home.name}
                                </div>
                            </div>
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Start time :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {new Date(this.state.gameData.game_data.start_time).toLocaleString() + "  " + this.state.timeZone}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="column">
                        <div className="gameInfoBlock">
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Venue Location :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.venue_location.name + ", " + this.state.gameData.venue_location.city + ", " + this.state.gameData.venue_location.state}
                                </div>
                            </div>
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>League :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.game_data.league}
                                </div>
                            </div>
                            <div className="createRow">
                                <p className="newDeploymentForGameLabel">
                                    <ControlLabel>Year :</ControlLabel>
                                </p>
                                <div className="newDeploymentForGameInfo">
                                    {this.state.gameData.game_data.year}
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className="preDeployConfigSection">
                        <FormGroup controlId="virtualCamerasMax" bsSize="large">
                            <div className="createRow">
                                <p className="createItemLabelCam">
                                    <ControlLabel>Virtual Cameras Max :</ControlLabel>
                                </p>
                                <p className="createItemValueCam">
                                    <FormControl
                                        type="text"
                                        value={this.state.virtualCamerasMax}
                                        onChange={this.handleChange}
                                    />
                                </p>
                            </div>
                        </FormGroup>
                    </div>
                    <LoaderButton
                        className="submitButton"
                        block
                        bsStyle="primary"
                        bsSize="large"
                        disabled={!this.validateForm()}
                        type="submit"
                        isLoading={this.state.isUpdating}
                        text="Next"
                        loadingText="Updating…"
                    />
                </form>
            </div>
        );
    }
}