import React from 'react';
import ReactDOM from 'react-dom';
import $ from 'jquery';

import MenuList from './MenuList';

class Menu extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [
                {
                    "id": 1,
                    "componentName": "Dashboard"
                }
            ]
        };
    }

    componentDidMount() {
    }

    render() {
        return (
            <div>
                <MenuList data={this.state.data} />
            </div>
        );
    }
}

export default Menu;
