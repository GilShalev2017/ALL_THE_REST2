import React from 'react';
import ReactDOM from 'react-dom';
import joint from 'jointjs/index';
import {connect} from 'react-redux';
import {API} from "aws-amplify";
import "./ComponentGraph.css";
import Shapes from '../jointjs-configuration/Shapes'

class ComponentGraph extends React.Component {

    constructor(props) {
        super(props);
        this.graph = new joint.dia.Graph();

        this.diagrams = {
            fd19: {
                title: "FD Core",
                node: {
                    decode: {
                        title: "Decoder",
                        output: ["multiview"]
                    },
                    multiview: {
                        title: "Color Match",
                        output: ["dxt","localization"]
                    },
                    dxt: {
                        title: "DXT conversion",
//                         output: ["render_hd", "render_4k", "render_360s"]
                        output: ["render"]
                    },
                    localization: {
                        title: "Localisation",
                        output: ["segmentation"]
                    },
                    segmentation: {
                        title: "Segmentation",
                        //output: ["recon_vh", "recon_xgen"]
                        output: ["reconstruction"]
                    },
//                    recon_vh: {
//                        title: "Reconstruction (VH)",
//                        output: ["render_hd", "render_4k", "render_360s"]
//                    },
//                    recon_xgen: {
//                        title: "Reconstruction (XGEN)",
//                        output: ["render_hd", "render_4k", "render_360s"]
//                    },
                      reconstruction: {
                         title: "Reconstruction",
//                         output: ["render_hd", "render_4k", "render_360s"]
                         output: ["render"]
                     },
                    camera: {
                        title: "Camera Engine",
//                         output: ["render_hd", "render_4k", "render_360s"]
                        output: ["render"]
                    },
                    render: {
                        title: "Render",
                        output: ["stream-agg"]
                    },
//                    render_hd: {
//                        title: "Render (HD)",
//                        output: ["stream-agg"]
//                    },
//                    render_4k: {
//                        title: "Render (4K)",
//                        output: ["stream-agg"]
//                    },
//                    render_360s: {
//                       title: "Render (360s)",
//                        output: ["stream-agg"]
//                    },
                    "stream-agg": {
                        title: "Stream Aggregator"
                    },
                    "flink": {
                        title: "Flink"
                    }
                }
            },
            dummy: {
                node: {
                    dummy: {
                        title: "Unknown Component",
                    }
                }
            }
        };
        const diagram = this.diagrams[this.props.component] || this.diagrams["dummy"];
        this.state = {
            isLoading: true,
            diagram: diagram,
            component: this.props.component,
            serviceStatus: null
        };
    }

    getInitialState() {
        this.state = {
            lastPosition: 0
        };
    }

    async componentDidMount() {
        try {
            // Kubernetes service status
            const serviceStatus = await this.serviceStatus();

            this.paper = new joint.dia.Paper({
                el: ReactDOM.findDOMNode(this.refs.placeholder),
                model: this.graph,
                width: "100%",
                height: 475,
                gridSize: 1,
                interactive: false
            });
            this.paper.options.defaultAnchor = {
                name: 'modelCenter',
                args: {
                    rotate: true,
                    padding: 20
                }
            };

            const _this = this;
            this.paper.on({
               'element:mouseenter': function(elementView, evt) {
                  console.log("mouse enter");
                  var currentElement = elementView.model;
                  console.log("tooltip: ", currentElement.attr('title/text'));
                  _this.showTooltip(currentElement.attr('title/text'));
               },
               'element:mouseleave': function(elementView, evt) {
                  console.log("mouse leave");
                  var currentElement = elementView.model;
                  console.log("tooltip: ", currentElement.attr('title/text'));
                  _this.showTooltip("");
               }
            });

            this.createChart();
            this.paper.scaleContentToFit({ padding: 50 });

            this.setState({
                serviceStatus
            });
            console.log("Kubernetes service status: " + JSON.stringify(this.state.serviceStatus));

            this.refreshPage();
        } catch (e) {
            alert(e.message);
        }
        this.setState({isLoading: false});
    }

    serviceStatus() {
        return API.get("service", `/${this.props.deployment.eks.cluster_name}`);
        //return API.get("service", `/fd19_cvte2etest8scm1`);
    }

    showTooltip(tooltip) {
        console.log("showTooltip() called:", tooltip);
        console.log("showTooltip() deployment id:", this.props.deployment.deployment_id);
    }

    createChart() {
        var node_histogram_template = new joint.shapes.custom.node.histogram();
        node_histogram_template.resize(200, 100);

        var link_template = new joint.shapes.standard.Link();
        link_template.attr({
            line: {
                strokeWidth: 2,
                stroke: 'blue'
            }
        });
        link_template.router('metro');
        link_template.connector('rounded');

        // Create Nodes in the diagram
        for (var node in this.state.diagram.node) {
            console.log("Creating "+node);
            var node_data = this.state.diagram.node[node];
            // console.log("node_data" + JSON.stringify(node_data));
            var rect = node_histogram_template.clone();
            rect.attr('label/text', node_data.title);
            //this.graph.addCells([rect]);
            rect.addTo(this.graph);
            node_data.rect = rect;
        }

        // Create Links between the nodes
        for (var node in this.state.diagram.node) {
            var node_data = this.state.diagram.node[node];
            if (node_data.output) {
                for (var i = 0; i < node_data.output.length; i++) {
                    if (!this.state.diagram.node[node_data.output[i]]) {
                        console.log("Can't find node '" + node_data.output[i] + "' listed as output node");
                        return;
                    }
                    console.log("node_data.output-" + i + ": " + node_data.output[i]);
                    var link = link_template.clone();
                    link.source(node_data.rect);
                    link.target(this.state.diagram.node[node_data.output[i]].rect);
                    link.addTo(this.graph);
                    //this.graph.addCells([link]);
                }
            }
        }

        var graphBBox = joint.layout.DirectedGraph.layout(this.graph, {
            nodeSep: 200,
            edgeSep: 100,
            rankSep: 100,
            marginY: 50,
            rankDir: "LR"
        });
    }

    updateChart() {
        console.log("UpdateChart");

        // Update Nodes in the diagram
        for (var node in this.state.diagram.node) {
            console.log("Updating "+node);
            var service_status = this.state.serviceStatus.tee_components[this.state.component];
            var node_data = this.state.diagram.node[node];
            var rect = node_data.rect;
            if (rect) {
                if (service_status) {
                    var svc = service_status.services[node];
                    console.log("Service data for "+node+":", svc);
                    if (svc) {
                        rect.setStatus(svc.readyReplicas,svc.desiredReplicas);
                    }
                }
            }
        }
    }

    async refreshPage () {
        setInterval(async () => {
            const serviceStatus = await this.serviceStatus();
            this.setState({
                serviceStatus
            });
            console.log("Kubernetes service status: " + JSON.stringify(this.state.serviceStatus));
            if (this.state.serviceStatus) {
                this.updateChart();
            }
        }, 10000);
    }

    render() {
        if (this.state.serviceStatus) {
            this.updateChart();
        }

        return (
            <div>
            <h1>{this.state.diagram.title}</h1>
            <div id="playground" ref="placeholder">
            </div></div>);
    }
}

function mapStateToProps(state) {
    if (state.newNodes.length == undefined)
        return {newNodes: []};
    else
        return {newNodes: [state.newNodes]};
}

export default connect(mapStateToProps)(ComponentGraph)
