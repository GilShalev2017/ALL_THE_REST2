import React from "react";
import { slide as Menu } from "react-burger-menu";
import "./SideBar.css";
import { LinkContainer } from "react-router-bootstrap";

export default props => {
    return (
        <Menu>
            <LinkContainer to="/">
                <a className="menu-item" href="/">
                    Home
                </a>
            </LinkContainer>
            <LinkContainer to="/games">
                <a className="menu-item" href="/games">
                    Game Scheduling
                </a>
            </LinkContainer>
            <LinkContainer to="/">
                <a className="menu-item" href="/">
                    Deployment Tool
                </a>
            </LinkContainer>
            <LinkContainer to="/deployments/new">
                <a className="menu-item sub-menu-item" href="/deployments/new">
                    Submit Deployment Request
                </a>
            </LinkContainer>
            <LinkContainer to="/deployments">
                <a className="menu-item sub-menu-item" href="/deployments">
                    View Deployments
                </a>
            </LinkContainer>
        </Menu>
    );
};