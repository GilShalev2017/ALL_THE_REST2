import React from 'react';
import ReactDOM from 'react-dom';

import MenuItem from './MenuItem';

class MenuList extends React.Component{
    render() {
        var menuItems = this.props.data.map(function(menuItem) {
            return (
                <div role="presentation" key={menuItem.id}>
                    <MenuItem label={menuItem.componentName} />
                </div>
            );
        });
        return (
            <ul className="wrapper">
                {menuItems}
            </ul>
        )
    }
}

export default MenuList;
