import React from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux'
import "./MenuItem.css";
import {addComponent} from '../actions/index'

class MenuItem extends React.Component{

    constructor(props) {
        super(props);
        this.fileUpload = React.createRef();
    }

    componentDidMount() {
        this.fileUpload.current.click();
    }

    render() {
        return (
            <a className="invisibleMenuItem" ref={this.fileUpload} onClick={this.props.generateEvent}>{this.props.label}</a>
        );
    }

}

function mapStateToProps(state) {
    return state;
}

function mapDispatchToProps(dispatch, props) {
    return {
        generateEvent : function() {
            dispatch(addComponent(props.label));
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(MenuItem)
