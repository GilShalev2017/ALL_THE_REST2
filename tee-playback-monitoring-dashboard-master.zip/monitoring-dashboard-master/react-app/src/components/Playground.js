import React from 'react';
import ReactDOM from 'react-dom';
import {Redirect} from 'react-router';
import joint from 'jointjs/index';
import {connect} from 'react-redux';
import {API} from "aws-amplify";
import "./Playground.css";
import Shapes from '../jointjs-configuration/Shapes'
import ReactTable from 'react-table';
import 'react-table/react-table.css';

class Graph extends React.Component {

    constructor(props) {
        super(props);
        this.graph = new joint.dia.Graph();
        this.fd19_diagram = {
            node: {
                stadium: {
                    title: "Stadium",
                    output: ["receiver"]
                },
                receiver: {
                    title: "Receiver",
                    output: ["fd19", "cvt"]
                },
                fd19: {
                    title: "FD Core",
                    output: ["mps"]
                },
                cvt: {
                    title: "CVT",
                    output: ["fd19"]
                },
                mps: {
                    title: "MPS",
                    output: ["mcc"]
                },
                mcc: {
                    title: "MCC",
                    output: ["cdn"]
                },
                cdn: {
                    title: "CDN",
                    output: ["client"]
                },
                client: {
                    title: "Client"
                },
                validation: {
                    title: "Validation"
                }
            }
        };
        this.state = {
            isLoading: true,
            systemMetrics: null,
            serviceStatus: null,
            toolTip: null,
            showComponentLevelDashboard: null
        };
    }

    getInitialState() {
        this.state = {
            lastPosition: 0
        };
    }

    async componentDidMount() {
        try {
            // System metrics
            const systemMetrics = await this.systemMetrics();
            // Kubernetes service status
            const serviceStatus = await this.serviceStatus();

            this.paper = new joint.dia.Paper({
                el: ReactDOM.findDOMNode(this.refs.placeholder),
                model: this.graph,
                width: "100%",
                height: 450,
                gridSize: 1,
                interactive: false
            });
            this.paper.options.defaultAnchor = {
                name: 'modelCenter',
                args: {
                    rotate: true,
                    padding: 20
                }
            };

            const _this = this;
            this.paper.on({
                'element:mouseenter': function (elementView, evt) {
                    console.log("mouse enter");
                    var currentElement = elementView.model;
                    console.log("node: ", currentElement.attr('label/data-id'));
                    //_this.showTooltip(currentElement.attr('title/text'));
                    var toolTip = currentElement.attr('label/data-id');
                    _this.setState({
                        toolTip
                    });
                },
                'element:mouseleave': function (elementView, evt) {
                    console.log("mouse leave");
                    var toolTip = "";
                    _this.setState({
                        toolTip
                    });
                },
                'element:pointerdown': function (elementView, evt) {
                    console.log("mouse down");
                    var currentElement = elementView.model;
                    var node = currentElement.attr('label/data-id');
                    if (node === "fd19") {
                        currentElement.setHighlight(true);
                    }
                },
                'element:pointerup': function (elementView, evt) {
                    console.log("mouse up");
                    var currentElement = elementView.model;
                    currentElement.setHighlight(false);
                },
                'element:pointerclick': function (elementView, evt) {
                    console.log("click event");
                    var currentElement = elementView.model;
                    console.log("node: ", currentElement.attr('label/data-id'));
                    var node = currentElement.attr('label/data-id');
                    if (node === "fd19") {
                        var showComponentLevelDashboard = node;
                        _this.setState({ showComponentLevelDashboard });
                    }
                }
            });

            this.createChart();
            this.paper.scaleContentToFit({ padding: 50 });

            this.setState({
                systemMetrics
            });
            console.log("System metrics: " + JSON.stringify(this.state.systemMetrics));

            this.setState({
                serviceStatus
            });
            console.log("Kubernetes service status: " + JSON.stringify(this.state.serviceStatus));

            this.refreshPage();
        } catch (e) {
            alert(e.message);
        }
        this.setState({isLoading: false});
    }

    systemMetrics() {
        return API.get("system", `/system?deployment_id=${this.props.deployment.deployment_id}`);
    }

    serviceStatus() {
        return API.get("service", `/${this.props.deployment.eks.cluster_name}`);
        //return API.get("service", `/fd19_cvte2etest8scm1`);
    }

    createChart() {
        var node_gauge_template = new joint.shapes.custom.node.gauge();
        node_gauge_template.resize(150, 40);

        var node_histogram_template = new joint.shapes.custom.node.histogram();
        node_histogram_template.resize(150, 100);

        var link_template = new joint.shapes.standard.Link();
        link_template.attr({
            line: {
                strokeWidth: 2,
                stroke: 'blue'
            }
        });
        link_template.router('metro');
        link_template.connector('rounded');

        // Create Nodes in the diagram
        for (var node in this.fd19_diagram.node) {
            console.log("Creating " + node);
            var node_data = this.fd19_diagram.node[node];
            // console.log("node_data" + JSON.stringify(node_data));
            var rect = node_histogram_template.clone();
            rect.attr('label/text', node_data.title);
            rect.attr('label/data-id', node);
            //this.graph.addCells([rect]);
            rect.addTo(this.graph);
            node_data.rect = rect;
        }

        // Create Links between the nodes
        for (var node in this.fd19_diagram.node) {
            var node_data = this.fd19_diagram.node[node];
            if (node_data.output) {
                for (var i = 0; i < node_data.output.length; i++) {
                    if (!this.fd19_diagram.node[node_data.output[i]]) {
                        console.log("Can't find node '" + node_data.output[i] + "' listed as output node");
                        return;
                    }
                    console.log("node_data.output-" + i + ": " + node_data.output[i]);
                    var link = link_template.clone();
                    link.source(node_data.rect);
                    link.target(this.fd19_diagram.node[node_data.output[i]].rect);
                    link.addTo(this.graph);
                    //this.graph.addCells([link]);
                }
            }
        }

        var graphBBox = joint.layout.DirectedGraph.layout(this.graph, {
            nodeSep: 200,
            edgeSep: 100,
            marginY: 100,
            rankDir: "LR"
        });
    }

    updateChart() {
        console.log("UpdateChart");

        // Update Nodes in the diagram
        for (var node in this.fd19_diagram.node) {
            console.log("Updating " + node);
            var metric_data = this.state.systemMetrics[node];
            var service_status = this.state.serviceStatus.tee_components[node];
            var node_data = this.fd19_diagram.node[node];
            var rect = node_data.rect;
            if (rect) {
                if (metric_data) {
                    var num_in = metric_data.active_in ? metric_data.active_in.num_active : 0;
                    var num_out = metric_data.active_out ? metric_data.active_out.num_active : 0;
                    if (metric_data.instances)
                        rect.setInstances(metric_data.instances);
                    if (metric_data.fps)
                        rect.setFps(metric_data.fps);
                    if (metric_data.active_in) {
                        rect.setActiveInOut(
                            this.props.deployment.stadium_cameras.max_cameras,
                            num_in, num_out);
                    } else {
                        rect.setActiveOut(
                            //this.props.deployment.cvt.max_cameras,
                            num_out, // Hack: Make sure CVT is always green
                            num_out);
                    }
                }
                if (service_status) {
                    //console.log("Services for "+node+":", service_status.services);
                    var instances = 0;
                    for (var name in service_status.services) {
                        var svc = service_status.services[name];
                        if (svc.desiredReplicas) {
                            instances += svc.readyReplicas ? svc.readyReplicas : 0;
                        }
                    }
                    rect.setStatus(service_status.readyServices, service_status.desiredServices);
                    rect.setInstances(instances);
                    node_data.service_status = service_status;
                }
            }
        }
    }

    renderToolTip () {
        var node_data = this.fd19_diagram.node[this.state.toolTip];
        if (!node_data || !node_data.service_status) return (<div className="toopTipText hidden"></div>);
        var list = [];
        Object.keys(node_data.service_status.services).forEach((name) => {
            const service = node_data.service_status.services[name];
            if (service.desiredReplicas) {
                list.push({name: name, ready: service.readyReplicas, desired: service.desiredReplicas, status: service.status});
            }
        });
        const columns = [{
            Header: 'Service',
            accessor: 'name',
            minWidth: 200,
            style: { "textAlign": "left" }
        }, {
            Header: 'Desired',
            accessor: 'desired',
            minWidth: 90
        }, {
            Header: 'Ready',
            accessor: 'ready',
            minWidth: 90
        }, {
            Header: 'Status',
            accessor: 'status',
            minWidth: 90
        }];


        return (
            <div className="toopTipText">
                <div className="toopTipHeader">Service Status for {node_data.title}</div>
                <ReactTable
                    showPagination={false}
                    resizable={false}
                    sortable={false}
                    defaultPageSize={list.length}
                    data={list}
                    columns={columns}/>
            </div>
        );
    }

    async refreshPage () {
        setInterval(async () => {
            const systemMetrics = await this.systemMetrics();
            const serviceStatus = await this.serviceStatus();
            this.setState({
                systemMetrics
            });
            console.log("System metrics: " + JSON.stringify(this.state.systemMetrics));
            this.setState({
                serviceStatus
            });
            console.log("Kubernetes service status: " + JSON.stringify(this.state.serviceStatus));
            if (this.state.systemMetrics && this.state.serviceStatus) {
                this.updateChart();
            }
        }, 10000);
    }

    render() {
        if (this.state.showComponentLevelDashboard) return( <Redirect to={"/deployments/"+this.props.deployment.deployment_id + "/componentLevelDashboard/" + this.state.showComponentLevelDashboard} />);
        if (this.state.systemMetrics && this.state.serviceStatus) {
            this.updateChart();
        }
        return (
            <div>
                <div id="playground" ref="placeholder">
                </div>
                {this.state.toolTip && this.renderToolTip()}
            </div>);
    }
}

function mapStateToProps(state) {
    if (state.newNodes.length === undefined)
        return {newNodes: []};
    else
        return {newNodes: [state.newNodes]};
}

export default connect(mapStateToProps)(Graph)
