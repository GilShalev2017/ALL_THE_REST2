#!/bin/bash

set -x

GITHASH=`git rev-parse --short HEAD`

# Create AWS resources with terraform
cd terraform/
terraform init
terraform workspace select $CI_ENVIRONMENT_NAME || terraform workspace new $CI_ENVIRONMENT_NAME
terraform apply \
    -refresh=true \
    -auto-approve \
    -var-file=env/${CI_ENVIRONMENT_NAME}.tfvars \
    -var "s3_bucket_name=${S3_BUCKET}"