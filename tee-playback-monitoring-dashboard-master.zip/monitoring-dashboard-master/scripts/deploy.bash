#!/bin/bash

# Debugging the workflow of the script
set -x

#Open the app directory 
cd react-app/

if [ $? -ne 0 ]
then
    echo "Directory react-app does not exist"
    exit 1
fi

# Sync the content from local to s3 bucket 
pwd; ls -lart
aws s3 sync build/ s3://${S3_BUCKET}/