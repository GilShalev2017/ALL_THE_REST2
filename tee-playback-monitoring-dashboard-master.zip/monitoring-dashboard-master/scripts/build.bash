#!/bin/bash

# Debugging the workflow of the script
set -x

# Open the app directory
cd react-app/

if [ $? -ne 0 ]
then
    echo "Directory react-app does not exist"
    exit 1
fi

# Node JS build
npm install && npm run build 