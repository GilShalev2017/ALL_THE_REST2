var fd19_diagram = {
    node: {
        stadium: {
            title: "Stadium Uploader",
            output: [ "fd19" ]
        },
        fd19: {
            title: "FD19 Core",
            output: [ "platform", "cvt" ]
        },
        platform: {
            title: "Platform"
        },
        cvt: {
            title: "CVT",
            output: [ "fd19" ]
        }
    }
};

var fd19_metrics = {
    stadium: {
        instances: 38,
        fps: 30
    }
};



var graph = new joint.dia.Graph;

var paper = new joint.dia.Paper({
    el: document.getElementById('myholder'),
    model: graph,
    width: 2000,
    height: 600,
    gridSize: 1,
    interactive: true
});

paper.options.defaultAnchor = {
    name: 'modelCenter',
    args: {
        rotate: true,
        padding: 20
    }
};

// Node with a half-circle gauge
joint.shapes.standard.Rectangle.define('custom.node.gauge', {
    attrs: {
        body: {
            refWidth: '100%',
            refHeight: '100%',
            strokeWidth: 2,
            stroke: '#F39C12',
            fill: '#FFFFFF',
            rx: 5,
            ry: 5
        },
        label: {
            textVerticalAnchor: 'middle',
            textAnchor: 'middle',
            refX: '50%',
            refY: '50%',
            fontSize: 14,
            fontWeight: 'bold',
            fill: 'black'
        },
        gaugelabel: {
            textVerticalAnchor: 'bottom',
            textAnchor: 'middle',
            refX: '50%',
            refY: '-20',
            fontSize: 14,
            fontWeight: 'bold',
            fill: 'black'
        },
        innergauge: {
            refCx: '50%',
            cy: '-20',
            r: '54',
            fill: 'none',
            stroke: '#999999',
            strokeWidth: 20,
            clipPath: "url(#cut-off-bottom)"
        },
        gauge: {
            refCx: '50%',
            cy: '-20',
            r: '54',
            fill: 'none',
            stroke: 'green',
            strokeWidth: 20,
            strokeDasharray: "339.292",
            strokeDashoffset: "0",
            clipPath: "url(#cut-off-bottom)"
        }
    }
}, {
    markup: [{
        tagName: 'rect',
        selector: 'body',
    }, {
        tagName: 'text',
        selector: 'label'
    }, {
        tagName: 'circle',
        selector: 'innergauge'
    }, {
        tagName: 'circle',
        selector: 'gauge'
    }, {
        tagName: 'text',
        selector: 'gaugelabel'
    }]
});

joint.shapes.custom.node.gauge.prototype.setValue = function(v) {
    var c = 339.292/2;
    this.attr("gauge/strokeDashoffset", c* (100-v) / 100);
    this.attr("gaugelabel/text", v +"ms");
    console.log("Setting node to", v);
};

var node_gauge_template = new joint.shapes.custom.node.gauge();
node_gauge_template.resize(150, 40);


// Node with a histogram
joint.shapes.standard.Rectangle.define('custom.node.histogram', {
    attrs: {
        body: {
            refWidth: '100%',
            refHeight: '100%',
            strokeWidth: 2,
            stroke: '#F39C12',
            fill: '#FFFFFF',
            rx: 5,
            ry: 5
        },
        body2: {
            refWidth: '100%',
            refHeight: '33%',
            refY: '67%',
            strokeWidth: 2,
            stroke: '#F39C12',
            fill: '#F39C12',
            rx: 5,
            ry: 5
        },
        label: {
            textVerticalAnchor: 'middle',
            textAnchor: 'middle',
            refX: '50%',
            refY: '35%',
            fontSize: 14,
            fontWeight: 'bold',
            fill: 'black'
        },
        instances: {
            textVerticalAnchor: 'middle',
            textAnchor: 'start',
            refX: '5%',
            refY: '82%',
            fontSize: 12,
            fontWeight: 'bold',
            fill: 'white'
        },
        fps: {
            textVerticalAnchor: 'middle',
            textAnchor: 'end',
            refX: '95%',
            refY: '82%',
            fontSize: 12,
            fontWeight: 'bold',
            fill: 'white'
        }
    }
}, {
    markup: [{
        tagName: 'rect',
        selector: 'body',
    }, {
        tagName: 'rect',
        selector: 'body2',
    }, {
        tagName: 'text',
        selector: 'label'
    }, {
        tagName: 'text',
        selector: 'instances'
    }, {
        tagName: 'text',
        selector: 'fps'
    }]
});

joint.shapes.custom.node.histogram.prototype.setInstances = function(v) {
    this.attr("instances/text", "" + v);
};

joint.shapes.custom.node.histogram.prototype.setFps = function(v) {
    this.attr("fps/text", v +"fps");
};

var node_histogram_template = new joint.shapes.custom.node.histogram();
//node_template.position(100, 30);


node_histogram_template.resize(150, 50);

var link_template = new joint.shapes.standard.Link();
link_template.attr({
    line: {
        strokeWidth: 2,
        stroke: 'red'
    }    
});
link_template.router('metro');
link_template.connector('rounded');

// Create Nodes in the Diagram
Object.keys(fd19_diagram.node).forEach(function(node) {
    var node_data = fd19_diagram.node[node];
    var metric_data = fd19_metrics[node];
//    var rect = node_gauge_template.clone();
    var rect = node_histogram_template.clone();
//    rect.translate(200*node_data.layout[1], 100*node_data.layout[0]);
    rect.attr('label/text', node_data.title);
    if (metric_data) {
        rect.setInstances(metric_data.instances);
    }
    rect.addTo(graph);
    node_data.rect = rect;
});


// Create Links between the nodes
if (false) Object.keys(fd19_diagram.node).forEach(function(node) {
    var node_data = fd19_diagram.node[node];
    
    if (!node_data.output) return;
    node_data.output.forEach(function(output) {
        if (!fd19_diagram.node[output]) {
            console.log("Can't find node '"+output+"' listed as output node");
            return;
        }
        var link = link_template.clone();
        link.source(node_data.rect);
        link.target(fd19_diagram.node[output].rect);
        link.addTo(graph);
    });
});

var graphBBox = joint.layout.DirectedGraph.layout(graph, {
    nodeSep: 100,
    edgeSep: 100,
    marginY: 100,
    rankDir: "LR"
});

