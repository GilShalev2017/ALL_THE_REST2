var apigAuth = {
    accessKey: 'AKIAJKNX4XID52N2OL7Q',
    secretKey: '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',
    region: 'us-east-1' // OPTIONAL: The region where the API is deployed, by default this parameter is set to us-east-1
};
var apigClient = apigClientFactory.newClient(apigAuth);

function loadDeployments() {
  var params = {}
  var body = {}
  var additionalParams = {}

  apigClient.deploymentsGet(params, body, additionalParams)
    .then(function(result){
        console.log("OK:", result);
        var deployment_list = result.data;
        var table = document.getElementById("DeploymentTable");
        if (deployment_list.length) {
           deployment_list.forEach(function(deployment) {
              console.log("Deployment:", deployment);
              var row = table.insertRow(1);
              var cell1 = row.insertCell(0);
              var cell2 = row.insertCell(1);
              var cell3 = row.insertCell(2);
              var cell4 = row.insertCell(3);
              cell1.innerHTML = deployment.deployment_id;
              cell2.innerHTML = deployment.active_by;
              cell3.innerHTML = deployment.deployment_status;
              var actions = '<div style="text-align:left;margin-left:60px">';
              actions += "<input type='submit' value='View' onclick='document.getElementById(\"deployment_id\").value=\""+deployment.deployment_id+"\"'>";
              if (deployment.deployment_status != "deployed") {
                 actions += "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' value='Delete' onclick='delete_deployment(event, \""+deployment.deployment_id+"\")'>";
              }
              actions += "</div>";
              cell4.innerHTML = actions;
           });
        }
    }).catch( function(result){
        //This is where you would put an error callback
    });
}

function delete_deployment(event, deployment_id) {
  event.stopPropagation();
  event.preventDefault();

  console.log("delete_deployment:", deployment_id);

  var params = { deployment_id: deployment_id }; // Example value
  var body = {};
  var additionalParams = {};

  apigClient.deploymentsDeploymentIdDelete(params, body, additionalParams)
    .then(function(result){
        console.log("OK:", result);
        location.reload();
    }).catch( function(result){
        //This is where you would put an error callback
    });
}

loadDeployments();
