var apigAuth = {
    accessKey: 'AKIAJKNX4XID52N2OL7Q',
    secretKey: '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',
    region: 'us-east-1' // OPTIONAL: The region where the API is deployed, by default this parameter is set to us-east-1
};
var apigClient = apigClientFactory.newClient(apigAuth);

function loadDeployments() {
  var params = {}
  var body = {}
  var additionalParams = {}

  apigClient.deploymentsGet(params, body, additionalParams)
    .then(function(result){
        console.log("OK:", result);
        var deployment_list = result.data;
        var table = document.getElementById("DeploymentTable");
        if (deployment_list.length) {
           deployment_list.forEach(function(deployment) {
              console.log("Deployment:", deployment);
              var row = table.insertRow(1);
              var cell1 = row.insertCell(0);
              var cell2 = row.insertCell(1);
              var cell3 = row.insertCell(2);
              cell1.innerHTML = deployment.deployment_id;
              cell2.innerHTML = deployment.active_by;
              cell3.innerHTML = deployment.deployment_status;
              row.onclick = function() {
                 console.log("Clicked on", deployment.deployment_id);
                 loadDeploymentInfo(deployment.deployment_id);
              };
           });
        }
    }).catch( function(result){
        //This is where you would put an error callback
    });
}

function loadDeploymentInfo(deployment_id) {
  var params = { deployment_id: deployment_id }
  var body = {}
  var additionalParams = {}

  apigClient.deploymentsDeploymentIdGet(params, body, additionalParams)
    .then(function(result){
        console.log("OK:", result);
        var deployment_info = result.data;

        var is_deployed = (deployment_info.deployment_status == "deployed") || (deployment_info.deployment_status == "active");

        var status_div = document.getElementById("status_div");
        status_div.innerHTML = deployment_info.deployment_status;

        var sub_status_div = document.getElementById("sub_status_div");
        sub_status_div.innerHTML = "Deployed from "+ new Date(deployment_info.active_by) +" till "+ new Date(deployment_info.active_till);

        var stadium_div = document.getElementById("stadium_div");
        stadium_div.innerHTML = deployment_info.stadium_cameras.max_cameras+" cameras supported";

        var virtual_div = document.getElementById("virtual_div");
        virtual_div.innerHTML = deployment_info.virtual_cameras.max_cameras+" cameras supported";

        var row = document.getElementById("compute_clusters_row");
        var keys = Object.keys(deployment_info.compute_clusters).sort();
        keys.forEach(function(key) {
           console.log("Compute Cluster:", key);
           var cluster = deployment_info.compute_clusters[key];
           console.log("Cluster Info:", cluster);
           var cell = row.insertCell(-1);
           var content = "<h4>"+key+"</h4>"+
                            cluster.cluster_size+" nodes<br/>"+
                            cluster.server_type+"<br/><br/>";
           if (is_deployed) {
              if (cluster.kibana_ui_metrics != "##MISSING##") {
                 content += "<input type='submit' value='Dashboard' onclick='window.open(\""+cluster.kibana_ui_metrics+"\", \"_blank\")'>";
              }
              if (cluster.kibana_ui_logs != "##MISSING##") {
                 content += "&nbsp;&nbsp;<input type='submit' value='Log Files' onclick='window.open(\""+cluster.kibana_ui_logs+"\", \"_blank\")'>";
              }
              if ((cluster.type == "flink") && cluster.flink_ui != "##MISSING##") {
                 content += "&nbsp;&nbsp;<input type='submit' value='Goto Flink UI' onclick='window.open(\""+cluster.flink_ui+"\", \"_blank\")'>";
              }
           }
           cell.innerHTML = content;
           // TODO: Add more details
        });
        
        
        row = document.getElementById("storage_row");
        var keys = Object.keys(deployment_info.shared_storage).sort();
        keys.forEach(function(key) {
           console.log("Storage:", key);
           var storage = deployment_info.shared_storage[key];
           console.log("Storage Info:", storage);
           var cell = row.insertCell(-1);
           var content = "<h4>"+key+"</h4>"+
                            storage.cluster_size+" nodes<br/>"+
                            storage.server_type+"<br/>"+
                            storage.mount_point+"<br/><br/>";
           if (is_deployed) {
              if (storage.kibana_ui_metrics != "##MISSING##") {
                 content += "<input type='submit' value='Dashboard' onclick='window.open(\""+storage.kibana_ui_metrics+"\",\"_blank\")'>";
              }
           }
           cell.innerHTML = content;
           // TODO: Add more details
        });
        console.log("DONE");
        
    }).catch( function(result){
        //This is where you would put an error callback
    });
}

const urlParams = new URLSearchParams(window.location.search);
const deployment_id = urlParams.get('deployment_id');

if (deployment_id) {
   var title = document.getElementById("deployment_title");
   title.innerHTML = deployment_id;
   console.log("Deployment:", deployment_id);
   loadDeploymentInfo(deployment_id);
}




