var apigAuth = {
    accessKey: 'AKIAJKNX4XID52N2OL7Q',
    secretKey: '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',
    region: 'us-east-1' // OPTIONAL: The region where the API is deployed, by default this parameter is set to us-east-1
};
var apigClient = apigClientFactory.newClient(apigAuth);

function loadDeployments() {
  var params = {}
  var body = {}
  var additionalParams = {}

  apigClient.deploymentsGet(params, body, additionalParams)
    .then(function(result){
        console.log("OK:", result);
        var deployment_list = result.data;
        var table = document.getElementById("DeploymentTable");
        if (deployment_list.length) {
           deployment_list.forEach(function(deployment) {
              console.log("Deployment:", deployment);
              var row = table.insertRow(1);
              var cell1 = row.insertCell(0);
              var cell2 = row.insertCell(1);
              var cell3 = row.insertCell(2);
              var cell4 = row.insertCell(3);
              cell1.innerHTML = deployment.deployment_id;
              cell2.innerHTML = deployment.active_by;
              cell3.innerHTML = deployment.deployment_status;
              cell4.innerHTML = "<input type='submit' value='View' onclick='document.getElementById(\"deployment_id\").value=\""+deployment.deployment_id+"\"'>";
              row.onclick = function() {
                 console.log("Clicked on", deployment.deployment_id);
                 loadDeploymentInfo(deployment.deployment_id);
              };
           });
        }
    }).catch( function(result){
        //This is where you would put an error callback
    });
}

function loadDeploymentInfo(deployment_id) {
  var params = { deployment_id: deployment_id }
  var body = {}
  var additionalParams = {}

  apigClient.deploymentsDeploymentIdGet(params, body, additionalParams)
    .then(function(result){
        console.log("OK:", result);
        var deployment_info = result.data;
        var table = document.getElementById("DeploymentInfoTable");
        var keys = Object.keys(deployment_info).sort();
        keys.forEach(function(key) {
           if (typeof deployment_info[key] != "object") {
              var row = table.insertRow(-1);
              var cell1 = row.insertCell(0);
              var cell2 = row.insertCell(1);
              cell1.innerHTML = key;
              cell2.innerHTML = deployment_info[key];
           } else {
              // Do nothing
           }
        });
    }).catch( function(result){
        //This is where you would put an error callback
    });
}

//loadDeployments();

function addDeployment(event) {
  event.stopPropagation();
  event.preventDefault();
  console.log("Running addDeployment()");

  var params = {deployment_id: document.getElementById("new_deployment_id").value,
          region: document.getElementById("new_deployment_region").value,
      active_by: document.getElementById("new_deployment_active_by").value,
      active_till: document.getElementById("new_deployment_active_till").value,
      stadium_camera_max: document.getElementById("stadium_camera_max").value,
      virtual_camera_max: document.getElementById("virtual_camera_max").value,
      decode_cluster_size: document.getElementById("decode_cluster_size").value,
      decode_server_type: document.getElementById("decode_server_type").value,
      flink_cluster_size: document.getElementById("flink_cluster_size").value,
      flink_server_type: document.getElementById("flink_server_type").value,
      flink_type: document.getElementById("flink_type").value,
      shared_storage: "",
      software_tags: ""
  };
  console.log(params);
  var body = {
    "active_by": params.active_by,
    "active_till": params.active_till,
    "compute_clusters": {
        "decode": {
            "cluster_size": parseInt(params.decode_cluster_size, 10),
            "server_type": params.decode_server_type
        },
        "fd19_flink": {
            "cluster_size": parseInt(params.flink_cluster_size, 10),
            "server_type": params.flink_server_type,
            "type": params.flink_type
        }
    },
    "cvt": {
        "max_cameras": 19
    },
    "deployment_id": params.deployment_id,
    "region": params.region,
    "shared_storage": {
        "default": {
            "cluster_size": 241,
            "mount_point": "/mnt/lustre",
            "server_type": "i3.16xlarge"
        }
    },
    "software_tags": {
        "decoder_docker": "latest",
        "eks_node_image": "latest",
        "fd19_flink_jar": "latest",
        "flink_docker": "latest",
        "grpc_docker": "latest",
        "metadata_docker": "latest",
        "storage_image": "latest"
    },
    "stadium_cameras": {
        "max_cameras": parseInt(params.stadium_camera_max, 10)
    },
    "virtual_cameras": {
        "max_cameras": parseInt(params.virtual_camera_max, 10),
        "output_s3_bucket": "intel-sports-fd19-us-east-1"
    }
};
  console.log(body);
  var additionalParams = {};

  apigClient.deploymentsPost(params, body, additionalParams)
    .then(function(result){
        console.log("OK:", result);
        location.reload();
    }).catch( function(result){
        //This is where you would put an error callback
    });
}

var submit = document.getElementById("add_deployment");
submit.onclick = addDeployment;

var create_new = document.getElementById("create_deployment");
create_new.onclick = function(event) {
  event.stopPropagation();
  event.preventDefault();

  var form = document.getElementById("deployment_form");
  form.style.display = "block";
  create_new.style.display = "none";
};


