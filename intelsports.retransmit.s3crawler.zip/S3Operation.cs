﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace NewS3Crawler
{
    public class S3Operation
    {
        protected IAmazonS3 s3Client;
        public S3Operation()
        {
            try
            {
                s3Client = new AmazonS3Client(RegionEndpoint.GetBySystemName("us-east-1"));
            }
            catch (Exception exc)
            {
                throw new Exception("Aws Credentials exception", exc);
            }
        }
        public async Task<ListObjectsV2Response> ListBucketFilesAsync(string bucketName, string prefix, string startAfter, int maxKeys)
        {
            ListObjectsV2Request listRequest = new ListObjectsV2Request { BucketName = bucketName, Prefix = prefix, StartAfter = startAfter, MaxKeys = maxKeys };

            // Get a list of objects
            return await s3Client.ListObjectsV2Async(listRequest);
        }
    }
}
