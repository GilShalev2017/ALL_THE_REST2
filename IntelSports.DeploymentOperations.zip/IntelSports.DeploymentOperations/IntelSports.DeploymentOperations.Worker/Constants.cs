﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Worker
{
    public class Constants
    {
        public const string COLUMN_TASK_ID = "Id";
        public const string COLUMN_TASK_PROGRAM_ID = "ODProgramId";
        public const string COLUMN_TASK_PROGRAM_NAME = "ODProgramName";
        public const string COLUMN_TASK_NAME = "Name";
        public const string COLUMN_TASK_DESCRIPTION = "Description";
        public const string COLUMN_TASK_PROGRAM_TO_EXECUTE = "ProgramToExecute";
        public const string COLUMN_TASK_PROGRAM_PARAMETERS = "ProgramParameters";
        public const string COLUMN_TASK_PARAMS = "TaskParameters";
        public const string COLUMN_REPORT_STDOUT = "ReportStandardOutput";
        public const string COLUMN_WORKING_DIRECTORY = "WorkingDirectory";

        public const string COLUMN_PROGRAM_ID = "Id";
        public const string COLUMN_PROGRAM_NAME = "Name";
        public const string COLUMN_PROGRAM_DESCRIPTION = "Description";
        public const string COLUMN_PROGRAM_PACKAGE = "Package";
        public const string COLUMN_PROGRAM_CATEGORY_GROUP = "CategoryGroup";
        public const string COLUMN_PROGRAM_TYPE = "Type";
        public const string COLUMN_PROGRAM_CONFIG_FILE = "ConfigFile";
        public const string COLUMN_PROGRAM_PREREQUISITES = "Prerequisites";
        public const string COLUMN_PROGRAM_IS_PACAKGE_COMPRESSED = "IsPackageCompressed";
        public const string COLUMN_PROGRAM_EXECUTED_PROGRAM = "ExecutedProgram";
        public const string COLUMN_PROGRAM_EXECUTED_PROGRAM_PARAMS = "ExecutedProgramParams";
    }
}
