﻿using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace IntelSports.DeploymentOperations.Worker
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {

                //  Make sure config file is passed as an argument 
                //if (args.Length == 0)
                //{
                //    Console.WriteLine("Config file is missing. Please pass a config file. Exiting");
                //    return;
                //}

                //if (!File.Exists(args[0]))
                //{
                //    Console.WriteLine("The Config File '" + args[0] + "' could not be found. Exiting");
                //    return;
                //}

                // Read Config File. Config file is passed thru project configuration for deubgging.
                // dynamic configFile = JsonConvert.DeserializeObject<dynamic>(File.ReadAllText(args[0]));
                dynamic configFile = new JObject();
                configFile.DeploymentOperationsServerHubURL = "http://63.33.241.11:5000/TaskProcessHub";
                configFile.WaitBeforeRetryConnectingInMilliseconds = 3000;

                Console.WriteLine("configFile.DeploymentOperationsServerHubURL:" + configFile.DeploymentOperationsServerHubURL.ToString());
                Console.WriteLine("configFile.WaitBeforeRetryConnectingInMilliseconds:" + int.Parse(configFile.WaitBeforeRetryConnectingInMilliseconds.ToString()));

                //ExecutionManager executionManager = new ExecutionManager();
                //executionManager.DownloadAllMissingPrograms();
                

                AutoResetEvent resetEvent = new AutoResetEvent(false);
                WorkerHubClient workerHubClient = new WorkerHubClient(configFile, resetEvent);
                var task = workerHubClient.Start();
                task.Wait();


                if (workerHubClient.hubConnection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
                {
                    Console.WriteLine("Docker running. Press any key to stop it.");           
                    resetEvent.WaitOne();
                }
                
                if (workerHubClient.hubConnection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Disconnected)
                {                    
                    while(workerHubClient.hubConnection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Disconnected)
                    {
                        Console.WriteLine("Retrying to connect again after waiting " + int.Parse(configFile.WaitBeforeRetryConnectingInMilliseconds.ToString()) + " MilliSeconds...");
                        var delayTask = Task.Delay(int.Parse(configFile.WaitBeforeRetryConnectingInMilliseconds.ToString()));
                        delayTask.Wait();
             
                        var retryTask = workerHubClient.Start();
                        retryTask.Wait();
                        if (workerHubClient.hubConnection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
                        {
                            Console.WriteLine("Docker running. Press any key to stop it.");
                            resetEvent.WaitOne();
                        }

                    }
                }
            }
            catch (Exception exc)
            {
                Console.WriteLine(exc.Message);
                if (exc.InnerException != null)
                {
                    Console.WriteLine(exc.InnerException.Message);
                }
            }
        }
    }
}
