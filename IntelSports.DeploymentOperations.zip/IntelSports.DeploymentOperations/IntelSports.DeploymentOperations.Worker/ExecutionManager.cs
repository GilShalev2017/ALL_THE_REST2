﻿using Amazon;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using IntelSports.DeploymentOperations.Model.DB;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;

namespace IntelSports.DeploymentOperations.Worker
{
    public class ExecutionManager
    {
        
        private List<ODProgram> _odPrograms;
        private List<ODTask> _odTasks;
        private Dictionary<string, ODTask> _odTasksById;
        private Dictionary<string, ODProgram> _odProgramsById;

        //The following should be retreived from configuration
        private string _installationDirectory = "./ODProgramsFolder";
        private string _programsTableName = "operational-docker-programs";
        private string _tasksTableName = "operational-docker-tasks";
        private string _region = "eu-west-1";
        private string _programsS3Bucket = "fd-controller-appliaction-bucket";
        private string _accessKeyId = "AKIAJAOGGOPNYW7WJUUQ";
        private string _secretAccessKey = "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";
        public ExecutionManager()
        {
            CreateProgramAndTaskCollections();

            CreateDestinationDirectories();
        }

        private void CreateDestinationDirectories()
        {
            if(!Directory.Exists(_installationDirectory))
            {
                Directory.CreateDirectory(_installationDirectory);
            }

            foreach (string categoryName in Enum.GetNames(typeof(CategoryGroup)))
            {
                var destinationDirectory = string.Format("{0}/{1}",_installationDirectory, categoryName);
                
                if (!Directory.Exists(destinationDirectory))
                {
                    Directory.CreateDirectory(destinationDirectory);
                }
            }
        }

        private void CreateProgramAndTaskCollections()
        {
            _odPrograms = GetProgramList();
            _odTasks = GetTaskList();
            _odTasksById = _odTasks.ToDictionary(x => x.Id, x => x);
            _odProgramsById = _odPrograms.ToDictionary(x => x.Id, x => x);
        }

        public List<ODTask> GetTaskList()
        {
            var dynamoDbClient = new AmazonDynamoDBClient(RegionEndpoint.GetBySystemName(_region));

            ScanResponse result;

            var req = new ScanRequest
            {
                TableName = _tasksTableName
            };

            result = dynamoDbClient.ScanAsync(req).Result;
                        
            List<ODTask> list = new List<ODTask>();

            foreach (var item in result.Items)
            {
                ODTask task = new ODTask
                {
                    Id = item[Constants.COLUMN_TASK_ID].S,
                    Name = item[Constants.COLUMN_TASK_NAME].S,
                    ODProgramId = item[Constants.COLUMN_TASK_PROGRAM_ID].S,
                    ODProgramName = item[Constants.COLUMN_TASK_PROGRAM_NAME].S,
                };

                if (item.ContainsKey(Constants.COLUMN_TASK_DESCRIPTION))
                {
                    task.Description = item[Constants.COLUMN_TASK_DESCRIPTION].S;
                }

                if (item.ContainsKey(Constants.COLUMN_TASK_PARAMS))
                {
                    task.TaskParameters = item[Constants.COLUMN_TASK_PARAMS].S;
                }

                if (item.ContainsKey(Constants.COLUMN_WORKING_DIRECTORY))
                {
                    task.WorkingDirectory = item[Constants.COLUMN_WORKING_DIRECTORY].S;
                }

                task.ReportStandardOutput = item[Constants.COLUMN_REPORT_STDOUT].S.ToLower() == "true" ? true : false;

                list.Add(task);
            }

            return list;
        }

        public List<ODProgram> GetProgramList()
        {
            var dynamoDbClient = new AmazonDynamoDBClient(RegionEndpoint.GetBySystemName(_region));

            ScanResponse result;

            var req = new ScanRequest
            {
                TableName = _programsTableName
            };

            result = dynamoDbClient.ScanAsync(req).Result;

            List<ODProgram> list = new List<ODProgram>();

            foreach (var item in result.Items)
            {
                ODProgram odp = new ODProgram
                {
                    Id = item[Constants.COLUMN_PROGRAM_ID].S,
                    Name = item[Constants.COLUMN_PROGRAM_NAME].S,
                    Description = item[Constants.COLUMN_PROGRAM_DESCRIPTION].S,
                    Package = item[Constants.COLUMN_PROGRAM_PACKAGE].S,
                    ExecutedProgram = item[Constants.COLUMN_PROGRAM_EXECUTED_PROGRAM].S,
                    ExecutedProgramParams = item[Constants.COLUMN_PROGRAM_EXECUTED_PROGRAM_PARAMS].S,
                };

                if (item.ContainsKey(Constants.COLUMN_PROGRAM_CONFIG_FILE))
                {
                    var configurationFile = item[Constants.COLUMN_PROGRAM_CONFIG_FILE].S;
                    odp.ConfigurationFile = configurationFile;
                }

                if (item.ContainsKey(Constants.COLUMN_PROGRAM_PREREQUISITES))
                {
                    var prereqisites = item[Constants.COLUMN_PROGRAM_PREREQUISITES].S;
                    var splits = prereqisites.Split(",");

                    if (splits != null)
                    {
                        odp.Prerequisites = new List<Prerequisite>();

                        foreach (string split in splits)
                        {
                            if (Enum.TryParse(split, out Prerequisite parsedPrerequisite))
                            {
                                odp.Prerequisites.Add(parsedPrerequisite);
                            }
                        }
                    }
                }

                if (bool.TryParse(item[Constants.COLUMN_PROGRAM_IS_PACAKGE_COMPRESSED].S, out bool parsedIsCompressed))
                {
                    odp.IsPackageCompressed = parsedIsCompressed;
                }

                if (Enum.TryParse(item[Constants.COLUMN_PROGRAM_CATEGORY_GROUP].S, out CategoryGroup parsedCategoryGroup))
                {
                    odp.CategoryGroup = parsedCategoryGroup;
                }

                list.Add(odp);
            }

            return list;
        }

        public void DownloadAllMissingPrograms()
        {
            foreach (var program in _odPrograms)
            {
                if (IsProgramMissing(program))
                {
                    DownloadProgram(program);

                    if(program.IsPackageCompressed)
                    {
                        UncompressPackage(program);
                    }
                }
            }
        }

        private void UncompressPackage(ODProgram program)
        {
            string sourceArchiveFileName = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, program.CategoryGroup, program.Name, program.Package);
                
            string destinationDirectoryName = string.Format("{0}/{1}/{2}", _installationDirectory, program.CategoryGroup, program.Name);

            ZipFile.ExtractToDirectory(sourceArchiveFileName, destinationDirectoryName);
        }

        private void DownloadProgram(ODProgram program)
        {
            var filePath = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, program.CategoryGroup, program.Name, program.Package);

            var destinationDirectory = string.Format("{0}/{1}/{2}", _installationDirectory, program.CategoryGroup, program.Name);

            if (!Directory.Exists(destinationDirectory)) //Does it create 2 dirs at once?
            {
                Directory.CreateDirectory(destinationDirectory);
            }

            var s3FileKey = string.Format("{0}/{1}/{2}", program.CategoryGroup, program.Name, program.Package);

            TransferUtility fileTransferUtility = new TransferUtility(new AmazonS3Client(_accessKeyId, _secretAccessKey, RegionEndpoint.GetBySystemName(_region)));
            
            fileTransferUtility.Download(filePath, _programsS3Bucket, s3FileKey);
        }

        public bool IsProgramMissing(ODProgram program)
        {
            var destinationFolder = string.Format("{0}/{1}/{2}", _installationDirectory,program.CategoryGroup,program.Name);

            //var destinationFile = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, program.CategoryGroup, program.Name,program.Package);
            
            //TODO complete: need to find if application/script is there too
            if (!Directory.Exists(destinationFolder))
                return true;

            return false;
        }

        public ODTask GetTaskToRun(string taskId)
        {
            var odTask = _odTasksById[taskId];

            if (odTask != null)
            {
                var odProgram = _odProgramsById[odTask.ODProgramId];
                if (odProgram == null)
                    return null;

                //Download program if it doesn't exist
                if(IsProgramMissing(odProgram))
                {
                    DownloadProgram(odProgram);

                    if (odProgram.IsPackageCompressed)
                    {
                        UncompressPackage(odProgram);
                    }
                }

                //C:\Program Files\dotnet\dotnet.exe
                //C:\NotInUseTatsProjects\DemoApp\bin\Debug\netcoreapp2.2\DemoApp.dll 2000 3000 30
                //odTask.ProgramParameters = "DemoApp.dll 2000 3000 30";

                var workerDir = Directory.GetCurrentDirectory();
                var installationDirName = _installationDirectory.Replace("./", "");
                var relativePath = string.Format(@"{0} {1}", odProgram.ExecutedProgramParams, odTask.TaskParameters);
                var appFullFolderPath = string.Format(@"{0}\{1}\{2}\{3}\", workerDir, installationDirName, odProgram.CategoryGroup, odProgram.Name);
                //Pay attention to the needed whitespace between the ExecutedProgramParams & TaskParameters
                var appFullPath = string.Format(@"{0}{1} {2}", appFullFolderPath, odProgram.ExecutedProgramParams, odTask.TaskParameters);
                
                odTask.ProgramToExecute = odProgram.ExecutedProgram;

                //probably WorkingDirectory set to appFullFolderPath is always needed
                odTask.WorkingDirectory = appFullFolderPath;

                // option 1 - full path
                odTask.ProgramParameters = appFullPath;

                // option 2 - relative path + WorkingDirectory
                odTask.ProgramParameters = relativePath;
               

                return odTask;
            }

            return null;
        }

        //public DeploymentTask GetDeploymentTask(string taskId)
        //{
        //    // should be read from configuration
        //    var AwsRegion = "eu-west-1";
        //    var DynamoDbTable = "tasks2";

        //    var dynamoDbClient = new AmazonDynamoDBClient(RegionEndpoint.GetBySystemName(AwsRegion));

        //    Dictionary<string, AttributeValue> key = new Dictionary<string, AttributeValue>
        //    {
        //        { TASK_ID_COL, new AttributeValue(taskId) }
        //    };

        //    GetItemResponse response = dynamoDbClient.GetItemAsync(DynamoDbTable, key).Result;

        //    if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
        //    {
        //        DeploymentTask task = new DeploymentTask
        //        {
        //            Id = response.Item[TASK_ID_COL].S,
        //            Name = response.Item[TASK_NAME_COL].S,
        //            ProgramToExecute = response.Item[EXECUTED_PROGRAM_COL].S,
        //        };

        //        if (response.Item.ContainsKey(EXECUTED_PROGRAM_PARAMS_COL))
        //        {
        //            task.ProgramParameters = response.Item[EXECUTED_PROGRAM_PARAMS_COL].S;
        //        }

        //        if (response.Item.ContainsKey(TASK_DESCRIPTION_COL))
        //        {
        //            task.Description = response.Item[TASK_DESCRIPTION_COL].S;
        //        }

        //        if (response.Item.ContainsKey(WORKING_DIRECTORY_COL))
        //        {
        //            task.WorkingDirectory = response.Item[WORKING_DIRECTORY_COL].S;
        //        }

        //        //TODO could be true or True
        //        task.ReportStandardOutput = response.Item[REPORT_STDOUT_COL].S.ToLower() == "true" ? true : false;

        //        return task;
        //    }
        //    else
        //        return null;
        //}
    }
}


//Alternative Way to download from S3
/*
public void DownloadObject(string imagename)
{
    RegionEndpoint bucketRegion = RegionEndpoint.USEast1;
    
    IAmazonS3 client = new AmazonS3Client(bucketRegion);

    string accessKey = System.Configuration.ConfigurationManager.AppSettings["AWSAccessKey"];
    string secretKey = System.Configuration.ConfigurationManager.AppSettings["AWSSecretKey"];
    AmazonS3Client s3Client = new AmazonS3Client(new BasicAWSCredentials(accessKey, secretKey), Amazon.RegionEndpoint.USEast1);
    string objectKey = "EMR" + "/" + imagename;
    //EMR is folder name of the image inside the bucket 
    GetObjectRequest request = new GetObjectRequest();
    request.BucketName = System.Configuration.ConfigurationManager.AppSettings["bucketname"];
    request.Key = objectKey;
    GetObjectResponse response = s3Client.GetObject(request);
    response.WriteResponseStreamToFile("D:\\Test\\" + imagename);
}
*/