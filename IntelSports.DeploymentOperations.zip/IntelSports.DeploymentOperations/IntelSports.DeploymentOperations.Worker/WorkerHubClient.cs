﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using IntelSports.DeploymentOperations.Model;
using IntelSports.DeploymentOperations.Model.DB;
using Microsoft.AspNetCore.SignalR.Client;

namespace IntelSports.DeploymentOperations.Worker
{
    public class WorkerHubClient
    {
        public HubConnection hubConnection = null;
        private Action<string> onRegisteredWorker = null;
        private Action<string> onStartTask = null;
        private Action<string> onStopTask = null;
        
        private dynamic configFile = null;
        private AutoResetEvent resetEvent;

        private Dictionary<string, ITaskExecuter> _executers = new Dictionary<string, ITaskExecuter>();

        public WorkerHubClient(dynamic configFile, AutoResetEvent resetEvent)
        {
            this.configFile = configFile;
            this.resetEvent = resetEvent;
            onRegisteredWorker = new Action<string>(OnRegisteredWorkerHandler);
            onStartTask = new  Action<string>(OnStartTaskHandler);
            onStopTask = new Action<string>(OnStopTaskHandler);
        }

        public async Task Start()
        {
            try
            {
                string serverUrl = this.configFile.DeploymentOperationsServerHubURL;
                hubConnection = new HubConnectionBuilder().WithUrl(serverUrl).Build();
                hubConnection.On<string>("OnRegisteredWorkerStatus", onRegisteredWorker);
                hubConnection.On<string>("StartTask", onStartTask);
                hubConnection.On<string>("StopTask", onStopTask);


                //  On Closed Connection
                hubConnection.Closed += HubConnection_Closed;

                //  Start the connection
                await hubConnection.StartAsync();

                //  Register with Server Hub
                await hubConnection.SendAsync("RegisterWorker");
            }
            catch(Exception exc)
            {
                Console.WriteLine("WorkerHubClient.Start:" + exc.Message);
                
            }
        }       

        public void OnRegisteredWorkerHandler(string status)
        {
            Console.WriteLine("OnRegisterTaskExecuter Status: " + status);
        }

        public void OnStartTaskHandler(string taskId)
        {                
            Console.WriteLine("Starting Process to execute Task Id: " + taskId);

            // SHOULD BE MOVED TO EXECUTION MANAGER  !!!
            // Also for every execution a new ExecutionManager is being created which means bringing all the tasks and programs over and over again

            ExecutionManager manager = new ExecutionManager();
            ODTask deploymentTask = manager.GetTaskToRun(taskId);

            string executerId = Guid.NewGuid().ToString();
            ITaskExecuter taskExecuter = new SystemProcessTaskExecuter(this.configFile.DeploymentOperationsServerHubURL.ToString(), taskId, executerId);
            _executers.Add(executerId, taskExecuter);

            var taskResult = taskExecuter.ExecuteTask(deploymentTask);
        }

        public void OnStopTaskHandler(string executerId)
        {
            // SHOULD BE MOVED TO EXECUTION MANAGER !!!
            Console.WriteLine("Trying to stop Executer with Id: " + executerId);

            if(_executers.ContainsKey(executerId))
            {
                ITaskExecuter executer = _executers[executerId];
                if(executer != null)
                {
                    executer.StopTask();
                }

                //TODO consider keeping it and removing only if process stopped
                //Listen to process end (exit/terminated ...) and remove from _executers
                _executers.Remove(executerId);
            }
        }
        

        private Task HubConnection_Closed(Exception exc)
        {
            Console.WriteLine("HubConnection_Closed: Hub connection has been closed " + exc);

            resetEvent.Set();
            return Task.FromResult("");
        }

    }
}
