﻿
using IntelSports.DeploymentOperations.Model.DB;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace IntelSports.DeploymentOperations.ServerHub.Hubs
{
    public class TaskProcessHub : Hub<IWorkerClient>
    {
        public TaskProcessHub()
        {

        }

        #region Worker commands
        public async Task RegisterWorker()
        {
            Console.WriteLine("Worker client registering on Server.");

            await Groups.AddToGroupAsync(Context.ConnectionId, "WorkerClients");

            //  Reply to the currently registering client (TaskExecuterClient)
            //await Clients.Caller.SendAsync("OnRegisterTaskExecuter", "Success");
            await Clients.Caller.OnRegisteredWorkerStatus("Success");
        }

        #endregion Worker commands

        #region Worker Notifications To Propagate to client
        public async Task ExecutingTaskStatus(ExecutingTaskStatus executingTaskStatus)
        {
            Console.WriteLine("TaskExecuterHubClient sending executing task status.");

            // Notify all UIs
            //For the sake of the UI fill the status as String - remove later
            executingTaskStatus.StatusString = executingTaskStatus.Status.ToString();

            await Clients.Group("UIClients").OnTaskStatusReport(executingTaskStatus);

            //TODO is it really needed to send to calling client - like???
            //    await Clients.Caller.OnTaskXXX("Success");
            //await Clients.Caller.OnTaskStartingStatus("Success");
        }

        public async Task OutputDataReceived(string executerId, string data)
        {
            Console.WriteLine("Task Execution Process SignalR of receiving StdOut.");

            // Notify all UIs
            await Clients.Group("UIClients").OutputDataReceived(executerId, data);
        }

        #endregion Worker Notifications To Propagate to Client

        #region UI commands
        public async Task RegisterUI()
        {
            Console.WriteLine("Server Hub received request from UI client to Register UI ");

            await Groups.AddToGroupAsync(Context.ConnectionId, "UIClients");
            
            await Clients.Caller.OnUIRegisteredStatus("Success");
        }

        public async Task StartTask(string taskId)
        {
            Console.WriteLine("Server Hub received request from client to StartTask with id:" + taskId);

            //  ToDo: What if the group "WorkerClients" is empty. Needs handling
            await Clients.Group("WorkerClients").StartTask(taskId);
        }

        public async Task StopTask(string executerId)
        {
            Console.WriteLine("Server Hub received request from client to Stop Process through executer with Id:" + executerId);

            await Clients.Group("WorkerClients").StopTask(executerId);
        }

        #endregion UI commands

        public async Task StopTaskCompleted()
        {
            Console.WriteLine("Server Hub received: StopTaskCompleted ");

            // Notify all UIs that Stop
            await Clients.Group("UIClients").StopTaskCompleted();
        }

        #region Hub inner notifications
        public override async Task OnConnectedAsync()
        {
            Console.WriteLine("Connection Id: " + Context.ConnectionId + " has been established");
            await base.OnConnectedAsync();
        }

        public override async Task OnDisconnectedAsync(Exception exception)
        {
            Console.WriteLine("Connection Id: " + Context.ConnectionId + " has been disconnected");
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, "WorkerClients");
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, "UIClients");        
            await base.OnDisconnectedAsync(exception);
        }
        #endregion
    }
}

//switch (executingTaskStatus.Status) //TO send specific events instead of one general
//{
//    case StatusOptions.TaskStarting:
//        await Clients.Group("UIClients").TaskStarting(executingTaskStatus);
//        break;
//    case StatusOptions.TaskStarted:
//        await Clients.Group("UIClients").TaskStarted(executingTaskStatus);
//        break;
//    case StatusOptions.TaskCompleted:
//        await Clients.Group("UIClients").TaskCompleted(executingTaskStatus);
//        break;
//    case StatusOptions.TaskCompletedWithError:
//        await Clients.Group("UIClients").TaskCompletedWithError(executingTaskStatus);
//        break;
//    case StatusOptions.ProcessExited:
//        await Clients.Group("UIClients").ProcessExited(executingTaskStatus);
//        break;
//    case StatusOptions.ErrorDataReceived:
//        await Clients.Group("UIClients").ErrorDataReceived(executingTaskStatus);
//        break;
//    case StatusOptions.TaskStopped:
//        await Clients.Group("UIClients").TaskStopped(executingTaskStatus);
//        break;
//    case StatusOptions.TaskStoppedError:
//        await Clients.Group("UIClients").TaskStoppedError(executingTaskStatus);
//        break;
//}


//public async Task TaskStarting(string taskId)
//{
//    Console.WriteLine("TaskExecuterHubClient Signaling that it's starting");

//    // Notify all UIs
//    await Clients.Group("UIClients").TaskStarting(taskId);

//    //  Reply to the currently registering client (TaskExecuterHubClient)       
//    await Clients.Caller.OnTaskStartingStatus("Success");

//}

//public async Task TaskStarted(string taskId)
//{
//    Console.WriteLine("TaskExecuterHubClient Signaling that it has started");

//    // Notify all UIs
//    await Clients.Group("UIClients").TaskStarted(taskId);

//    //  Reply to the currently registering client (TaskExecuterHubClient)       
//    await Clients.Caller.OnTaskStartedStatus("Success");

//}

//public async Task TaskCompleted(string taskId)
//{
//    Console.WriteLine("Task Execution Process SignalR client reported that task has completed.");

//    // Notify all UIs
//    await Clients.Group("UIClients").TaskCompleted(taskId);

//    //  Reply to the currently registering client (TaskExecuterHubClient)       
//    await Clients.Caller.OnTaskCompletedStatus("Success");

//}

//public async Task OnStdOutReceived(string message, int processId)
//{
//    Console.WriteLine("Task Execution Process SignalR of receiving StdOut.");

//    // Notify all UIs
//    await Clients.Group("UIClients").OnStdOutReceived(message, processId);
//}