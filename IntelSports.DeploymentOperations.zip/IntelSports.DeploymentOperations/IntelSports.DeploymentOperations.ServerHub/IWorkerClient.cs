﻿using IntelSports.DeploymentOperations.Model.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IntelSports.DeploymentOperations.ServerHub
{
    public interface IWorkerClient
    {
        #region UI commands (what can the UI command)

        Task StartTask(string taskId);
        Task StopTask(string executerId);

        #endregion

        #region UI notifications (what will the UI receive)
        Task OnUIRegisteredStatus(string status);

        Task OnTaskStatusReport(ExecutingTaskStatus executingTaskStatus);

        Task OutputDataReceived(string executerId, string data);
        
        #endregion UI notifications

        #region Worker notifications (what will the Worker receive)
        Task OnRegisteredWorkerStatus(string status);
        #endregion

        Task StopTaskCompleted();
    }
}
//Task OnTaskStartingStatus(string status);
//Task OnTaskStartedStatus(string status);
//Task OnTaskCompletedStatus(string status);

//Task TaskStarting(ExecutingTaskStatus executingTaskStatus);
//Task TaskStarted(ExecutingTaskStatus executingTaskStatus);
//Task TaskCompleted(ExecutingTaskStatus executingTaskStatus);
//Task TaskCompletedWithError(ExecutingTaskStatus executingTaskStatus);
//Task ProcessExited(ExecutingTaskStatus executingTaskStatus);
//Task ErrorDataReceived(ExecutingTaskStatus executingTaskStatus);
//Task TaskStopped(ExecutingTaskStatus executingTaskStatus);
//Task TaskStoppedError(ExecutingTaskStatus executingTaskStatus);