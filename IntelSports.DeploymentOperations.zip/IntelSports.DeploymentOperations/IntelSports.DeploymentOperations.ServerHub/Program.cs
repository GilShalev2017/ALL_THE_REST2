using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace IntelSports.DeploymentOperations.ServerHub
{
    public class Program
    {
        public static void Main(string[] args)
        {

            CreateHostBuilder(args).Build().Run();

        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)           
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.ConfigureKestrel(serverOptions =>
                {
                    serverOptions.Listen(IPAddress.Parse("0.0.0.0"), 5000);

                    // uncomment the next lines when ready to work with SSL
                    //serverOptions.Listen(IPAddress.Parse("0.0.0.0"), 5002,
                    //listenOptions =>
                    //{
                    //    listenOptions.UseHttps("cert1", "abc1234");
                    //});

                }).UseStartup<Startup>();
            });
    }
}
