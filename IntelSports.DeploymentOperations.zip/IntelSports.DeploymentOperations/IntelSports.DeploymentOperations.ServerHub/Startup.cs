using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using IntelSports.DeploymentOperations.ServerHub.Hubs;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace IntelSports.DeploymentOperations.ServerHub
{
    public class Startup
    {
        readonly string MyAllowSpecificOriginsPolicy = "_myAllowSpecificOrigins";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {            
            services.AddRazorPages();
            services.AddSignalR();
            //services.AddCors(options =>
            //{
            //    options.AddPolicy(MyAllowSpecificOriginsPolicy,
            //    builder =>
            //    {
                    
            //        builder.WithOrigins(Configuration.GetValue<string>("AllowedCORSDomains").Split(','));
            //    });
            //});

            services.AddCors(o => o.AddPolicy("CorsPolicy", builder =>
            {
                builder
                .AllowAnyMethod()
                .AllowAnyHeader()
                .AllowCredentials()
                //.AllowAnyOrigin()
                .WithOrigins("http://taskautomationtoolsy-bucket-developmen.s3-website.us-east-2.amazonaws.com", "http://localhost:4200", "http://localhost:1111", "http://localhost:2222");
            }));

            //services.AddHttpsRedirection(options =>
            //{
            //    options.RedirectStatusCode = StatusCodes.Status307TemporaryRedirect;
            //    options.HttpsPort = 5001;
            //});
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

           // Uncomment when ready to work with SSL
            // app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.UseCors("CorsPolicy");// MyAllowSpecificOriginsPolicy);

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapRazorPages();
                endpoints.MapHub<TaskProcessHub>("/TaskProcessHub");
            });
        }
    }
}
