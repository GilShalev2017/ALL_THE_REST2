﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace IntelSports.DeploymentOperations.ServerHub.Hubs
{
    public class TaskProcessHub : Hub<IWorkerClient>
    {
        public TaskProcessHub()
        {

        }

        public async Task RegisterWorker()
        {
            Console.WriteLine("Worker client registering on Server.");

            await Groups.AddToGroupAsync(Context.ConnectionId, "WorkerClients");

            //  Reply to the currently registering client (TaskExecuterClient)
            //await Clients.Caller.SendAsync("OnRegisterTaskExecuter", "Success");
            await Clients.Caller.OnRegisteredWorkerStatus("Success");
        }


        public async Task TaskStarting()
        {
            Console.WriteLine("TaskExecuterHubClient Signaling that it's starting");

            // Notify all UIs
            await Clients.Group("UIClients").TaskStarting();

            //  Reply to the currently registering client (TaskExecuterHubClient)       
            await Clients.Caller.OnTaskStartingStatus("Success");

        }

        public async Task TaskStarted()
        {
            Console.WriteLine("TaskExecuterHubClient Signaling that it has started");

            // Notify all UIs
            await Clients.Group("UIClients").TaskStarted(Context.ConnectionId);

            //  Reply to the currently registering client (TaskExecuterHubClient)       
            await Clients.Caller.OnTaskStartedStatus("Success");

        }

        public async Task TaskCompleted()
        {
            Console.WriteLine("Task Execution Process SignalR client reported that task has completed.");

            // Notify all UIs
            await Clients.Group("UIClients").TaskCompleted();

            //  Reply to the currently registering client (TaskExecuterHubClient)       
            await Clients.Caller.OnTaskCompletedStatus("Success");

        }

        public async Task RegisterUI()
        {
            Console.WriteLine("Server Hub received request from UI client to Register UI ");

            await Groups.AddToGroupAsync(Context.ConnectionId, "UIClients");
            await Clients.Caller.OnUIRegisteredStatus("Success");
        }

        public async Task StartTask(int taskId)
        {
            Console.WriteLine("Server Hub received request from client to StartTask with id:" + taskId);

            //  ToDo: What if the group "WorkerClients" is empty. Needs handling
            await Clients.Group("WorkerClients").StartTask(taskId);
        }

        public async Task StopTask(string connectionId)
        {
            Console.WriteLine("Server Hub received request from clien to Stop Process with connection Id:" + connectionId);
            await Clients.Client(connectionId).StopTask();
        }

        public async Task StopTaskCompleted()
        {
            Console.WriteLine("Server Hub received: StopTaskCompleted ");

            // Notify all UIs that Stop
            await Clients.Group("UIClients").StopTaskCompleted();
        }


        public override async Task OnConnectedAsync()
        {
            Console.WriteLine("Connection Id: " + Context.ConnectionId + " has been established");
            await base.OnConnectedAsync();
        }

        public override async Task OnDisconnectedAsync(Exception exception)
        {
            //await Groups.RemoveFromGroupAsync(Context.ConnectionId, "WorkerClients");
            Console.WriteLine("Connection Id: " + Context.ConnectionId + " has been disconnected");
            await base.OnDisconnectedAsync(exception);
        }
    }
}