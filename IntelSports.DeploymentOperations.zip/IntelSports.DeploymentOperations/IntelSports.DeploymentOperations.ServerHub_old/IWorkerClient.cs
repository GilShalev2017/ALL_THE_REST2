﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IntelSports.DeploymentOperations.ServerHub
{
    public interface IWorkerClient
    {
        Task StartTask(int taskId);
        Task StopTask();
        Task OnRegisteredWorkerStatus(string status);
        Task OnTaskStartingStatus(string status);
        Task OnTaskStartedStatus(string status);
        Task TaskStarting();
        Task TaskStarted(string connectionId);
        Task TaskCompleted();
        Task OnUIRegisteredStatus(string status);
        Task OnTaskCompletedStatus(string status);
        Task StopTaskCompleted();

    }
}
