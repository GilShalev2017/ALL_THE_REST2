﻿using Microsoft.AspNetCore.SignalR.Client;
using System;
using System.Threading.Tasks;

namespace SignalRClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            var task = Test();
            task.Wait();

            Console.ReadKey();

        }

        public static async Task Test()
        {
            
            HubConnection connection = new HubConnectionBuilder()
                .WithUrl("https://localhost:44398//chatHub")
                .Build();
     
            await connection.StartAsync();
            await connection.InvokeAsync("SendMessage", "test1", "testing thignfsdf");

        }
    }
}
