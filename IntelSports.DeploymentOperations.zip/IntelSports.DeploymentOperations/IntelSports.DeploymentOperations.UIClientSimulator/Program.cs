﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR.Client;

namespace IntelSports.DeploymentOperations.UIClientSimulator
{
    class Program
    {
        static void Main(string[] args)
        {

            // HubConnection connection = new HubConnectionBuilder().WithUrl("https://localhost:5002/TaskProcessHub").Build();
            //HubConnection connection = new HubConnectionBuilder().WithUrl("http://63.33.241.11:5000/TaskProcessHub").Build();
            //HubConnection connection = new HubConnectionBuilder().WithUrl("http://ec2-34-245-25-97.eu-west-1.compute.amazonaws.com:5000/FPSReportingHub").Build();
            HubConnection connection = new HubConnectionBuilder().WithUrl("http://localhost:54797/TaskProcessHub").Build();

            //  On Recieving Message
            connection.On<string, string>("ReceiveMessage", (user, message) =>
            {
                Console.WriteLine(user + ": "+ message);
            });


            connection.On("TaskStarting", () =>
            {
                Console.WriteLine("TaskStarting");
            });


            connection.On<string>("TaskStarted", (connectionId) =>
            {
                Console.WriteLine("TaskStarted: " + connectionId);

                //  stop proccess
                var stopTask = connection.InvokeAsync("StopTask", connectionId);
                stopTask.Wait();

            });


            connection.On("TaskCompleted", () =>
            {
                Console.WriteLine("TaskCompleted:");
            });



            connection.On("StopTaskCompleted", () =>
            {
                Console.WriteLine("StopTaskCompleted");
            });

            

            connection.On<string>("OnUIRegisteredStatus", (status) =>
            {
                Console.WriteLine("OnUIRegisteredStatus:" + status);
            });


            

            
            //  On Closed Connection
            connection.Closed += async (error) =>
            {
                await Task.Delay(new Random().Next(0, 5) * 1000);
                await connection.StartAsync();
            };

         

            var task = connection.StartAsync();
            task.Wait();

            //  delete later
            var sendTask11 = connection.InvokeAsync("RegisterAsLogsDataPublisher");



            /// Tell the server that u are a UI client
            var registerUI = connection.InvokeAsync("RegisterUI");
            registerUI.Wait();

            
            // Register with Server Hub. All cliets must do so, wether they have called StartTask or not
            var sendTask = connection.InvokeAsync("StartTask", 100);
            sendTask.Wait();

           

           // var stopTask = connection.InvokeAsync("StopTask", 100);
           // stopTask.Wait();
            Console.ReadKey();
            
        }
    }
}
