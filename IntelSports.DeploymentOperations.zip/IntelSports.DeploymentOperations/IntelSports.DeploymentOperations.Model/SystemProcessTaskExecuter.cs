﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using IntelSports.DeploymentOperations.Model.DB;

namespace IntelSports.DeploymentOperations.Model
{
    public class SystemProcessTaskExecuter : ITaskExecuter
    {
        protected TaskExecuterHubClient taskExecuterHubClient = null;

        public string _taskId;
        public string _executerId;
        public Process process = null;
        private ExecutingTaskStatus _executingTaskStatus;

        public SystemProcessTaskExecuter(string serverHubUrl, string taskId, string executerId)
        {
            taskExecuterHubClient = new TaskExecuterHubClient(serverHubUrl, this);
            _taskId = taskId;
            _executerId = executerId;
            _executingTaskStatus = new ExecutingTaskStatus {TaskId= taskId, ExecuterId = executerId };
        }

        public async Task<ExecutingTaskStatus> ExecuteTask(ODTask task)
        {           
            return await ExecuteDeploymentTask(task);           
        }

        private async Task<ExecutingTaskStatus> ExecuteDeploymentTask(ODTask task)
        {
            try
            {
                process = new Process();
                process.StartInfo.FileName = task.ProgramToExecute;
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardError = true;
                process.StartInfo.UseShellExecute = false;
                process.EnableRaisingEvents = true;
                process.StartInfo.Arguments = task.ProgramParameters;

                if (task.ReportStandardOutput)
                {
                    process.Exited += Process_Exited;
                    process.OutputDataReceived += new DataReceivedEventHandler(Process_OutputDataReceived);
                    process.ErrorDataReceived += new DataReceivedEventHandler(Process_ErrorDataReceived);
                }

                if (!string.IsNullOrEmpty(task.WorkingDirectory))
                {
                    process.StartInfo.WorkingDirectory = task.WorkingDirectory;
                }

                _executingTaskStatus.Status = StatusOptions.TaskStarting;
                await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);

                process.Start();

                _executingTaskStatus.Status = StatusOptions.TaskStarted;
                _executingTaskStatus.StartDateTime = DateTime.Now;
                await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);

                process.BeginErrorReadLine();
                process.BeginOutputReadLine();
                process.WaitForExit();

                _executingTaskStatus.EndDateTime = DateTime.Now;

                if (_executingTaskStatus.Status != StatusOptions.TaskStopped)
                {
                    if (!string.IsNullOrEmpty(_executingTaskStatus.ErrorData))
                    {
                        _executingTaskStatus.Status = StatusOptions.TaskCompletedWithError;
                    }
                    else
                    {
                        _executingTaskStatus.Status = StatusOptions.TaskCompleted;
                    }
                }

                if (taskExecuterHubClient.connection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
                {
                    await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);

                    await taskExecuterHubClient.Disconnect();
                }

                return _executingTaskStatus;
            }
            catch(Exception xcp)
            {
                _executingTaskStatus.EndDateTime = DateTime.Now;
                _executingTaskStatus.Status = StatusOptions.TaskCompletedWithError;
                _executingTaskStatus.ErrorData = xcp.Message;
                
                if (taskExecuterHubClient.connection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
                {
                    await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);
                    await taskExecuterHubClient.Disconnect();
                }
                Console.WriteLine("Exception occuured at ExecuteDeploymentTask: " + xcp.Message);
            }

            return _executingTaskStatus;
        }
        private async void Process_Exited(object sender, EventArgs e)
        {
            Console.WriteLine("Process Exited");

            if (_executingTaskStatus.Status != StatusOptions.TaskStopped)
            {
                _executingTaskStatus.Status = StatusOptions.ProcessExited;
            }

            if (taskExecuterHubClient.connection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
            {
                await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);
            }
        }

        private async void Process_ErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            Console.WriteLine("From 'Process_ErrorDataReceived' :" + e.Data);

            if (!string.IsNullOrEmpty(e.Data))
            {
                _executingTaskStatus.Status = StatusOptions.ErrorDataReceived;
                _executingTaskStatus.ErrorData = e.Data;
                //Find out if this means that the process failed ??? or it can send other statuses after this one?

                if (taskExecuterHubClient.connection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
                {
                    await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);
                }
            }
        }

        private async void Process_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            try
            {
                Console.WriteLine("From EXECUTER: " + _executerId + " PROCESS_ID: " + process.Id + " Process_OutputDataReceived: " + e.Data);

                if (taskExecuterHubClient.connection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
                {
                    await taskExecuterHubClient.ReportOutputDataReceived(_executerId, e.Data);
                }
            }
            catch(Exception xcp)
            {

            }
        }

        public async Task<ExecutingTaskStatus> StopTask()
        {
            try
            {
                if (!process.HasExited)
                {
                    process.Kill();
                }
            }
            //catch(System.ComponentModel.Win32Exception win32Exception)
            //{

            //}
            //catch (System.NotSupportedException notSupportedException)
            //{

            //}
            //catch (System.InvalidOperationException invalidOperationException)
            //{

            //}
            catch 
            {
                //var excpExecutingTaskStatus = new ExecutingTaskStatus { TaskId = _taskId, ExecuterId = _executerId, Status = StatusOptions.TaskStoppedError, StartDateTime = _startDateTime, EndDateTime= DateTime.Now, ErrorData = xcp.Message };
                _executingTaskStatus.Status = StatusOptions.TaskStoppedError;
                _executingTaskStatus.EndDateTime = DateTime.Now;

                if (taskExecuterHubClient.connection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
                {
                    await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);
                }

                return _executingTaskStatus;
            }

            _executingTaskStatus.Status = StatusOptions.TaskStopped;
            //should be sent when process is indeed stopped
            //_executingTaskStatus.EndDateTime = DateTime.Now;
            //await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);

            return _executingTaskStatus;
        }
    }
}

//public /*async*/ Task<TaskExecutionResult> StopTask(DeploymentTask task)
//{
//    var taskExecutionResult = new TaskExecutionResult() { TaskId = task.Id, TaskProcess = process, /*StartDateTime = task.StartDateTime*/ EndDateTime = DateTime.Now };
//    return Task.FromResult(taskExecutionResult);
//}

//TODO currently is obsolete
//public async Task<TaskExecutionResult> ExecuteTask(string taskId)
//{
//    //  Get Deployment Task
//    var deploymentTask = GetDeploymentTask(taskId);

//    //  Execute Deployment Task
//    return await ExecuteTask(deploymentTask);
//}

//private DeploymentTask GetDeploymentTask(string taskId)
//{

//    //Git clone
//    //return new DeploymentTask() { Id = taskId, Description = "My first great task", Name = "task1", ProgramToExecute = "git", ProgramParameters = "clone https://github.com/necolas/normalize.css.git", ReportStandardOutput = true };

//    //tree
//    return new DeploymentTask() { Id = taskId, Description = "Running the Tree", Name = "task1", ProgramToExecute = @"C:\Windows\System32\cmd.exe", ProgramParameters = "/C tree", WorkingDirectory = @"C:\temp", ReportStandardOutput = true };
//}