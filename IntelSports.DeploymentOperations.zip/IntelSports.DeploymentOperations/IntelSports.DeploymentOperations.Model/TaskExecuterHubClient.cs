﻿using System;
using System.Threading.Tasks;
using IntelSports.DeploymentOperations.Model.DB;
using Microsoft.AspNetCore.SignalR.Client;

namespace IntelSports.DeploymentOperations.Model
{
    public class TaskExecuterHubClient
    {
        public HubConnection connection = null;
        private SystemProcessTaskExecuter systemProcessTaskExecuter = null;
        public TaskExecuterHubClient(string url, SystemProcessTaskExecuter systemProcessTaskExecuter)
        {
            connection = new HubConnectionBuilder().WithUrl(url).Build();
            this.systemProcessTaskExecuter = systemProcessTaskExecuter;

            //
            //Looks like all the below event handlers don't  do anything and are not needed?
            //
            connection.On<string, string>("ReceiveMessage", (user, message) =>
            {
                Console.WriteLine("Recieved a message: " + message);
            });
                                   
            
             connection.On<string>("OnTaskStartingStatus", (status) =>
             {
                 Console.WriteLine("Recieved a message From Server Hub: OnTaskStartingStatus" + status);
             });

            connection.On<string>("OnTaskStartedStatus", (status) =>
            {
                Console.WriteLine("Recieved a message From Server Hub: OnTaskStartedStatus" + status);
            });

            connection.On<string>("OnTaskCompletedStatus", (status) =>
            {
                Console.WriteLine("Recieved a message From Server Hub: OnTaskCompletedStatus" + status);
            });

            connection.On("StopTask", () =>
            {
                Console.WriteLine("Attempting to Stop Task");
        
                if (!systemProcessTaskExecuter.process.HasExited)
                {
                    systemProcessTaskExecuter.process.Kill();
                    connection.SendAsync("StopTaskCompleted");
                    Console.WriteLine("StopTaskCompleted");
                }

            });

            connection.StartAsync();
        }

        private Task Connection_Closed(Exception arg)
        {
            Console.WriteLine("SystemProcessTaskExecuter: Connection Closed");
            return Task.FromResult("");
            
        }

        public async Task ReportExecutingTaskStatus(ExecutingTaskStatus executingTaskStatus)
        {
            await connection.InvokeAsync("ExecutingTaskStatus", executingTaskStatus);
        }
        public async Task ReportOutputDataReceived(string executerId, string data)
        {
            await connection.InvokeAsync("OutputDataReceived", executerId, data);
        }
        
        public async Task Disconnect()
        {
            await this.connection.StopAsync();
        }
    }
}

//public async Task ReportEvent(string methodName, string message)
//{
//    await connection.InvokeAsync(methodName, message);
//}

//public async Task ReportEvent(string methodName)
//{
//    await connection.InvokeAsync(methodName);
//}