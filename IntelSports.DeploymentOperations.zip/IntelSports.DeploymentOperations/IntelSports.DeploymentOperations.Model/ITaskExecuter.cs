﻿using IntelSports.DeploymentOperations.Model.DB;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IntelSports.DeploymentOperations.Model
{
    public interface ITaskExecuter
    { 
        Task<ExecutingTaskStatus> ExecuteTask(ODTask task);

        Task<ExecutingTaskStatus> StopTask();
    }
}
//Task<TaskExecutionResult> ExecuteTask(string taskId);

//Task<TaskExecutionResult> StopTask(string taskId);