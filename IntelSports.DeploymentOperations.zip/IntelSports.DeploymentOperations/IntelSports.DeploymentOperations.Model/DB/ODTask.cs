﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public class ODTask
    {
        public string Id { get; set; }
        public string ODProgramId { get; set; }
        public string ODProgramName { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string ProgramToExecute { get; set; }
        public string ProgramParameters { get; set; }
        public string TaskParameters { get; set; }
        public bool ReportStandardOutput { get; set; }
        public string WorkingDirectory { get; set; }
    }
}
