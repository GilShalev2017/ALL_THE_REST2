// lang-en.ts

export const LANG_EN_NAME = 'en';

export const LANG_EN_TRANS = {
    'FirstName': 'First Name',
    'LastName': 'Last Name',
    'UserName': 'User Name',
    'Email': 'Email',
}
