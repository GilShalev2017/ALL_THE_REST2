// lang-en.ts
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LANG_EN_NAME = 'en';
exports.LANG_EN_TRANS = {
    '2009': '2009',
    '2010': '2010',
    '2011': '2011',
    '2012': '2012',
    '2013': '2013',
    '2014': '2014',
    '2015': '2015',
    '2016': '2016',
    '2017': '2017',
};
//# sourceMappingURL=lang-en.js.map