# FreeD cloud Decoder Worker (Fd19) 
A simple java conspole app wihch that has a next flow:
*   Get frame from Kinesis Video (according to start selector `NOW` or `EARLIEST`)
*   Extract (parse) meta data of frame (`frameId`, `timeStamp` etc..)
*   Cut h264 frame by `bodyOffset`
*   Decode h264 frame
*   Convert to `TIFF`
*   Save TIFF `image` in provided output direcotry
*   Send `meta message` to the provided Kinesis Data.

### Download
You can get prebuild version from S3 [temp1-file-share/builds/intel-cloudfreed-decoderworker-1.0.zip](https://s3-eu-west-1.amazonaws.com/temp1-file-share/builds/intel-cloudfreed-decoderworker-1.0.zip). (in future Artifactory).

### Pre Installation
*	EC2 G3 Nvidia M60 instance required
*	Cuda/Nvidia Drivers
	*	You can create EC2 Instance from AMI with Nvidia drivers
		*	Link: https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/accelerated-computing-instances.html
	*	Install drivers manualy
		*	Link: https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/install-nvidia-driver.html

### Dependencies
There is a list of Java & C++ library dependencies
*   Maven package `intel-cloudfreed-metafeed-interfaces` [link to git](https://bitbucket.il.alm-sg.com/projects/RP/repos/intel-cloudfreed-metafeed-interfaces/browse). (in funture Artifactory)

*   Maven package `intel-cloudfreed-framecomposer-jnihpci` [link to git](https://bitbucket.il.alm-sg.com/projects/RP/repos/intel-cloudfreed-framecomposer-jnihpci/browse). (in funture Artifactory)

*	Sub C++ dependencies:
	*	Intel.CloudFreed.FrameComposer.JniHpciFrameComposer (.so) (C++ JNI layer) [link to git](https://bitbucket.il.alm-sg.com/projects/RP/repos/intel.cloudfreed.framecomposer.jnihpciframecomposer/browse). CMake NEEDED!
	*	Intel.CloudFreed.FrameComposer.Interfaces (.h only) (interface) [link to git](https://bitbucket.il.alm-sg.com/projects/RP/repos/intel.cloudfreed.framecomposer.interfaces/browse)
	*	Intel.CloudFreed.FrameComposer.HpciFrameComposer (.cpp) (HPIC implementation.) [link to git](https://bitbucket.il.alm-sg.com/projects/RP/repos/intel.cloudfreed.framecomposer.hpciframecomposer/browse)

*	Sub C++ dependencies:
	*	Intel.CloudFreed.Decoder.JniHpciDecoder (.so) (C++ JNI layer) [link to git](https://bitbucket.il.alm-sg.com/projects/RP/repos/intel.cloudfreed.decoder.jnihpcidecoder/browse) CMake NEEDED!		
	*	Intel.CloudFreed.Decoder.Interfaces (.h only) (Decoder interface) [link to git](https://bitbucket.il.alm-sg.com/projects/RP/repos/intel.cloudfreed.decoder.interfaces/browse)
	*	libdecoder.so, libFDDecoderWrapper.so (Decoder HPIC implementation.) 




### Compile
There is no automation process right now, the `mvn package` doesn't work. In order to compile and produce `JAR` with 
java dependencies use IDE Intellij `Build -> Build Artifacts`.  


### Config 
There are two options to provide configuration either through `arguments` or via `config.json` file.
In addition you have to configure **AWS SDK** credentials.
We use [Default Credential Provider Chain](https://docs.aws.amazon.com/sdk-for-java/v1/developer-guide/credentials.html) (which support Roles , Profiles, Environment variables) so you have plate of variants how to do it.
*   For `Region` you can use Environment variable `AWS_REGION` as well.


### Docker Build
```
aws ecr get-login --region eu-west-1 --no-include-email
docker loging ...

// Build base docker
docker build -f decoderworker-base.Dockerfile -t 753274046439.dkr.ecr.eu-west-1.amazonaws.com/intel-cloudfreed-decoderworker-base:1.0 .

// Build soruce docker
docker build -t 753274046439.dkr.ecr.eu-west-1.amazonaws.com/intel-cloudfreed-decoderworker:1.1 .

// Local RUN
docker run -it -v output:/output -e AWS_ACCESS_KEY_ID='aaaaaaaaaa' -e AWS_SECRET_ACCESS_KEY='bbbbbbbb' 753274046439.dkr.ecr.eu-west-1.amazonaws.com/intel-cloudfreed-decoderworker:1.1 -cid 1 -fw 3600 -fh 2160 -vs for_Dima_Feb13 -vss EARLIEST -ds app1-stream -r eu-west-1 -o "/output/{0,number,#}.tiff"

// Cluster RUN
docker run -it -v output:/output -e HOSTNAME="decoder-1-1" -e DEPLOYMENT_JSON="/output/deployment.json" -e SHARED_STORAGE_WRITE_ROOT="/output" -e AWS_ACCESS_KEY_ID='aaaaaaa' -e AWS_SECRET_ACCESS_KEY='bbbbbbb' 753274046439.dkr.ecr.eu-west-1.amazonaws.com/intel-cloudfreed-decoderworker:1.2

docker push ...


// Export used in order to test startup.sh
export HOSTNAME="decoder-1-1"
export DEPLOYMENT_JSON="/home/ubuntu/temp/deployment.json"
export SHARED_STORAGE_WRITE_ROOT="/home/ubuntu/temp/output"
```

#### Args example:
```
usage: You can use config.json or Args
 -c,--config <arg>               file path to 'config.json'
 -cid,--camera-id <arg>          camera id
 -ds,--data-stream-name <arg>    kinesis data stream name
 -fh,--frame-height <arg>        frame heigth
 -fw,--frame-width <arg>         frame width
 -o,--output <arg>               output directory full path ex:
                                 'c:\temp\frame-{0,number,#}.tiff'
 -r,--region <arg>               AWS region name ex: 'eu-west-1'
 -vs,--video-stream-name <arg>   kinesis video stream name
 -vss,--start-selector <arg>     kinesis selector 'NOW' or 'EARLIEST'
```

#### config.json example:
Use argument `-c --config` in order to provide full path to the config.json. 
```
{
	"videoStreamName": "name",
    "dataStreamName": "name",
	"cameraId": 1,
	"frameWidth": 0,
	"frameHeight": 0,
    "region": "eu-west-1"
    "startSelector": "NOW", // 'NOW' or 'EARLIEST'
    "outputPath":"D:\\temp\\frames\\{0,number,#}.tiff"
}
```


### Running
```
// On Linux:
export LD_LIBRARY_PATH=/dir/to/lib   // ex: /usr/local/lib
java -jar intel-cloudfreed-decoderworker.jar -cid 1 -fw 1800 -fh 1080 -vs video-stream-name -vss EARLIEST -ds data-stream-name -r eu-west-1 -o "/home/ubuntu/output/{0,number,#}.tiff"
```
OR with `-Djava.library.path`
```
java -Djava.library.path="C:\path\to\lib" -jar intel-cloudfreed-decoderworker.jar -cid 1 -fw 1800 -fh 1080 -vs video-stream-name -vss EARLIEST -ds data-stream-name -r eu-west-1 -o "/home/ubuntu/output/{0,number,#}.tiff"
```

Example:
```
java -jar intel-cloudfreed-decoderworker.jar -cid 1 -fw 1800 -fh 1080 -vs ms1_trial_source_0 -vss EARLIEST -ds temp-stream-1 -r eu-west-1 -o "/home/ubuntu/output/{0,number,#}.tiff"
```

Running Test only:
```
mvn -Dtest=JniHpciDecoderTest test
```

# Problems / TODO

*	We suspect that C++ Tiff converter not working properly.
*   Few projects and dependencies are not using Cmkae. We are working on creating Cmake files for thess projects.
*   We notice that the first few consumed frames error out in decoding - Status false.. We need to look into that.