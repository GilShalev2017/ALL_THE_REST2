#!/bin/bash

# bash stops processing once it encounters the error
set -e


# # Am I on k8s cluster?
if [[ ! -z "${DEPLOYMENT_JSON}" ]]; then

    echo "RUNNING ON: CLUSTER"

    # following env variables will be available once running in the K8s cluster
    echo "DEPLOYMENT_JSON: $DEPLOYMENT_JSON" ##all config should come from deployment.json
    echo "SHARED_STORAGE_WRITE_ROOT: $SHARED_STORAGE_WRITE_ROOT" ##lustre
    echo "APPLICATION_EVENTS: $APPLICATION_EVENTS" ##mount point for application events
    echo "LOGS_JSON: $LOGS_JSON" ##mount for json logs
    echo "LOGS_LEGACY: $LOGS_LEGACY" ## mount for unformatted logs

    # extract instance number, eg. hsl-packager-123 => 123 
    INSTANCE=${HOSTNAME##*-}
    echo "INSTANCE NUMBER: $INSTANCE"

    # Get configuration from deployment.json    
    VIDEO_STREAM=$( cat $DEPLOYMENT_JSON | jq ".stadium_cameras.all_streams[$INSTANCE].kinesis_video_name" )
    DATA_STREAM=$( cat $DEPLOYMENT_JSON | jq '.decode.kinesis_data_stream' )
    REGION=$( cat $DEPLOYMENT_JSON | jq '.region' ) 
    OUTPUT="$SHARED_STORAGE_WRITE_ROOT/camera-$INSTANCE/{0,number,#}.tiff"

    # Create camera dir if it doens't exist
    mkdir -p "$SHARED_STORAGE_WRITE_ROOT/camera-$INSTANCE"

    # Set VIDEO_START_SELECTOR to NOW (if not set. i.e as default)
    if [ -z "$VIDEO_START_SELECTOR" ]; then
	export VIDEO_START_SELECTOR="NOW"
    fi

    # print varibles
    echo "VIDEO_STREAM: $VIDEO_STREAM"
    echo "DATA_STREAM: $DATA_STREAM"
    echo "REGION: $REGION"
    echo "OUTPUT: $OUTPUT"

    # exec container command
    exec java -jar intel-cloudfreed-decoderworker.jar -cid $INSTANCE -fw 3600 -fh 2160 -vs $VIDEO_STREAM -vss $VIDEO_START_SELECTOR -ds $DATA_STREAM -r $REGION -o $OUTPUT
else
    echo "RUNNING ON: LOCAL"
    # exec container command
    exec java -jar intel-cloudfreed-decoderworker.jar "$@"
fi


