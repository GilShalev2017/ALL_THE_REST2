package com.intel.cloudfreed.decoderworker.storage;

import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;
import java.nio.ByteBuffer;
import java.time.Clock;

public class StorageWithMetrics implements IStorage
{
    private IStorage _inner;
    private Logger _logger = null;

    public StorageWithMetrics(IStorage inner, ILoggerFactory loggerFactory)
    {
        _inner = inner;
        _logger = loggerFactory.getLogger(StorageWithMetrics.class.getName());
    }

    // TODO: generate AWS CloudWatch metrics
    @Override
    public void save(String filaPath, ByteBuffer blob) throws Exception
    {
        long timeStart = Clock.systemUTC().millis();

        _inner.save(filaPath, blob);

        long timeAfter = Clock.systemUTC().millis();

        //_logger.info("save time taken: " + (timeAfter - timeStart) + " (ms)");
    }
}
