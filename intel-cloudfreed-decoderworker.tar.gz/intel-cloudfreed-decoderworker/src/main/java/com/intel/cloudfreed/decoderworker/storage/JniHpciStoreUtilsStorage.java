package com.intel.cloudfreed.decoderworker.storage;

import com.intel.cloudfreed.storeutils.jnihpcistoreutils.JniHpciStoreUtils;

import java.nio.ByteBuffer;

public class JniHpciStoreUtilsStorage  implements IStorage {

    private JniHpciStoreUtils _hpciStoreUtils;
    private int _width;
    private int _height;

    public JniHpciStoreUtilsStorage(int width, int height)
    {
        _width = width;
        _height = height;

        _hpciStoreUtils = new JniHpciStoreUtils();
    }

    @Override
    public void save(String filaPath, ByteBuffer blob) throws Exception {
        //_hpciStoreUtils.Save24BitsFromBufferToTiff(filaPath, blob, _width, _height);
        _hpciStoreUtils.Save32BitsFromBufferToTiff(filaPath, blob, _width, _height);
    }
}
