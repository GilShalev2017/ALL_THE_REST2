package com.intel.cloudfreed.decoder.instrumental;

import com.intel.cloudfreed.decoder.interfaces.IDecoder;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;
import java.nio.ByteBuffer;
import java.time.Clock;
import java.nio.ByteBuffer;

public class DecoderWithMetricts implements IDecoder
{
    private IDecoder _inner;
    private Logger _logger = null;

    public DecoderWithMetricts(IDecoder inner, ILoggerFactory loggerFactory)
    {
        _inner = inner;
        _logger = loggerFactory.getLogger(DecoderWithMetricts.class.getName());
    }

    @Override
    public ByteBuffer Decode(ByteBuffer frame)
    {
        long timeStart = Clock.systemUTC().millis();

        ByteBuffer result = _inner.Decode(frame);

        long timeAfter = Clock.systemUTC().millis();

        //_logger.info("decode time taken: " + (timeAfter - timeStart) + " (ms)");

        return result;
    }
}
