package com.intel.cloudfreed.decoder.jnihpci;

import com.intel.cloudfreed.decoder.interfaces.IDecoder;

import java.io.Closeable;
import java.io.IOException;
import java.nio.ByteBuffer;

// JNI CPP instructions:
//  run > javac -h . JniHpciDecoder.java -classpath D:\dev\intel-cloudfreed-decoderworker\target\classes
// OR
// run > javac -h . JniHpciDecoder.java -classpath {location-of-some-jar with interface IDecoder}

public class JniHpciDecoder implements IDecoder, Closeable
{
    static
    {
        System.loadLibrary("Intel.CloudFreed.Decoder.JniHpciDecoder"); // Intel.CloudFreed.Decoder.JniHpciDecoder.dll (Windows) or Intel.CloudFreed.Decoder.JniHpciDecoder.so (Unixes)
    }

    private native void initNative(int inputFrameWidth, int inputFrameHeight, boolean useFakeDecoder);
    private native ByteBuffer decodeNative(ByteBuffer frame);
    private native void disposeNative();


    public JniHpciDecoder(int inputFrameWidth, int inputFrameHeight)
    {
        initNative(inputFrameWidth, inputFrameHeight, false);
    }

    public JniHpciDecoder(int inputFrameWidth, int inputFrameHeight, boolean useFakeDecoder)
    {
        initNative(inputFrameWidth, inputFrameHeight, useFakeDecoder);
    }


    // https://confluence.il.alm-sg.com/display/FR/JNI+example
    // https://stackoverflow.com/questions/2673839/jni-native-method-with-bytebuffer-parameter

    public ByteBuffer Decode(ByteBuffer frame)
    {
        frame.rewind();

        if(!frame.isDirect())
        {
            throw new IllegalArgumentException("The input byte buffer have to be allocated in direct mode");
        }

        return decodeNative(frame);
    }


    public void close() throws IOException {
        disposeNative();
    }
}
