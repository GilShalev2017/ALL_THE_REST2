package com.intel.cloudfreed.decoderworker.framevisitor;

import com.amazonaws.kinesisvideo.parser.utilities.FrameVisitor;
import com.intel.cloudfreed.decoder.interfaces.IDecoder;
import com.intel.cloudfreed.decoderworker.sender.ISender;
import com.intel.cloudfreed.decoderworker.storage.IStorage;
import com.intel.cloudfreed.framecomposer.interfaces.IFrameComposer;
import com.intel.cloudfreed.frameconverter.IFrameConverter;
import com.intel.cloudfreed.metafeed.interfaces.MetaFrame;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;


public class ElementVisitorFactory
{
    private ILoggerFactory _loggerFactory = null;
    private IFrameComposer _composer = null;
    private IDecoder _decoder = null;
    private IFrameConverter _frameConverter = null;
    private IStorage _storage = null;
    private ISender<MetaFrame> _sender = null;
    private int _cameraId;
    private String _outputAddress;
    private FrameProcessor _frameProcessor;

    public ElementVisitorFactory(int cameraId, String outputAddress, IFrameComposer composer, IDecoder decoder, IFrameConverter frameConverter, IStorage storage, ISender<MetaFrame> sender, ILoggerFactory loggerFactory)
    {
        _cameraId = cameraId;
        _outputAddress = outputAddress;
        _composer = composer;
        _decoder = decoder;
        _frameConverter = frameConverter;
        _storage = storage;
        _sender = sender;
        _loggerFactory = loggerFactory;
    }

//    public ElementVisitorFactory(FrameVisitor.FrameProcessor frameProcessor)
//    {
//        _frameProcessor = frameProcessor;
//    }

    public FrameProcessor GetFrameProcessor()
    {
        return _frameProcessor;
    }

    public FrameVisitor create()
    {
        _frameProcessor = new FrameProcessor(_cameraId, _outputAddress, _composer, _decoder, _frameConverter, _storage, _sender, _loggerFactory);

        return FrameVisitor.create(new FrameProcessorWithMetrics<>(_frameProcessor/*new FrameProcessor(_cameraId, _outputAddress, _composer, _decoder, _frameConverter, _storage, _sender, _loggerFactory)*/, _loggerFactory));
    }
}
