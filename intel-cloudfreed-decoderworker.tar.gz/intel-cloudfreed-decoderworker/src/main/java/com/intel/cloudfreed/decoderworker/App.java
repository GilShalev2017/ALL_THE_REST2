package com.intel.cloudfreed.decoderworker;


import com.amazonaws.kinesisvideo.parser.mkv.MkvElementVisitor;
import com.amazonaws.kinesisvideo.parser.utilities.FrameVisitor;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;
import com.amazonaws.services.kinesisvideo.model.StartSelector;
import com.amazonaws.services.kinesisvideo.model.StartSelectorType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.intel.cloudfreed.decoder.fake.FakeDecoder;
import com.intel.cloudfreed.decoder.instrumental.DecoderWithMetricts;
import com.intel.cloudfreed.decoder.interfaces.IDecoder;
import com.intel.cloudfreed.decoder.jnihpci.JniHpciDecoder;
import com.intel.cloudfreed.decoderworker.framevisitor.FrameProcessor;
import com.intel.cloudfreed.decoderworker.framevisitor.FrameProcessorWithMetrics;
import com.intel.cloudfreed.decoderworker.helpers.AmazonKinesisClientFactory;
import com.intel.cloudfreed.decoderworker.helpers.AmazonKinesisVideoMediaFactory;
import com.intel.cloudfreed.decoderworker.helpers.ConfigConstants;
import com.intel.cloudfreed.decoderworker.framevisitor.ElementVisitorFactory;
import com.intel.cloudfreed.decoderworker.helpers.IAmazonKinesisVideoMediaFactory;
import com.intel.cloudfreed.decoderworker.sender.ISender;
import com.intel.cloudfreed.decoderworker.sender.KinesisDataSender;
import com.intel.cloudfreed.decoderworker.sender.SenderWithMetrics;
import com.intel.cloudfreed.decoderworker.storage.*;
import com.intel.cloudfreed.framecomposer.fake.FakeFrameComposer;
import com.intel.cloudfreed.framecomposer.instrumental.FrameComposerWithMetrics;
import com.intel.cloudfreed.framecomposer.interfaces.IFrameComposer;
import com.intel.cloudfreed.framecomposer.jnihpci.JniHpciFrameComposer;
import com.intel.cloudfreed.frameconverter.*;
import com.intel.cloudfreed.metafeed.interfaces.MetaFrame;
import org.apache.commons.cli.*;
import org.apache.commons.lang.StringUtils;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import com.twelvemonkeys.imageio.plugins.tiff.TIFFImageReader;

public class App
{
    private static ILoggerFactory _loggerFactory = LoggerFactory.getILoggerFactory();
    private static Logger _logger = _loggerFactory.getLogger(App.class.toString());;

    public static void main( String[] args ) throws Exception
    {
        _logger.info("Decoder Worker");

        Config appConfig = null;

        try
        {
            appConfig = GetConfig(args);
        }
        catch (Exception ex)
        {
            System.exit(1);
        }

        // kinesis factory config
        Properties awsConfig = new Properties();
        awsConfig.put(ConfigConstants.AWS_REGION, appConfig.getRegion());


        // kinesis video
        IAmazonKinesisVideoMediaFactory videoKinesisFactory = new AmazonKinesisVideoMediaFactory(appConfig.getVideoStreamName(), awsConfig);
        StartSelector startSelector = new StartSelector().withStartSelectorType(StartSelectorType.fromValue(appConfig.getStartSelector())); // StartSelectorType.EARLIEST // NOW

        // frame composer
        IFrameComposer composer = new FrameComposerWithMetrics(new JniHpciFrameComposer(), _loggerFactory);
        //IFrameComposer composer = new FakeFrameComposer();

        // decoder
        IDecoder decoder = new DecoderWithMetricts(new JniHpciDecoder(appConfig.getFrameWidth(), appConfig.getFrameHeight()), _loggerFactory);
        //IDecoder decoder = new FakeDecoder();

        // tiff frame converter
        IFrameConverter converter = new NoneFrameConverter();
        //IFrameConverter converter = new FrameConverterWithMetrics(new TiffFrameConverter(appConfig.getFrameWidth(), appConfig.getFrameHeight()), _loggerFactory);
        //IFrameConverter converter = new FakeFrameConverter();

        // storage
        IStorage storage = new StorageWithMetrics(new JniHpciStoreUtilsStorage(appConfig.getFrameWidth(), appConfig.getFrameHeight()), _loggerFactory);
        //IStorage storage = new StorageWithMetrics(new FileStorage(), _loggerFactory);
        //IStorage storage = new FakeStorage();


        // sender
        AmazonKinesis kinesisClient = new AmazonKinesisClientFactory(awsConfig).create();
        ISender<MetaFrame> sender = new SenderWithMetrics<>(new KinesisDataSender(kinesisClient, appConfig.getDataStreamName()), _loggerFactory);

        //FrameProcessor
//        FrameVisitor frameProcessor = new FrameProcessorWithMetrics<>(new FrameProcessor(appConfig.getCameraId(),
//                                                                                         appConfig.getOutputPath(),
//                                                                                         composer,
//                                                                                         decoder,
//                                                                                         converter,
//                                                                                         storage,
//                                                                                         sender,
//                                                                                         _loggerFactory));

        // visitor
        ElementVisitorFactory elementVisitorFactory = new ElementVisitorFactory(appConfig.getCameraId(), appConfig.getOutputPath(),
                                                                                composer, decoder, converter, storage, sender, _loggerFactory);

        MkvElementVisitor elementVisitor = elementVisitorFactory.create();

//                        new ElementVisitorFactory(appConfig.getCameraId(), appConfig.getOutputPath(),
//                composer, decoder, converter, storage, sender, _loggerFactory).create();

        //MkvElementVisitor elementVisitor = new ElementVisitorFactory(frameProcessor).create();

        // worker
        DecoderWorker worker = new DecoderWorker(_loggerFactory, videoKinesisFactory, startSelector, appConfig.getVideoStreamName(), elementVisitorFactory.GetFrameProcessor(), elementVisitor);


        ExecutorService executorService = Executors.newFixedThreadPool(1);
        executorService.submit(worker)
                .get(); // await ...


        if (!executorService.isTerminated()) {
            _logger.warn("Shutting down executor service by force");
            executorService.shutdownNow();
        }
        else {
            _logger.info("Executor service is shutdown");
        }
    }

    private static Config GetConfig(String[] args ) throws Exception
    {
        Config result = new Config();
        // use environment variable first
        result.setRegion(System.getenv("AWS_REGION"));


        String ARG_CONFIG ="config";
        String ARG_VIDEO_STREAM_NAME ="video-stream-name";
        String ARG_DATA_STREAM_NAME ="data-stream-name";
        String ARG_START_SELECTOR ="start-selector";
        String ARG_OUTPUT ="output";
        String ARG_REGION ="region";
        String ARG_CAMERAID ="camera-id";
        String ARG_FRAME_WIDTH ="frame-width";
        String ARG_FRAME_HEIGHT ="frame-height";


        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        CommandLine cmd = null;

        options.addOption(new Option("c", ARG_CONFIG, true, "file path to 'config.json'"));
        options.addOption(new Option("cid", ARG_CAMERAID, true, "camera id"));
        options.addOption(new Option("fw", ARG_FRAME_WIDTH, true, "frame width"));
        options.addOption(new Option("fh", ARG_FRAME_HEIGHT, true, "frame heigth"));
        options.addOption(new Option("vs", ARG_VIDEO_STREAM_NAME, true, "kinesis video stream name"));
        options.addOption(new Option("vss", ARG_START_SELECTOR, true, "kinesis selector 'NOW' or 'EARLIEST'"));
        options.addOption(new Option("ds", ARG_DATA_STREAM_NAME, true, "kinesis data stream name"));
        options.addOption(new Option("o", ARG_OUTPUT, true, "output directory full path ex: 'c:\\temp\\frame-{0,number,#}.tiff'"));
        options.addOption(new Option("r", ARG_REGION, true, "AWS region name ex: 'eu-west-1'"));


        try
        {
            cmd = parser.parse(options, args);

            if(cmd.hasOption(ARG_CONFIG))
            {
                String configPath = cmd.getOptionValue(ARG_CONFIG);

                if(configPath == null || configPath.isEmpty())
                {
                    throw new Exception("invalid arguments value");
                }

                File configFile = new File(configPath);

                if(!configFile.exists() || configFile.isDirectory())
                {
                    throw new Exception("file not exists");
                }

                List<String> fileLines = Files.readAllLines(configFile.toPath());
                String jsonString = StringUtils.join(fileLines, StringUtils.EMPTY);

                ObjectMapper jsonMapper = new ObjectMapper();
                result = jsonMapper.readValue(jsonString, Config.class);
            }
            else
            {
                result.setCameraId(Integer.parseInt(cmd.getOptionValue(ARG_CAMERAID)));
                result.setFrameWidth(Integer.parseInt(cmd.getOptionValue(ARG_FRAME_WIDTH)));
                result.setFrameHeight(Integer.parseInt(cmd.getOptionValue(ARG_FRAME_HEIGHT)));
                result.setVideoStreamName(cmd.getOptionValue(ARG_VIDEO_STREAM_NAME));
                result.setStartSelector(cmd.getOptionValue(ARG_START_SELECTOR));
                result.setDataStreamName(cmd.getOptionValue(ARG_DATA_STREAM_NAME));
                result.setOutputPath(cmd.getOptionValue(ARG_OUTPUT));

                if(!isNullOrEmpty(cmd.getOptionValue(ARG_REGION)))
                {
                    result.setRegion(cmd.getOptionValue(ARG_REGION));
                }
            }


            // validation
            if(isNullOrEmpty(result.getVideoStreamName()) ||
                    isNullOrEmpty(result.getDataStreamName()) ||
                    isNullOrEmpty(result.getRegion()) ||
                    isNullOrEmpty(result.getStartSelector())||
                    isNullOrEmpty(result.getOutputPath()) ||
                    result.getFrameWidth() <= 0 ||
                    result.getFrameHeight() <= 0)
            {
                throw new Exception("invalid arguments value");
            }

        }
        catch (Exception e)
        {
            System.out.println("Error: " +e.getMessage());
            formatter.printHelp("You can use config.json or Args", options);


            throw new Exception("GetConfig Exception");
        }



        return result;
    }

    public static boolean isNullOrEmpty(String str) {
        if(str != null && !str.trim().isEmpty())
            return false;
        return true;
    }
}
