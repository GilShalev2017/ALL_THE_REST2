package com.intel.cloudfreed.frameconverter;

import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.time.Clock;

public class FrameConverterWithMetrics implements IFrameConverter {

    private IFrameConverter _inner;
    private Logger _logger = null;

    public FrameConverterWithMetrics(IFrameConverter inner, ILoggerFactory loggerFactory)
    {
        _inner = inner;
        _logger = loggerFactory.getLogger(FrameConverterWithMetrics.class.getName());
    }


    @Override
    public ByteBuffer convert(ByteBuffer frame) throws IOException
    {
        long timeStart = Clock.systemUTC().millis();

        ByteBuffer result = _inner.convert(frame);

        long timeAfter = Clock.systemUTC().millis();

        _logger.info("convert time taken: " + (timeAfter - timeStart) + " (ms)");

        return result;
    }
}
