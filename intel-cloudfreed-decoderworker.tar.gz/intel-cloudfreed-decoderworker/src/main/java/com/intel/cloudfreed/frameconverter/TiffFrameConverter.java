package com.intel.cloudfreed.frameconverter;

import com.twelvemonkeys.imageio.plugins.tiff.TIFFImageWriteParam;

import javax.imageio.*;
import javax.imageio.stream.ImageOutputStream;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.time.Clock;

public class TiffFrameConverter implements IFrameConverter {

    private int _width;
    private int _height;

    public TiffFrameConverter(int width, int height)
    {
        _width = width;
        _height = height;
    }

    @Override
    public ByteBuffer convert(ByteBuffer frame) throws IOException
    {
        frame.rewind();

        if(frame.isDirect()) // copy frame to local buffer :(
        {
            ByteBuffer localBuffer = ByteBuffer.allocate(frame.remaining());
            localBuffer.put(frame);
            localBuffer.rewind(); // reset position to '0'.
            frame.rewind(); // reset position to '0'.

            frame = localBuffer;
        }

        BufferedImage image = readRawRGBA(frame.array(), _width, _height);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        ImageIO.write(image, "TIFF", outputStream);
        return ByteBuffer.wrap(outputStream.toByteArray());
    }


    public ByteBuffer convertWithCompression(ByteBuffer frame) throws IOException
    {
        frame.rewind();

        if(frame.isDirect()) // copy frame to local buffer :(
        {
            ByteBuffer localBuffer = ByteBuffer.allocate(frame.remaining());
            localBuffer.put(frame);
            localBuffer.rewind(); // reset position to '0'.
            frame.rewind(); // reset position to '0'.

            frame = localBuffer;
        }

        long timeStart = Clock.systemUTC().millis();

        BufferedImage image = readRawRGBA(frame.array(), _width, _height);

        long timeAfter = Clock.systemUTC().millis();

        System.out.println("readRawRGBA time taken: " + (timeAfter - timeStart) + " (ms)");


        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();


        ImageWriter writer = ImageIO.getImageWritersByFormatName("TIFF").next();
        TIFFImageWriteParam writeParam = (TIFFImageWriteParam)writer.getDefaultWriteParam();
        writeParam.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        writeParam.setCompressionType("None");
        writeParam.setCompressionQuality(1f);

        write(image, writer, outputStream, writeParam);

        return ByteBuffer.wrap(outputStream.toByteArray());
    }

    public static boolean write(RenderedImage im,
                                ImageWriter writer,
                                OutputStream output, ImageWriteParam param) throws IOException {
        if (output == null) {
            throw new IllegalArgumentException("output == null!");
        }
        ImageOutputStream stream = null;
        try {
            stream = ImageIO.createImageOutputStream(output);
        } catch (IOException e) {
            throw new IIOException("Can't create output stream!", e);
        }

        try {
            return doWrite(im, writer, stream, param);
        } finally {
            stream.close();
        }
    }

    private static boolean doWrite(RenderedImage im, ImageWriter writer,
                                   ImageOutputStream output, ImageWriteParam param) throws IOException {
        if (writer == null) {
            return false;
        }
        writer.setOutput(output);
        try {
            writer.write(null, new IIOImage(im, null, null), param);
        } finally {
            writer.dispose();
            output.flush();
        }
        return true;
    }



    private static BufferedImage readRawRGBA(byte[] raw, int width, int height)
    {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB); //TYPE_BYTE_GRAY, TYPE_INT_RGB

        IntBuffer intBuf = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN).asIntBuffer(); //LITTLE_ENDIAN


        for (int i = 0; i < intBuf.remaining(); i++)
        {
            int val = intBuf.get(i);
            val = ToARGB(val);
            intBuf.put(i, val);
        }


        int[] array = new int[intBuf.remaining()];
        intBuf.get(array);
        image.setRGB(0, 0, width, height, array, 0, width);

        return image;
    }

    private static int ToARGB(int rgba)
    {
        //return (rgba << 24) | (rgba >> 8); // original solution

        int r = (rgba)&0xFF;
        int g = (rgba>>8)&0xFF;
        int b = (rgba>>16)&0xFF;
        int a = (rgba>>24)&0xFF;

        //java.awt.Color x = new java.awt.Color(r, g,b, a);
        //return x.getRGB();

        return (a & 0xff) << 24 | (r & 0xff) << 16 | (g & 0xff) << 8 | (b & 0xff);
    }

}
