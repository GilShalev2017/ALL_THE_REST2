package com.intel.cloudfreed.decoderworker.helpers;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClient;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;

import java.util.Properties;

public class AmazonKinesisClientFactory
{
    private Properties _config;

    public AmazonKinesisClientFactory(Properties config)
    {
        _config = config;
    }

    public AmazonKinesis create() throws Exception
    {
        validate(_config);

        AWSCredentialsProvider credentials = DefaultAWSCredentialsProviderChain.getInstance(); // by default AWS credentials chain.
        Regions region = Regions.fromName(_config.getProperty(ConfigConstants.AWS_REGION));


        if(_config.containsKey(ConfigConstants.AWS_PROFILE_NAME))
        {
            credentials = new ProfileCredentialsProvider(_config.getProperty(ConfigConstants.AWS_PROFILE_NAME));
        }
        else if(_config.containsKey(ConfigConstants.AWS_ACCESS_KEY_ID) && _config.containsKey(ConfigConstants.AWS_SECRET_ACCESS_KEY) )
        {
            credentials = new BasicAWSCredentialsProvider(_config.getProperty(ConfigConstants.AWS_ACCESS_KEY_ID), _config.getProperty(ConfigConstants.AWS_SECRET_ACCESS_KEY));
        }


        AmazonKinesisClientBuilder clientBuilder = AmazonKinesisClientBuilder.standard();
        clientBuilder.withRegion(region);
        clientBuilder.withCredentials(credentials);
        //clientBuilder.setClientConfiguration(config);

        return clientBuilder.build();
    }

    private static void validate(Properties config) throws Exception
    {
        if(config.getProperty(ConfigConstants.AWS_REGION) == null || config.getProperty(ConfigConstants.AWS_REGION) == "")
        {
            throw new Exception(ConfigConstants.AWS_REGION + " can't be null or empty");
        }
    }
}
