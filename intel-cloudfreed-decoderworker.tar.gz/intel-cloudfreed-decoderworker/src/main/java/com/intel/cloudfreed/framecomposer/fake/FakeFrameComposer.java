package com.intel.cloudfreed.framecomposer.fake;

import com.intel.cloudfreed.framecomposer.interfaces.GetMetaResult;
import com.intel.cloudfreed.framecomposer.interfaces.IFrameComposer;
import org.joda.time.DateTime;

import java.nio.ByteBuffer;

public class FakeFrameComposer implements IFrameComposer {

    private int _counter = 0;

    @Override
    public GetMetaResult getMeta(ByteBuffer byteBuffer) {
        _counter++;

        return new GetMetaResult(_counter, DateTime.now().toDate().getTime() / 1000, 0, 0);
    }

    @Override
    public ByteBuffer setMeta(long frameId, long timeStamp, ByteBuffer frame) {
        return null;
    }


}
