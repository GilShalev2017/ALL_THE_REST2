package com.intel.cloudfreed.decoderworker.helpers;

import com.amazonaws.services.kinesisvideo.AmazonKinesisVideoMedia;

public interface IAmazonKinesisVideoMediaFactory
{
    AmazonKinesisVideoMedia create() throws Exception;
}