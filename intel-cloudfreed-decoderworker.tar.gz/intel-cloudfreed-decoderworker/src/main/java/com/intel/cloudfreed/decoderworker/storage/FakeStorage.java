package com.intel.cloudfreed.decoderworker.storage;

import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class FakeStorage implements IStorage {

    @Override
    public void save(String filaPath, ByteBuffer blob) throws Exception
    {

    }
}

