package com.intel.cloudfreed.decoder.fake;

import com.intel.cloudfreed.decoder.interfaces.IDecoder;

import java.nio.ByteBuffer;

public class FakeDecoder implements IDecoder {

    public ByteBuffer Decode(ByteBuffer frame)
    {
        return  frame;
    }
}
