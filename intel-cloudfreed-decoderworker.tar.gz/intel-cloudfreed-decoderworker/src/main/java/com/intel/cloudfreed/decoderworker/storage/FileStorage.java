package com.intel.cloudfreed.decoderworker.storage;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class FileStorage implements IStorage {

    @Override
    public void save(String filaPath, ByteBuffer blob) throws Exception
    {
        FileChannel fc = null;

        try
        {
            fc = new FileOutputStream(filaPath).getChannel();
            fc.write(blob);
        }
        finally
        {
            if(fc != null){
                fc.close();
            }
        }

    }
}
