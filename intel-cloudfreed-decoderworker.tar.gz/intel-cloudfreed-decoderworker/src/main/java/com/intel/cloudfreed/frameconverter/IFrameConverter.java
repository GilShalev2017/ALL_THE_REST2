package com.intel.cloudfreed.frameconverter;

import java.io.IOException;
import java.nio.ByteBuffer;

public interface IFrameConverter {

    ByteBuffer convert(ByteBuffer frame) throws IOException;

}
