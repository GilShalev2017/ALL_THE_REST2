package com.intel.cloudfreed.framecomposer.instrumental;

import com.intel.cloudfreed.framecomposer.interfaces.GetMetaResult;
import com.intel.cloudfreed.framecomposer.interfaces.IFrameComposer;

import org.apache.commons.lang.NotImplementedException;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;

import java.nio.ByteBuffer;
import java.time.Clock;

public class FrameComposerWithMetrics implements IFrameComposer
{
    private IFrameComposer _inner;
    private Logger _logger = null;

    public FrameComposerWithMetrics(IFrameComposer inner, ILoggerFactory loggerFactory)
    {
        _inner = inner;
        _logger = loggerFactory.getLogger(FrameComposerWithMetrics.class.getName());
    }


    @Override
    public GetMetaResult getMeta(ByteBuffer byteBuffer)
    {
        long timeStart = Clock.systemUTC().millis();

        GetMetaResult result = _inner.getMeta(byteBuffer);

        long timeAfter = Clock.systemUTC().millis();

        //_logger.info("getMeta time taken: " + (timeAfter - timeStart) + " (ms)");

        return result;
    }

    @Override
    public ByteBuffer setMeta(long l, long l1, ByteBuffer byteBuffer)
    {
        throw new NotImplementedException();
    }
}
