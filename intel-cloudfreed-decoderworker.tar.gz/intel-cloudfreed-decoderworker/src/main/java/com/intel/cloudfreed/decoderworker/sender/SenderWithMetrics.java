package com.intel.cloudfreed.decoderworker.sender;


import com.intel.cloudfreed.decoderworker.storage.IStorage;
import com.intel.cloudfreed.metafeed.interfaces.MetaFrame;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;
import java.nio.ByteBuffer;
import java.time.Clock;

public class SenderWithMetrics<T> implements ISender<T>
{
    private ISender<T> _inner;
    private Logger _logger = null;

    public SenderWithMetrics(ISender<T> inner, ILoggerFactory loggerFactory)
    {
        _inner = inner;
        _logger = loggerFactory.getLogger(SenderWithMetrics.class.getName());
    }

    @Override
    public void send(T message) throws Exception
    {
        long timeStart = Clock.systemUTC().millis();

        _inner.send(message);

        long timeAfter = Clock.systemUTC().millis();

        //_logger.info("send time taken: " + (timeAfter - timeStart) + " (ms)");
    }
}
