package com.intel.cloudfreed.decoderworker.sender;

public interface ISender<T>
{
    void send(T message) throws Exception;
}
