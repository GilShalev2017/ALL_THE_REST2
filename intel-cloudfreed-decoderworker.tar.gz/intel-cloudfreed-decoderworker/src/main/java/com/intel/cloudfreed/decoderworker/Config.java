package com.intel.cloudfreed.decoderworker;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;

public @Data @AllArgsConstructor @NoArgsConstructor class Config implements Serializable
{
    private int frameWidth;
    private int frameHeight;
    private int cameraId;
    private String outputPath;
    private String dataStreamName;
    private String videoStreamName;
    private String startSelector;
    private String region;
}
