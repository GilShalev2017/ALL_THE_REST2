package com.intel.cloudfreed.decoderworker.framevisitor;

import com.amazonaws.kinesisvideo.parser.mkv.Frame;
import com.amazonaws.kinesisvideo.parser.utilities.FragmentMetadata;
import com.amazonaws.kinesisvideo.parser.utilities.FrameVisitor;
import com.amazonaws.kinesisvideo.parser.utilities.MkvTrackMetadata;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;

import java.math.BigInteger;
import java.time.Clock;
import java.util.Optional;

public class FrameProcessorWithMetrics<T> implements FrameVisitor.FrameProcessor
{
    public FrameVisitor.FrameProcessor _inner;
    private Logger _logger = null;
    private double framesCounter = 0;
    private long timeBegin;

    public FrameProcessorWithMetrics(FrameVisitor.FrameProcessor inner, ILoggerFactory loggerFactory)
    {
        _inner = inner;

        _logger = loggerFactory.getLogger(FrameProcessorWithMetrics.class.toString());

        timeBegin = Clock.systemUTC().millis();
    }


    // TODO: generate AWS CloudWatch metrics
    public void process(Frame frame, MkvTrackMetadata trackMetadata, Optional<FragmentMetadata> fragmentMetadata)
    {
        framesCounter++;

        long timeStart = Clock.systemUTC().millis();

        double deltaInMilli = timeStart - timeBegin;

        double fpsInMilli = framesCounter / deltaInMilli;

        double fps = fpsInMilli * 1000;

        _logger.info("Frames Per Second (FPS): " + fps);

        _inner.process(frame, trackMetadata, fragmentMetadata);

        long timeAfter = Clock.systemUTC().millis();

        _logger.info("process time taken: " + (timeAfter - timeStart) + " (ms)");
    }
}
