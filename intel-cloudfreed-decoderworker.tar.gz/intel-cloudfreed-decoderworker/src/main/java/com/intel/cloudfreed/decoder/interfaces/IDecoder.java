package com.intel.cloudfreed.decoder.interfaces;

import java.nio.ByteBuffer;

public interface IDecoder
{
    ByteBuffer Decode(ByteBuffer frame);
}
