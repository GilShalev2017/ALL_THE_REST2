package com.intel.cloudfreed.decoderworker.framevisitor;

import com.amazonaws.kinesisvideo.parser.mkv.Frame;
import com.amazonaws.kinesisvideo.parser.utilities.FragmentMetadata;
import com.amazonaws.kinesisvideo.parser.utilities.FrameVisitor;
import com.amazonaws.kinesisvideo.parser.utilities.MkvTrackMetadata;
import com.intel.cloudfreed.decoder.interfaces.IDecoder;
import com.intel.cloudfreed.decoderworker.sender.ISender;
import com.intel.cloudfreed.decoderworker.storage.IStorage;
import com.intel.cloudfreed.framecomposer.interfaces.GetMetaResult;
import com.intel.cloudfreed.framecomposer.interfaces.IFrameComposer;
import com.intel.cloudfreed.frameconverter.IFrameConverter;
import com.intel.cloudfreed.metafeed.interfaces.MetaFrame;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;

import java.awt.image.BufferedImage;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.Optional;

public class FrameProcessor<T> implements FrameVisitor.FrameProcessor
{
    private Logger _logger = null;
    private IFrameComposer _composer = null;
    private IDecoder _decoder = null;
    private IStorage _storage = null;
    private IFrameConverter _frameConverter = null;
    private ISender<MetaFrame> _sender = null;
    private int _cameraId;
    private String _outputAddress;

    private BigInteger lastFragmentNumber;
    private BigInteger currentFragmentNumber;

    public BigInteger getLastFragmentNumber() {
        return lastFragmentNumber;
    }

    private int framesCounter = 0;

    public FrameProcessor(int cameraId, String outputAddress, IFrameComposer composer, IDecoder decoder, IFrameConverter frameConverter, IStorage storage, ISender<MetaFrame> sender, ILoggerFactory loggerFactory)
    {
        _cameraId = cameraId;
        _outputAddress = outputAddress;
        _composer = composer;
        _decoder = decoder;
        _frameConverter = frameConverter;
        _storage = storage;
        _sender = sender;
        _logger = loggerFactory.getLogger(FrameProcessor.class.getName());
    }


    public void process(Frame frame, MkvTrackMetadata trackMetadata, Optional<FragmentMetadata> fragmentMetadata)
    {
//        _logger.debug("process frame: " + frame);
//        _logger.debug("frame trackMetadata: " + trackMetadata);
//        _logger.debug("frame fragmentMetadata: " + fragmentMetadata);

        try
        {
            processFrame(frame.getFrameData());

            final BigInteger currentFragmentnumberLocal = fragmentMetadata.orElseThrow(() -> new IllegalStateException("Not a Kinesis Video stream fragment !")).getFragmentNumber();

            if (currentFragmentnumberLocal != currentFragmentNumber) {
                lastFragmentNumber = currentFragmentNumber;
                currentFragmentNumber = currentFragmentnumberLocal;
            }

        }
        catch (Exception ex)
        {
            _logger.error("##############  Error while processing frame !!! ##############", ex);
        }
    }

    private void SaveFrameToDisk(String filePath, ByteBuffer blob) throws Exception
    {
        blob.rewind();

        FileChannel fc = new FileOutputStream(filePath).getChannel();
        fc.write(blob);
        fc.close();

        blob.rewind();
    }

    private void processFrame(ByteBuffer frame) throws Exception
    {
        // parse header
        GetMetaResult meta = _composer.getMeta(frame);

        long frameID = meta.getFrameId();
        // print meta
        //_logger.debug("process frame meta: " + meta);
        //_logger.debug("FRAME ID: " + meta.getFrameId());

        // cut raw frame
        ByteBuffer rawFrame = ByteBuffer.allocateDirect(frame.remaining() - (int)meta.getBodyOffset());
        rawFrame.put(frame.array(), (int)meta.getBodyOffset(), frame.remaining() - (int)meta.getBodyOffset()).rewind();

        //SaveFrameToDisk before decoding
        //framesCounter++;
        //String filePathDbg = MessageFormat.format("/output/encoded/frame{0,number,#}.h264", frameID);//framesCounter);
        //SaveFrameToDisk(filePathDbg, rawFrame);

        // decode
        ByteBuffer decodedFrame = _decoder.Decode(rawFrame);


        if(decodedFrame == null)
        {
            //_logger.error("##########  decode failed on frame: " + meta !!);
            _logger.error("##############  decode failed on frame: " + frameID + " !!! ##############");
            return;
        }
        else
        {
            //SaveFrameToDisk after decoding
            //filePathDbg = MessageFormat.format("/output/decoded/frame{0,number,#}.rgb", frameID);//framesCounter);
            //SaveFrameToDisk(filePathDbg, decodedFrame);
        }

        // convert to tiff
        //ByteBuffer image = _frameConverter.convert(decodedFrame); // we can optimize this in future, by using OutputStream of storage.

        // compose file Path
        String filePath = MessageFormat.format(_outputAddress, frameID, _cameraId);

        // save decoded frame
        _storage.save(filePath, decodedFrame);

        // send notification message
        _sender.send(new MetaFrame(_cameraId, frameID, meta.getTimeStamp(), filePath));
    }

    // this one does not copy
    // ByteBuffer rawFrame = ByteBuffer.wrap(frame.array(), (int)meta.getBodyOffset(), frame.remaining() - (int)meta.getBodyOffset());
}
