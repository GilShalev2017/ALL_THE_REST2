package com.intel.cloudfreed.decoderworker.sender;

import com.amazonaws.AmazonClientException;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;
import com.amazonaws.services.kinesis.model.PutRecordRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.intel.cloudfreed.metafeed.interfaces.MetaFrame;

import java.nio.ByteBuffer;

public class KinesisDataSender implements ISender<MetaFrame>
{

    private AmazonKinesis _kinesisClient;
    private String _streamName;
    ObjectMapper _jsonMapper;

    public KinesisDataSender(AmazonKinesis kinesisClient, String streamName)
    {
        _kinesisClient = kinesisClient;
        _streamName = streamName;
        _jsonMapper = new ObjectMapper();
    }


    public void send(MetaFrame message) throws Exception
    {
        byte[] bytes = _jsonMapper.writeValueAsBytes(message); // Json as a byte array

        PutRecordRequest putRecord = new PutRecordRequest();
        putRecord.setStreamName(_streamName);
        putRecord.setPartitionKey(Long.toString(message.getFrameId()));
        putRecord.setData(ByteBuffer.wrap(bytes));

        try
        {
            _kinesisClient.putRecord(putRecord);
        }
        catch (AmazonClientException ex)
        {
            throw new Exception("Error sending record to Amazon Kinesis. Record is: " + message.toString() , ex);
        }
    }
}
