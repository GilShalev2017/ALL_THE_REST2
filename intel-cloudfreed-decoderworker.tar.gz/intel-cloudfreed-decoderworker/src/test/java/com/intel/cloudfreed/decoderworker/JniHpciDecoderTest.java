package com.intel.cloudfreed.decoderworker;

import com.intel.cloudfreed.decoder.interfaces.IDecoder;
import com.intel.cloudfreed.decoder.jnihpci.JniHpciDecoder;
import com.intel.cloudfreed.framecomposer.instrumental.FrameComposerWithMetrics;
import com.intel.cloudfreed.framecomposer.interfaces.GetMetaResult;
import com.intel.cloudfreed.framecomposer.interfaces.IFrameComposer;
import com.intel.cloudfreed.framecomposer.jnihpci.JniHpciFrameComposer;
import com.intel.cloudfreed.frameconverter.FrameConverterWithMetrics;
import com.intel.cloudfreed.frameconverter.IFrameConverter;
import com.intel.cloudfreed.frameconverter.TiffFrameConverter;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import java.nio.file.Files;

import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.Assert.*;


public class JniHpciDecoderTest
{
    Logger _logger = LoggerFactory.getLogger(JniHpciDecoderTest.class);

    @Ignore
    @Test
    public void Decode_HpciTestFiles_OneFileWasDecoded() throws Exception
    {
        IFrameComposer composer = new FrameComposerWithMetrics(new JniHpciFrameComposer(), LoggerFactory.getILoggerFactory());

        IDecoder decoder =  new JniHpciDecoder(3600, 2160); // 1920 1080

        IFrameConverter converter = new FrameConverterWithMetrics(new TiffFrameConverter(3600, 2160), LoggerFactory.getILoggerFactory());

        //for (int i = 1; i <= 30; i++)
        {
            String filePath = "/home/ubu-admin/projects-new/intel-cloudfreed-decoderworker/libs/frame136341.264";

            byte[] infile = Files.readAllBytes(Paths.get(filePath));

            ByteBuffer bufferIn = ByteBuffer.allocateDirect(infile.length);

            bufferIn.put(infile);

            bufferIn.rewind();

            // parse header
            GetMetaResult meta = composer.getMeta(bufferIn);

            // print meta
            _logger.info("process frame meta: " + meta);

            // cut raw frame
            ByteBuffer rawFrame = ByteBuffer.allocateDirect(bufferIn.remaining() - (int)meta.getBodyOffset());

            rawFrame.put(bufferIn.array(), (int)meta.getBodyOffset(), bufferIn.remaining() - (int)meta.getBodyOffset()).rewind();

            _logger.info("headless file size: " + rawFrame.remaining());

            ByteBuffer bufferOut = decoder.Decode(rawFrame);

            if(bufferOut == null)
            {
                _logger.error("Decode failed!");
            }
            else
            {
                ByteBuffer tiffBuffer = converter.convert(bufferOut);

                String fileOutPath = "/home/ubuntu/mszero-test/output/" + ".tiff";

                FileChannel fc = new FileOutputStream(fileOutPath).getChannel();

                fc.write(tiffBuffer);

                fc.close();
            }
        }
    }

    @Ignore
    @Test
    public void Decode_HpciTestFiles_FilesWereDecoded() throws Exception
    {
        IDecoder decoder =  new JniHpciDecoder(1800, 1080); // 1920 1080

        for (int i = 1; i <= 30; i++)
        {
            String filePath = "/home/ubuntu/projects/Intel.CloudFreed.Decoder.DemoApp/tests/resources/encoder0_hd/frame" + String.valueOf(i) + ".h264";
            byte[] infile = Files.readAllBytes(Paths.get(filePath));

            ByteBuffer bufferIn = ByteBuffer.allocateDirect(infile.length);
            bufferIn.put(infile);
            bufferIn.rewind();

            ByteBuffer bufferOut = decoder.Decode(bufferIn);

            if(bufferOut == null)
            {
                _logger.info("Decode returns 'NULL'");
            }
            else
            {
                _logger.info("Decode returns 'Buffer'");

                String fileOutPath = "/home/ubuntu/projects/Intel.CloudFreed.Decoder.DemoApp/tests/resources/encoder0_hd-output/frame" + String.valueOf(i) + ".rgb";

                FileChannel fc = new FileOutputStream(fileOutPath).getChannel();
                fc.write(bufferOut);
                fc.close();
            }
        }
    }

    @Ignore
    @Test
    public void Decode_GroupOfMs1Files_FilesWereDecoded() throws Exception
    {
        IDecoder decoder =  new JniHpciDecoder(3600, 2160); // 1920 1080

        for (int i = 135622; i <= 135658; i++)
        {
            String filePath = "/home/ubuntu/input/" + String.valueOf(i) + ".h264";
            byte[] infile = Files.readAllBytes(Paths.get(filePath));

            ByteBuffer bufferIn = ByteBuffer.allocateDirect(infile.length);
            bufferIn.put(infile);
            bufferIn.rewind();

            ByteBuffer bufferOut = decoder.Decode(bufferIn);

            if(bufferOut == null)
            {
                _logger.info("Decode returns 'NULL'");
            }
            else
            {
                _logger.info("Decode returns 'Buffer'");

                String fileOutPath = "/home/ubuntu/output/" + String.valueOf(i) + ".rgb";

                FileChannel fc = new FileOutputStream(fileOutPath).getChannel();
                fc.write(bufferOut);
                fc.close();
            }
        }
    }

    @Ignore
    @Test
    public void MsZero() throws Exception
    {
        IFrameComposer composer = new FrameComposerWithMetrics(new JniHpciFrameComposer(), LoggerFactory.getILoggerFactory());
        IDecoder decoder =  new JniHpciDecoder(3600, 2160); // 1920 1080
        IFrameConverter converter = new FrameConverterWithMetrics(new TiffFrameConverter(3600, 2160), LoggerFactory.getILoggerFactory());

        for (int i = 135627; i <= 135628; i++)
        {
            //String filePath = "/home/ubuntu/mszero-test/input/frame" + String.valueOf(i) + ".264";
            String filePath = "/home/ubu-admin/projects-new/intel-cloudfreed-decoderworker/libs/frame" + String.valueOf(i) + ".264";
            //String filePath = "/home/ubu-admin/projects-new/intel-cloudfreed-decoderworker/libs/frame136341.264"; //fail
            //String filePath = "/home/ubu-admin/projects-new/intel-cloudfreed-decoderworker/libs/frame136317.264";
            //String filePath = "/home/ubu-admin/projects-new/intel-cloudfreed-decoderworker/libs/frame136318.264";
            //String filePath = "/home/ubu-admin/projects-new/intel-cloudfreed-decoderworker/libs/frame135627.264";
            //String filePath = "/home/ubu-admin/projects-new/intel-cloudfreed-decoderworker/libs/frame135628.264";

            byte[] infile = Files.readAllBytes(Paths.get(filePath));

            ByteBuffer frame = ByteBuffer.allocate(infile.length);
            frame.put(infile);
            frame.rewind();

            // parse header
            GetMetaResult meta = composer.getMeta(frame);

            // print meta
            _logger.info("process frame meta: " + meta);

            // cut raw frame
            ByteBuffer rawFrame = ByteBuffer.allocateDirect(frame.remaining() - (int)meta.getBodyOffset());
            rawFrame.put(frame.array(), (int)meta.getBodyOffset(), frame.remaining() - (int)meta.getBodyOffset()).rewind();

            _logger.info("headless file size: " + rawFrame.remaining());

            ByteBuffer bufferOut = decoder.Decode(rawFrame);

            if(bufferOut == null)
            {
                _logger.error("Decode failed!");
            }
            else
            {
                ByteBuffer tiffBuffer = converter.convert(bufferOut);

                String fileOutPath = "/home/ubuntu/mszero-test/output/" + /*String.valueOf(i) +*/ ".tiff";

                FileChannel fc = new FileOutputStream(fileOutPath).getChannel();
                fc.write(tiffBuffer);
                fc.close();
            }
        }
    }



}


