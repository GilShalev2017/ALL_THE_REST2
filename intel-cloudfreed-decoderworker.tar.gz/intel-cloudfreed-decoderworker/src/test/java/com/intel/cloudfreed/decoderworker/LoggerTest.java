package com.intel.cloudfreed.decoderworker;

import com.intel.cloudfreed.decoderworker.framevisitor.FrameProcessor;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoggerTest
{
    @Test
    public void writeSomeLogs()
    {
        Logger logger = LoggerFactory.getLogger(LoggerTest.class);
        logger.info("Hello logging!");
    }
}
