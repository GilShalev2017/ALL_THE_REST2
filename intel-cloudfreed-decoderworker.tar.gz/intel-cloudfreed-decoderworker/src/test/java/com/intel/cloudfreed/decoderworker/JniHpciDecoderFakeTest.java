package com.intel.cloudfreed.decoderworker;


import com.intel.cloudfreed.decoder.interfaces.IDecoder;
import com.intel.cloudfreed.decoder.jnihpci.JniHpciDecoder;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import static org.junit.Assert.*;

import java.nio.ByteBuffer;

// Notes: Tasts are focused on JNI and based on Native FakeDecoder!.

@Ignore
public class JniHpciDecoderFakeTest
{
    Logger _logger = LoggerFactory.getLogger(JniHpciDecoderFakeTest.class);


    @Test(expected = IllegalArgumentException.class)
    public void Decode_NonDirectInBuffer_ThrowsException() throws Exception
    {
        _logger.info("Test: Decode_NonDirectInBuffer_ThrowsException");

        IDecoder decoder = new JniHpciDecoder(1920, 1080, true);

        ByteBuffer bufferIn = ByteBuffer.allocate(5);
        ByteBuffer bufferOut = decoder.Decode(bufferIn);
    }

    @Test
    public void Decode_EmptyInput_NullWasReturned() throws Exception
    {
        _logger.info("Test: Decode_EmptyInput_NullWasReturned");

        IDecoder decoder =  new JniHpciDecoder(1920, 1080, true);

        ByteBuffer bufferIn = ByteBuffer.allocateDirect(0);


        ByteBuffer bufferOut = decoder.Decode(bufferIn);

        assertNull(bufferOut);
    }


    @Test
    public void Decode_RunOnce_BufferWasModified() throws Exception
    {
        _logger.info("Test: Decode_RunOnce_BufferWasModified");

        IDecoder decoder =  new JniHpciDecoder(1920, 1080, true);

        ByteBuffer bufferIn = ByteBuffer.allocateDirect(5);
        bufferIn.put(0, (byte)7);
        bufferIn.put(1, (byte)7);
        bufferIn.put(2, (byte)7);


        ByteBuffer bufferOut = decoder.Decode(bufferIn);

        _logger.info("bufferOut:" + bufferOut.toString());
        _logger.info("bufferOut:" + String.valueOf((int)bufferOut.get(0)) + String.valueOf((int)bufferOut.get(1)) + String.valueOf((int)bufferOut.get(2)));

        assertEquals(8, (int)bufferOut.get(0));
        assertEquals(8, (int)bufferOut.get(1));
        assertEquals(8, (int)bufferOut.get(2));
    }

    @Ignore
    public void Decode_RunDecoder1000Times_MemoryShouldNotHaveToLeak() throws Exception
    {
        _logger.info("Test: Decode_RunDecoder1000Times_MemoryShouldNotHaveToLeak");

        IDecoder decoder =  new JniHpciDecoder(1920, 1080, true);

        for (int i = 0; i < 1000; i++) {

            ByteBuffer bufferIn = ByteBuffer.allocateDirect(5);
            bufferIn.put(0, (byte)7);
            bufferIn.put(1, (byte)7);
            bufferIn.put(2, (byte)7);


            ByteBuffer bufferOut = decoder.Decode(bufferIn);

            _logger.info("bufferOut:" + String.valueOf((int)bufferOut.get(0)) + String.valueOf((int)bufferOut.get(1)) + String.valueOf((int)bufferOut.get(2)));

            Thread.sleep(100);
        }
    }
}
