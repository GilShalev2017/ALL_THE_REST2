package com.intel.cloudfreed.decoderworker;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.intel.cloudfreed.metafeed.interfaces.MetaFrame;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.Charset;
import java.util.Base64;

public class JsonTest
{
    @Test
    public void writeSomeLogs() throws Exception
    {
        ObjectMapper jsonMapper = new ObjectMapper();
        MetaFrame message = new MetaFrame(1,1,1,"aaa");

        byte[] bytes = jsonMapper.writeValueAsBytes(message);


        String jsonString = jsonMapper.writeValueAsString(message);

        String result = new String(bytes, Charset.forName("UTF-8"));

        String base64 = Base64.getEncoder().encodeToString(bytes);

        String hex = bytesToHex(bytes);
    }

    private final static char[] hexArray = "0123456789ABCDEF".toCharArray();
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for ( int j = 0; j < bytes.length; j++ ) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }
}
