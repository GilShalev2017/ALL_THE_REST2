package com.intel.cloudfreed.decoderworker;


import com.amazonaws.kinesisvideo.parser.mkv.Frame;
import com.intel.cloudfreed.decoder.interfaces.IDecoder;
import com.intel.cloudfreed.decoderworker.framevisitor.FrameProcessor;
import com.intel.cloudfreed.decoderworker.sender.ISender;
import com.intel.cloudfreed.decoderworker.storage.IStorage;
import com.intel.cloudfreed.framecomposer.interfaces.GetMetaResult;
import com.intel.cloudfreed.framecomposer.interfaces.IFrameComposer;
import com.intel.cloudfreed.frameconverter.IFrameConverter;
import com.intel.cloudfreed.metafeed.interfaces.MetaFrame;
import org.junit.Test;
import org.mockito.ArgumentMatchers;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

public class FrameProcessorTest
{
    @Test
    public void Process_ValidInput_RawFrameWasRetrievedAndPassedToDecoder()
    {
        // Arrange:
        Frame frame = Frame.builder().frameData(ByteBuffer.wrap(new byte[]{1,2,3,4})).build();

        IFrameComposer composer = mock(IFrameComposer.class);
        when(composer.getMeta(frame.getFrameData())).thenReturn(new GetMetaResult(1, 2, 2, 0));

        IDecoder decoder = mock(IDecoder.class);
        IFrameConverter converter = mock(IFrameConverter.class);
        IStorage storage = mock(IStorage.class);
        ISender<MetaFrame> sender = mock(ISender.class);
        ILoggerFactory loggerFactory = LoggerFactory.getILoggerFactory(); // mock(ILoggerFactory.class);
        FrameProcessor frameProcessor = new FrameProcessor(1, "c:\\out\\{0}.h264", composer, decoder, converter, storage, sender, loggerFactory);


        // Act:

        frameProcessor.process(frame, null, Optional.empty(), Optional.empty());

        // Assert:
        verify(decoder).Decode(ArgumentMatchers.eq(ByteBuffer.wrap(new byte[]{3,4})));
    }

    @Test
    public void Process_ValidInput_ValidMessageWasSent() throws Exception
    {
        // Arrange:
        Frame frame = Frame.builder().frameData(ByteBuffer.wrap(new byte[]{1,2,3,4})).build();

        IFrameComposer composer = mock(IFrameComposer.class);
        when(composer.getMeta(frame.getFrameData())).thenReturn(new GetMetaResult(1,2, 2, 0));

        IDecoder decoder = mock(IDecoder.class);
        when(decoder.Decode(any(ByteBuffer.class))).thenReturn(ByteBuffer.wrap(new byte[]{1,2,3,4}));
        IFrameConverter converter = mock(IFrameConverter.class);
        IStorage storage = mock(IStorage.class);
        ISender<MetaFrame> sender = mock(ISender.class);
        ILoggerFactory loggerFactory = LoggerFactory.getILoggerFactory(); // mock(ILoggerFactory.class);
        FrameProcessor frameProcessor = new FrameProcessor(1, "c:\\out\\{0}.h264", composer, decoder, converter, storage, sender, loggerFactory);


        // Act:
        frameProcessor.process(frame, null, Optional.empty(), Optional.empty());


        // Assert:
        verify(sender).send(ArgumentMatchers.eq(new MetaFrame(1,1,2, "c:\\out\\1.h264")));
    }
}

