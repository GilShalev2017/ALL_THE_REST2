package com.intel.cloudfreed.decoderworker;

import com.intel.cloudfreed.frameconverter.FrameConverterWithMetrics;
import com.intel.cloudfreed.frameconverter.IFrameConverter;
import com.intel.cloudfreed.frameconverter.TiffFrameConverter;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Paths;

@Ignore
public class TiffFrameConverterTest {

    @Test
    public void convert_30mbRgbFile_ConvertedToTiff() throws Exception
    {
        IFrameConverter converter = new FrameConverterWithMetrics(new TiffFrameConverter(3600, 2160), LoggerFactory.getILoggerFactory());

        String filePath = "D:\\135628.rgb";
        byte[] infile = Files.readAllBytes(Paths.get(filePath));

        //ByteBuffer bufferIn = ByteBuffer.allocateDirect(infile.length);
        //bufferIn.put(infile);
        //bufferIn.rewind();

        //Act:
        ByteBuffer bufferOut = converter.convert(ByteBuffer.wrap(infile));

        String fileOutPath = "D:\\135628.tiff";

        FileChannel fc = new FileOutputStream(fileOutPath).getChannel();
        fc.write(bufferOut);
        fc.close();
    }

    @Test
    public void convert_30mbRgbFileAsDirectBuffer_ConvertedToTiff() throws Exception
    {
        IFrameConverter converter = new TiffFrameConverter(3600, 2160);

        String filePath = "/home/ubuntu/output/135628.rgb";
        byte[] infile = Files.readAllBytes(Paths.get(filePath));

        ByteBuffer bufferIn = ByteBuffer.allocateDirect(infile.length);
        bufferIn.put(infile);
        bufferIn.rewind();

        //Act:
        ByteBuffer bufferOut = converter.convert(bufferIn);

        String fileOutPath = "/home/ubuntu/output/135628.tiff";

        FileChannel fc = new FileOutputStream(fileOutPath).getChannel();
        fc.write(bufferOut);
        fc.close();
    }
}
