#ifndef STORAGEAPI_H
#define STORAGEAPI_H

#include <string>
#include <functional>

#include "storageapi_export.h" 

#ifdef STORAGEAPI_STATIC_DEFINE
#undef STORAGEAPI_EXPORT
#define STORAGEAPI_EXPORT
#endif

namespace storageapi {

typedef std::function<void*(size_t)> alloc_func_t;

class STORAGEAPI_EXPORT StorageAPI {
public:

public:
    /* Constructor */
    StorageAPI();
    
    /* Destructor */
    ~StorageAPI();

    /* Write file */
    bool WriteFile(const std::string &storage_url, const void *buffer, uint64_t file_size, std::string &errorMsg);

    /* Read file into pre-alocated buffer */
    bool ReadFile(const std::string &storage_url, void *buffer, uint64_t buf_size, uint64_t &file_size, std::string &errorMsg);

    /* Read file into a buffer that is allocated using the allocate function */
    bool ReadFile(const std::string &storage_url, alloc_func_t allocate, std::string &errorMsg);
    
private:
    /* Read file from filesystem (local or mounted) */
    bool ReadFileFromFS(const std::string &storage_url, alloc_func_t allocate, std::string &errorMsg);
    /* Write file to filesystem */
    bool WriteFileToFS(const std::string &storage_url, const void *buffer, uint64_t file_size, std::string &errorMsg);

    /* Read file from Redis */
    bool ReadFileFromRedis(const std::string &storage_url, alloc_func_t allocate, std::string &errorMsg);
    /* Write file to Redis */
    bool WriteFileToRedis(const std::string &storage_url, const void *buffer, uint64_t file_size, std::string &errorMsg);

    /* Read file from S3 */
    bool ReadFileFromS3(const std::string &storage_url, alloc_func_t allocate, std::string &errorMsg);
    /* Write file to S3 */
    bool WriteFileToS3(const std::string &storage_url, const void *buffer, uint64_t file_size, std::string &errorMsg);

private:
    class _private;
    class StorageAPI::_private *m;
};

}
#endif