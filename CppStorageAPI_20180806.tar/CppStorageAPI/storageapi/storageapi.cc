/*
 * StorageAPI main module
 */

#include "storageapi.h"

#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <thread>
#include <mutex>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>


#if ENABLE_REDIS
#include "RedisClient.h"
#endif

#if ENABLE_S3
#include <aws/core/Aws.h>
#include <aws/core/client/ClientConfiguration.h>
#include <aws/core/utils/threading/Executor.h>
#include <aws/s3/S3Client.h>
#include <aws/s3/model/GetObjectRequest.h>
#include <aws/transfer/TransferManager.h>
#endif

#include <streambuf>

const int maxConnections = 200;

template <typename char_type>
struct ostreambuf : public std::basic_streambuf<char_type, std::char_traits<char_type> >
{
    ostreambuf(char_type* buffer, std::streamsize bufferLength)
    {
        // set the "put" pointer the start of the buffer and record it's length.
        this->setp(buffer, buffer + bufferLength);
    }
};

namespace storageapi {

#if ENABLE_S3
/** Ensures that the AWS library is only initialized once per process. */
static std::once_flag aws_lib_initialized;

/** AWS options. */
static Aws::SDKOptions options_;

static const char* ALLOC_TAG = "StorageAPI";

void SetupAWSLibrary() {
   std::cout << "Initializing AWS API" << std::endl;
   Aws::InitAPI(options_);
}
#endif

#if ENABLE_REDIS
static const char* redis_host_ = NULL;
static int redis_port_ = 0;

void SetupRedis() {
   redis_host_ = getenv("REDIS_HOST");
   if (!redis_host_) {
     redis_host_ = "localhost";
   }
   redis_port_ = 6379;
   const char *port = getenv("REDIS_PORT");
   if (port) {
       redis_port_ = strtol(port, NULL, 10);
   }
}
#endif

static void mkparentdir(const std::string &path) {
   std::string parent = path.substr(0, path.rfind('/'));
   std::cout << "MkParentDir = " << parent << std::endl;
   if (mkdir(parent.c_str(), 0777)) {
      if (errno == ENOENT) {
        // Parent dir does not exit
        mkparentdir(parent);
        (void) mkdir(parent.c_str(), 0777);
      }
   }
}

class StorageAPI::_private {
public:
#if ENABLE_S3
   std::shared_ptr<Aws::S3::S3Client> client;
#endif
#if ENABLE_REDIS
   CRedisClient redisClient;
#endif
};

StorageAPI::StorageAPI() {
   m = new _private();

#if ENABLE_S3
   m->client = nullptr;
   // Initialize the library once per process.
   std::call_once(aws_lib_initialized, SetupAWSLibrary);

   Aws::Client::ClientConfiguration config;
   
   config.region = "us-west-1";
   if (getenv("AWS_REGION")) {
     config.region = getenv("AWS_REGION");
   }
   config.proxyScheme = Aws::Http::Scheme::HTTPS;
   if (getenv("https_proxy")) {
     config.proxyHost = "proxy-us.intel.com";
     config.proxyPort = 911;
   }
   config.scheme = Aws::Http::Scheme::HTTPS;
   config.maxConnections = maxConnections;
   
   std::cout << "Creating AWS S3 Client AWS_REGION=" << config.region << " Proxy=" << config.proxyHost << std::endl;

   // Connect S3 client
   m->client = Aws::MakeShared<Aws::S3::S3Client>(
      ALLOC_TAG,
      config,
      Aws::Client::AWSAuthV4Signer::PayloadSigningPolicy::Never);
#endif
      
#if ENABLE_REDIS
   SetupRedis();
   std::cout << "Connecting to Redis at " << redis_host_ << ":" << redis_port_ << std::endl;
   m->redisClient.Initialize(redis_host_, redis_port_, 2, 10);
#endif
}

StorageAPI::~StorageAPI() {
#if ENABLE_S3
   std::cout << "Deleting AWS S3 Client" << std::endl;
   m->client = nullptr;
#endif
   delete m;
   m = NULL;
}

bool starts_with(const std::string& value, const std::string& prefix) {
  if (prefix.size() > value.size())
    return false;
  return std::equal(prefix.begin(), prefix.end(), value.begin());
}

bool StorageAPI::ReadFileFromFS(const std::string &storage_url, alloc_func_t allocate, std::string &errorMsg)
{
   if (!starts_with(storage_url, "file://")) {
      std::cerr << "StorageAPI::ReadFileFromFS received invalid/unsupported storage_url: " << storage_url << std::endl;
      errorMsg = "INVALID_REQUEST:Unsupported URL scheme for storage_url";
      return false;
   }

   std::string storage_path = storage_url.substr(7);
   std::cout << "Reading from " << storage_path << std::endl;

   std::ifstream file (storage_path, std::ifstream::in|std::ifstream::binary|std::ifstream::ate);
   if (!file) {
     errorMsg = "FILE_OPEN:Could not open file for reading";
     return false;
   }
   file.seekg (0, file.end);
   long long content_length = file.tellg();
   file.seekg (0, file.beg);
   char *buffer = (char *) allocate(content_length);
   if (!buffer) {
     errorMsg = "ALLOCATE:Could not allocate file buffer";
     return false;
   }

   file.read (buffer, content_length);
   
   std::cout << "Read " << file.gcount() << " bytes out of " << std::to_string(content_length) << " bytes total" << std::endl;
   
   if (!file) {
     errorMsg = "PARTIAL_READ:Could not read entire file";
     return false;
   }
   
   errorMsg = "OK";
   return true;
}

bool StorageAPI::ReadFileFromRedis(const std::string &storage_url, alloc_func_t allocate, std::string &errorMsg)
{
   (void) storage_url;
   
   size_t file_size = 42; // TODO: Determine file size
   void *buffer = allocate(file_size);
   if (!buffer) {
     errorMsg = "ALLOCATE:Could not allocate file buffer";
     return false;
   }
   
   (void) buffer; // TODO: Read file into buffer
   
   errorMsg = "NOT_IMPLEMENTED:ReadFileFromRedis not implemented";
   return false;
}

bool StorageAPI::ReadFileFromS3(const std::string &storage_url, alloc_func_t allocate, std::string &errorMsg)
{
   if (!starts_with(storage_url, "s3://")) {
      std::cerr << "StorageAPI::ReadFileFromS3 received invalid/unsupported storage_url: " << storage_url << std::endl;
      errorMsg = "INVALID_REQUEST:Unsupported URL scheme for storage_url";
      return false;
   }

#if ENABLE_S3
   std::string storage_path = storage_url.substr(5);
   std::cout << "Downloading from " << storage_path << std::endl;

   Aws::Http::URI aws_uri = storage_url.c_str();
   Aws::S3::Model::GetObjectRequest get_object_request;
   get_object_request.WithBucket(aws_uri.GetAuthority()).WithKey(aws_uri.GetPath());
   
   auto get_object_outcome = m->client->GetObject(get_object_request);
   
   if (!get_object_outcome.IsSuccess()) {
      std::cerr << "AWS S3 GetObject failed" << std::endl <<
         "Exception: " << get_object_outcome.GetError().GetExceptionName().c_str() << std::endl <<
         "ErrorMesg: " << get_object_outcome.GetError().GetMessage().c_str() << std::endl;
      errorMsg = "AWS_ERROR:";
      return false;
   }

   long long content_length = get_object_outcome.GetResult().GetContentLength();
   std::cout << "AWS S3 GetObject success, ContentLength = " << content_length << std::endl;

   void *buffer = allocate(content_length);
   if (!buffer) {
     errorMsg = "ALLOCATE:Could not allocate file buffer";
     return false;
   }
   
   ostreambuf<char> ostreamBuffer((char *)buffer, content_length);
   std::ostream bufStream(&ostreamBuffer);

   bufStream << get_object_outcome.GetResult().GetBody().rdbuf();
   
//   std::cout << "In-Memory Content Size: " << content.size() << std::endl;

//   if (content_length != (long long) content.size()) {
//     return std::string("ERROR:PARTIAL_READ:Could not read entire file"); 
//   }

   errorMsg = "OK";
   return true;
#else
   (void) allocate; // Unused

   errorMsg = "INVALID_REQUEST:No S3 support compiled in";
   return false;
#endif
}


/* Write file to filesystem */
bool StorageAPI::WriteFileToFS(const std::string &storage_url, const void *buffer, uint64_t file_size, std::string &errorMsg)
{
   if (!starts_with(storage_url, "file://")) {
      std::cerr << "StorageAPI::WriteFileToFS received invalid/unsupported storage_url: " << storage_url << std::endl;
      errorMsg = "INVALID_REQUEST:Unsupported URL scheme for storage_url";
      return false;
   }

   std::string storage_path = storage_url.substr(7);
   std::cout << "Writing to " << storage_path << std::endl;
   mkparentdir(storage_path);

   std::ofstream ofile (storage_path, std::ofstream::binary);
   if (!ofile) {
     errorMsg = "FILE_OPEN:Could not open file for writing";
     return false;
   }

   ofile.write((const char *) buffer, file_size);
   ofile.close();

   if (!ofile) {
     errorMsg = "FILE_WRITE:Could not write entire file";
     return false;
   }

   // Sync file to storage
   int fd = open(storage_path.c_str(), O_WRONLY | O_APPEND | O_CREAT, S_IRWXU);
   if (fd == -1) {
     errorMsg = "FILE_OPEN:Could not open file to sync";
     return false;
   }
   if (fsync(fd) != 0) {
      close(fd);
      errorMsg = "SYNC:File sync failed";
      return false;
   }
   close(fd);

   errorMsg = "OK";
   return true;
}

/* Write file to Redis */
bool StorageAPI::WriteFileToRedis(const std::string &storage_url, const void *buffer, uint64_t file_size, std::string &errorMsg)
{
   if (!starts_with(storage_url, "red://")) {
      std::cerr << "StorageAPI::WriteFileToRedis received invalid/unsupported storage_url: " << storage_url << std::endl;
      errorMsg = "INVALID_REQUEST:Unsupported URL scheme for storage_url";
      return false;
   }
   
   (void) buffer; // Unused
   (void) file_size; // Unused
   
   errorMsg = "NOT_IMPLEMENTED:WriteFileToRedis not implemented";
   return false;
}

/* Write file to S3 */
bool StorageAPI::WriteFileToS3(const std::string &storage_url, const void *buffer, uint64_t file_size, std::string &errorMsg)
{
   if (!starts_with(storage_url, "s3://")) {
      std::cerr << "StorageAPI::WriteFileToS3 received invalid/unsupported storage_url: " << storage_url << std::endl;
      errorMsg = "INVALID_REQUEST:Unsupported URL scheme for storage_url";
      return false;
   }

#if ENABLE_S3
   std::cout << "Writing to " << storage_url << std::endl;

   Aws::Http::URI aws_uri = storage_url.c_str();
   Aws::S3::Model::PutObjectRequest put_object_request;
   put_object_request.WithBucket(aws_uri.GetAuthority()).WithKey(aws_uri.GetPath());
   
   //auto sstream = std::make_shared<std::stringstream>(std::stringstream::out);
   //sstream->write((const char*)buffer, file_size);
   
   auto sstream = std::make_shared<std::stringstream>(std::stringstream::in);
   sstream->rdbuf()->pubsetbuf((char*)buffer, file_size);
   
   put_object_request.SetBody(sstream);
   
   auto put_object_outcome = m->client->PutObject(put_object_request);
   if (!put_object_outcome.IsSuccess()) {
      std::cerr << "AWS S3 PutObject failed" << std::endl <<
         "Exception: " << put_object_outcome.GetError().GetExceptionName().c_str() << std::endl <<
         "ErrorMesg: " << put_object_outcome.GetError().GetMessage().c_str() << std::endl;
      errorMsg = "AWS_ERROR:";
      return false;
   }
   
   errorMsg = "OK";
   return true;
#else
   (void) buffer; // Unused
   (void) file_size; // Unused

   errorMsg = "INVALID_REQUEST:No S3 support compiled in";
   return false;
#endif
}


/* Write file */
bool StorageAPI::WriteFile(const std::string &storage_url, const void *buffer, uint64_t file_size, std::string &errorMsg)
{
   if (starts_with(storage_url, "file://")) {
      return WriteFileToFS(storage_url, buffer, file_size, errorMsg);
   }

#if ENABLE_REDIS
   if (starts_with(storage_url, "red://")) {
      return WriteFileToRedis(storage_url, buffer, file_size, errorMsg);
   }
#endif

#if ENABLE_S3
   if (starts_with(storage_url, "s3://")) {
      return WriteFileToS3(storage_url, buffer, file_size, errorMsg);
   }
#endif
 
   std::cerr << "StorageAPI::WriteFile received invalid/unsupported storage_url: " << storage_url << std::endl;
   errorMsg = "INVALID_REQUEST:Unsupported URL scheme for storage_url";
   return false;
}


/* Read file into a buffer that is allocated using the allocate function */
bool StorageAPI::ReadFile(const std::string &storage_url, alloc_func_t allocate, std::string &errorMsg)
{
   if (starts_with(storage_url, "file://")) {
      return ReadFileFromFS(storage_url, allocate, errorMsg);
   }

#if ENABLE_REDIS
   if (starts_with(storage_url, "red://")) {
      return ReadFileFromRedis(storage_url, allocate, errorMsg);
   }
#endif

#if ENABLE_S3
   if (starts_with(storage_url, "s3://")) {
      return ReadFileFromS3(storage_url, allocate, errorMsg);
   }
#endif
 
   std::cerr << "StorageAPI::ReadFile received invalid/unsupported storage_url: " << storage_url << std::endl;
   errorMsg = "INVALID_REQUEST:Unsupported URL scheme for storage_url";
   return false;
}

/* Read file into pre-allocated buffer */
bool StorageAPI::ReadFile(const std::string &storage_url, void *buffer, uint64_t buf_size, uint64_t &file_size, std::string &errorMsg)
{
   alloc_func_t allocate = [buf_size, buffer, &file_size] (size_t size) -> void * {
      if (size > buf_size) return NULL;
      file_size = size;
      return buffer;
   };
   
   return ReadFile(storage_url, allocate, errorMsg);
}


#if 0
/* Read file into a dynamically allocated buffer */
//bool StorageAPI::ReadFile(const std::string &storage_url, void *&buffer, uint64_t &buf_size, uint64_t &file_size, std::string &errorMsg)
bool StorageAPI::ReadFile(const std::string &storage_url )
{
   struct {
      bool ok;
      std::string errorMsg;
      jobject byte_buffer;
   } result;

   void *buffer;
   jlong file_size;

   alloc_func_t allocate = [&buffer, &file_size] (size_t size) -> void * {
      buffer = malloc(size);
      file_size = size;
      return buffer;
   };
   
   result.ok = ReadFile(storage_url, allocate, result.errorMsg);
   // NewDirectByteBuffer(JNIEnv* env, void* address, jlong capacity);
   result.byte_buffer = NewDirectByteBuffer(jni_env, buffer, file_size);
   return result;
}

#endif



}
