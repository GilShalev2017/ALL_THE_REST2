
#include "storageapi.h"

#include <iostream>
#include <memory>
#include <string.h>

int show_help()
{
    printf("Usage: storageapi read <storage_url>\n");
    printf("Usgae: storageapi write <storage_url>\n");
    return -1;
}

int main(int argc, char** argv )
{
    std::string errorMsg;
    if ( argc < 2 ) return show_help();

    std::string operation = argv[1];
    if (operation == "read") {
        if ( argc < 3 ) return show_help();
        std::string storage_url = argv[2];
        std::cout << "Reading from " << storage_url << std::endl;
        
        std::shared_ptr<storageapi::StorageAPI> client = std::make_shared<storageapi::StorageAPI>();
        size_t buffer_size = 1024*1024;
        void *buffer = malloc(buffer_size);
        size_t file_size = 0;
        bool result = client->ReadFile(storage_url, buffer, buffer_size, file_size, errorMsg);
        ((char *)buffer)[file_size] = 0;
        std::cout << "Result: " << result << " errorMsg: " << errorMsg << " Size: " << file_size << std::endl;
        std::cout << "Content: " << (char *) buffer << std::endl;
    }
    else if (operation == "write") {
        if ( argc < 3 ) return show_help();
        std::string storage_url = argv[2];
        std::cout << "Writing to " << storage_url << std::endl;
        
        std::shared_ptr<storageapi::StorageAPI> client = std::make_shared<storageapi::StorageAPI>();
        const char *buffer = "The quick brown fox jumps over the lazy dog.\n\nThe End.\n";
        size_t file_size = strlen(buffer);
        bool result = client->WriteFile(storage_url, (void *) buffer, file_size, errorMsg);
        std::cout << "Result: " << result << " errorMsg: " << errorMsg << " Size: " << file_size << std::endl;
        std::cout << "Content: " << (char *) buffer << std::endl;
    }
    else {
        return show_help();
    }
    
    return 0;
}
