// Import dependencies
const mongoose = require('mongoose');
const express = require('express');
const router = express.Router();

// MongoDB URL from the docker-compose file
//const dbHost = 'mongodb://database/cinema-docker';
const dbHost = process.env.MONGO_DB_CONNECTION_URI;

// Connect to mongodb
mongoose.connect(dbHost);


let Movie = require('../model/Movie');
let Show = require('../model/Show.js');

// Add Movie
router.route('/add-movie').post((req, res, next) => {
    Movie.create(req.body, (error, data) => {
    if (error) {
      return next(error)
    } else {
      res.json(data)
    }
  })
});

// Add Show
router.route('/add-show').post((req, res, next) => {
  Show.create(req.body, (error, data) => {
    if (error) {
      return next(error)
    } else {
      res.json(data)
    }
  })
});

// Get All Movies
router.route('/').get((req, res) => {
    Movie.find((error, data) => {
    if (error) {
      return next(error)
    } else {
      res.json(data)
    }
  })
})

// Get All Shows
router.route('/get-shows').get((req, res) => {
  Show.find((error, data) => {
    if (error) {
      return next(error)
    } else {
      res.json(data)
    }
  })
})

module.exports = router;
