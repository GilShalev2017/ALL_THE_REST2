const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Show = new Schema({
  id: {
    type: String
  },
  // movie: {
  //   type: Movie
  // },
  date: {
    type: String
  },
  time: {
    type: String
  },
  hall: {
    type: String
  },
  movieTitle: {
    type: String
  }
}, {
  collection: 'shows'
})

module.exports = mongoose.model('Show', Show, 'Show')
