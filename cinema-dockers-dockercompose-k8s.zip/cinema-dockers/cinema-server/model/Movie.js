const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Movie = new Schema({
  id: {
    type: String
  },
  title: {
    type: String
  },
  overview: {
    type: String
  },
  posterPath: {
    type: String
  },
  backdropPath: {
    type: String
  }
}, {
  collection: 'movies'
})

module.exports = mongoose.model('Movie', Movie)
