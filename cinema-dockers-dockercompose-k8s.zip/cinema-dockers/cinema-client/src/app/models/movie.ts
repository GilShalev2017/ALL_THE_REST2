export class Movie {
  id: number | undefined;
  title: string | undefined;
  overview: string | undefined;
  posterPath?:string;
  backdropPath?:string;
}
