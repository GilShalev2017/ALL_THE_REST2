export class TmdbMovie {
  id: number | undefined;
  title: string | undefined;
  overview: string | undefined;
  poster_path?:string;
  backdrop_path?:string;
}
