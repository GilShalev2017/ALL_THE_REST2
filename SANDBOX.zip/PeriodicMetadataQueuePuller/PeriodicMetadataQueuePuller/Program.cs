﻿using Newtonsoft.Json;
using System.IO;
using System;
using Common.ClientFactory;
using Amazon.SQS.Model;
using System.Collections.Generic;
using Amazon.Lambda.S3Events;
using Amazon.SQS;
using Common;
using Amazon.S3;
using Common.DTO;
using Amazon.S3.Transfer;
using System.Diagnostics;
using Common.UtilityFunctions;

namespace PeriodicMetadataQueuePuller
{
    class Program
    {
        private static StreamWriter _logFile;
        private static IAmazonS3 _s3Client;
        private static TransferUtility _fileTransferUtility;
        private static Dictionary<string, int> _versionedAssets;
        
        static void Main(string[] args)
        {
            StartLogging(args);

            _versionedAssets = new Dictionary<string, int>();

            var deploymentConfig = UtilityFunctions.LoadDeploymentJsonConfig(args[0]);

            var periodicMetadataSqsPuller = LoadPeriodicMetadataConfig("./periodic-metadata-queue-puller.json");

            Environment.SetEnvironmentVariable(Constants.AWS_REGION, deploymentConfig.periodic_metadata.region);
            Environment.SetEnvironmentVariable(Constants.KINESIS_DATA_STREAM_NAME, deploymentConfig.periodic_metadata.kinesis_data_stream);
            Environment.SetEnvironmentVariable(Constants.DYNAMO_DB_TABLE, deploymentConfig.periodic_metadata.dynamo_db_table);
            //Environment.SetEnvironmentVariable(Constants.DYNAMO_DB_TABLE_LATEST_ASSETS, "pm-latest-asset-table");// deploymentConfig.periodic_metadata.dynamo_db_table_latest_assets);

            _s3Client = ClientFactory.GetS3Client();

            _fileTransferUtility = new TransferUtility(_s3Client);

            Log("\n" + "Periodic Metadata SQS Puller started..." + "\n");
            Log("REGION = " + deploymentConfig.periodic_metadata.region + "\n");
            //Log("KINESIS DATA STREAM = " + deploymentConfig.periodic_metadata.kinesis_data_stream + "\n");
            Log("DYNAMO DB = " + deploymentConfig.periodic_metadata.dynamo_db_table + "\n");
            Log("BUCKET = " + deploymentConfig.periodic_metadata.s3_bucket + "\n");
            
            if (deploymentConfig == null)
            {
                return;
            }

            var sqsClient = ClientFactory.GetSqsClient();

            var watch = Stopwatch.StartNew();

            while (true)
            {
                var request = GetReceiveMessageRequest(deploymentConfig.periodic_metadata.sqs_queue_url,
                                                       periodicMetadataSqsPuller.wait_time_in_seconds,
                                                       periodicMetadataSqsPuller.max_num_of_messages);

                var response = sqsClient.ReceiveMessageAsync(request).Result;

                if (response.Messages.Count > 0)
                {
                    //Parallel.ForEach(response.Messages, new ParallelOptions { MaxDegreeOfParallelism = applicationConfig.ParallelSessions/*response.Messages.Count*/ }, message =>
                    foreach(Message message in response.Messages)
                    {
                        try
                        {
                            RetreiveS3FileKeyAndSize(message.Body, out AssetDetails assetDetails);

                            Log(string.Format("{0} - Saving asset with key: {1} to Lustre, Kinesis and DynamoDB", DateTime.Now.ToLongTimeString(), assetDetails.AssetKey));

                            SaveToLustre(assetDetails.AssetKey, deploymentConfig.periodic_metadata.s3_bucket, deploymentConfig.periodic_metadata.shared_storage_root);

                            UpdateDynamoDBs/*AndKinesisStream*/(assetDetails, "pm-latest-asset-table");// deploymentConfig.periodic_metadata.dynamo_db_table_latest_assets);
                        }
                        catch (Exception xcp)
                        {
                            Console.WriteLine("Exception caught: " + xcp.Message + " At: " + xcp.StackTrace);
                        }
                        finally
                        {
                            RemoveMessageFromQueue(sqsClient, message, deploymentConfig.periodic_metadata.sqs_queue_url);
                        }
                    }
                    //);
                    //);
                }
                else
                {
                    watch.Stop();

                    Log("=== Done downloading ===");

                    Log($"Elapsed {watch.ElapsedMilliseconds / 1000} seconds");

                    Console.WriteLine("No messages received.");
                }
            }
        }

        public static PeriodicMetadataSqsPuller LoadPeriodicMetadataConfig(string appConfigFile)
        {
            PeriodicMetadataSqsPuller config;

            using (StreamReader r = new StreamReader(appConfigFile))
            {
                string json = r.ReadToEnd();

                config = JsonConvert.DeserializeObject<PeriodicMetadataSqsPuller>(json);
            }

            return config;
        }

        private static DeleteMessageRequest GetDeleteMessageRequest(Message message, string sqsQueueUrl)
        {
            var request = new DeleteMessageRequest
            {
                ReceiptHandle = message.ReceiptHandle,
                QueueUrl = sqsQueueUrl
            };

            return request;
        }

        private static void RemoveMessageFromQueue(IAmazonSQS client, Message message, string sqsQueueUrl)
        {
            var deleteRequest = GetDeleteMessageRequest(message, sqsQueueUrl);

            var deleteResponse = client.DeleteMessageAsync(deleteRequest).Result;
        }

        private static ReceiveMessageRequest GetReceiveMessageRequest(string sqsQueueUrl, int waitTimeInSeconds, int maxNumberOfMessages)
        {
            var request = new ReceiveMessageRequest
            {
                AttributeNames = new List<string>() { "All" },
                MaxNumberOfMessages = maxNumberOfMessages,
                QueueUrl = sqsQueueUrl,
                VisibilityTimeout = (int)TimeSpan.FromMinutes(10).TotalSeconds,
                WaitTimeSeconds = (int)TimeSpan.FromSeconds(waitTimeInSeconds).TotalSeconds
            };

            return request;
        }

        private static void RetreiveS3FileKeyAndSize(string messageBody, 
                                                     out AssetDetails assetDetails)
        {
            var s3Event = JsonConvert.DeserializeObject<S3Event>(messageBody);

            assetDetails = new AssetDetails
            {
                AssetKey = s3Event.Records[0].S3.Object.Key.Replace(@"_%23_", @"_#_")
            };

            var separator = @"_#_";

            var topicAndFrameAndFrameID = assetDetails.AssetKey.Split(separator);

            assetDetails.TopicName = topicAndFrameAndFrameID[2];

            assetDetails.EffectiveFrameID = topicAndFrameAndFrameID[1];

            assetDetails.EventTime = UtilityFunctions.GetFormattedUtcTime((DateTime)(s3Event.Records?[0].EventTime));
        }

        private static void SaveToLustre(string assetkey, string sourceBucket, string localDestinationDirectory)
        {
            try
            {
                var lustreDestPath = localDestinationDirectory + @"/" + assetkey;

                var dir = new FileInfo(lustreDestPath).Directory.FullName;

                if(!Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }

                _fileTransferUtility.Download(lustreDestPath, sourceBucket, assetkey);
            }
            catch (AmazonS3Exception e)
            {
                Console.WriteLine("Error encountered on server. Message:'{0}' when writing an object", e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Unknown encountered on server. Message:'{0}' when writing an object", e.Message);
            }
        }

        private static void UpdateDynamoDBs/*UpdateDynamoDBAndKinesisStream*/(AssetDetails assetDetails, string pmLatestAssetTable)
        {
            //UtilityFunctions.AddAssetDetailsToKinesisStream(assetDetails);

            UtilityFunctions.AddAssetToDynamoDb(assetDetails);

            if (!_versionedAssets.ContainsKey(assetDetails.TopicName))
            {
                _versionedAssets.Add(assetDetails.TopicName, Convert.ToInt32(assetDetails.EffectiveFrameID));

                UtilityFunctions.AddLatestAssetToDynamoDb(assetDetails, pmLatestAssetTable);
            }
            else
            {
                int convertedFrameID = Convert.ToInt32(assetDetails.EffectiveFrameID);

                if (convertedFrameID > _versionedAssets[assetDetails.TopicName])
                {
                    _versionedAssets[assetDetails.TopicName] = convertedFrameID;

                    UtilityFunctions.AddLatestAssetToDynamoDb(assetDetails, pmLatestAssetTable);
                }
            }
            
        }

        //private static void UpdateDynamoDBAndKinesisStream(string xApiKey, string apiGatewayEndpoint, AssetDetails assetDetails)
        //{
        //    PeriodicMetadataPayload periodicMetadataPayload = new PeriodicMetadataPayload
        //    {
        //        //Operation = Constants.INSERT_RESOURCE,
        //        AssetDetails = assetDetails
        //    };

        //    var payloadString = JsonConvert.SerializeObject(periodicMetadataPayload);

        //    var response = _client.PostAsync(apiGatewayEndpoint, new StringContent(payloadString)).Result;

        //    response.EnsureSuccessStatusCode();

        //    string content = response.Content.ReadAsStringAsync().Result;

        //}

        private static void StartLogging(string[] args)
        {
            string logFileName = "PeriodicMetadataQueuePuller.log";

            if (args.Length > 1)
            {
                logFileName = args[1];
            }

            try
            {
                _logFile = new StreamWriter(logFileName, false);//true=for append, false=new file
            }
            catch (Exception e)
            {
                _logFile = new StreamWriter(Console.OpenStandardOutput());
                Console.SetOut(_logFile);
                Log("Redirecting log to console; Logfile opening error :" + e.Message);
            }
            _logFile.AutoFlush = true;
        }

        private static void Log(string message)
        {
            //Write both to console & to log
            Console.WriteLine(message);

            lock (_logFile)
            {
                _logFile.WriteLine("[" + DateTime.Now.ToString() + "] " + message);
            }
        }
    }
}

//CopyObjectRequest copyObjectRequest = new CopyObjectRequest();

//copyObjectRequest.SourceBucket = sourceBucket;

//copyObjectRequest.SourceKey = assetkey;

//copyObjectRequest.DestinationBucket = sourceBucket;

//copyObjectRequest.DestinationKey = assetkey;

//var copyResult = s3Client.CopyObjectAsync(copyObjectRequest).Result;

//private static string UploadFileToLustre(string sourceFileName, string assetkey, string LustreDestDir)
//{
//    string destFileName = LustreDestDir + @"\" + assetkey;

//    FileInfo fi = new FileInfo(destFileName);

//    if (!Directory.Exists(fi.DirectoryName))
//    {
//        Directory.CreateDirectory(fi.DirectoryName);
//    }

//    File.Copy(sourceFileName, destFileName, true);

//    return destFileName;
//}
//private static PeriodicMetadataConfigFile LoadApplicationJsonConfig(string[] args)
//{
//    var jsonFile = args[0];

//    PeriodicMetadataConfigFile config;

//    using (StreamReader r = new StreamReader(jsonFile))
//    {
//        string json = r.ReadToEnd();

//        config = JsonConvert.DeserializeObject<PeriodicMetadataConfigFile>(json);
//    }

//    return config;
//}

//private static DeploymentConfig LoadDeploymentJsonConfig(string jsonFile)
//{
//    DeploymentConfig config;

//    using (StreamReader r = new StreamReader(jsonFile))
//    {
//        string json = r.ReadToEnd();

//        config = JsonConvert.DeserializeObject<DeploymentConfig>(json);
//    }

//    return config;
//}

//private static PeriodicMetadataConfigFile LoadJsonConfig(string[] args)
//{
//    var configFile = args[0];

//    using (StreamReader r = new StreamReader(configFile))
//    {
//        string json = r.ReadToEnd();

//        var config = JsonConvert.DeserializeObject<PeriodicMetadataConfigFile>(json);

//        return config;
//    }
//}