﻿namespace S3FilesUploader
{
    public class S3UploaderConfigFile
    {
        public string BucketName { get; set; }
        public string Region { get; set; }
        public string SourceDirectory { get; set; }
        public string awsAccessKeyId { get; set; }
        public string awsSecretAccessKey { get; set; }
        public int ThreadsNumber { get; set; } 
        public string SleepTimeBetweenUploads { get; set; }
    }
}
