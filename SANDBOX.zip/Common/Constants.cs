﻿namespace Common
{
    public enum NotificationType
    {
        TransactionStarted,
        TransactionUpdate,
        TransactionEnded,
    }

    public class Constants
    {
        public const string NOT_FOUND = "Not Found";

        //SNS
        public const string PENDING_CONFIRMATION = "PendingConfirmation";

        //DynamoDB 
        public const string TOTAL_NUMBER_OF_FILES_PER_TRANSACTION_TABLE = "TotalNumberOfItemsPerTransactionTable";
        public const string PRIMARY_KEY_COLUMN = "TID";
        public const string ACTUAL_UPLOADED_FILES_NUMBER = "ActualNumber";
        public const string EXPECTED_UPLOADED_FILES_NUMBER = "ExpectedNumber";
        public const string INSERT_RESOURCE = "InsertResource";

        public const string COLUMN_PK = "PK";
        public const string COLUMN_TRANSACTION_ID = "TransactionID";
        public const string COLUMN_RELATIVE_PATH = "RelativePath";
        public const string COLUMN_EVENT_TIME = "EventTime";
        public const string COLUMN_EXPECTED_FILES = "ExpectedFiles";

        public const string COLUMN_TOPIC_NAME = "TopicName";
        public const string COLUMN_ASSET_NAME = "AssetName";
        public const string COLUMN_ASSET_KEY = "AssetKey";
        //public const string COLUMN_GAME_ID = "GameID";
        public const string COLUMN_EFFECTIVE_FRAME_ID = "EffectiveFrameID";

        //Transaction Statuses
        public const string TRANSACTION_STARTED = "Transaction Started";
        public const string TRANSACTION_UPDATE = "Transaction Update";
        public const string TRANSACTION_ENDED = "Transaction Ended";
        public const string FILE_UNLOADED = "Unloaded";
        public const string FILE_LOADED = "Loaded";

        //Lambda - Environment Variables
        public const string DYNAMO_DB_TABLE = "DYNAMO_DB_TABLE";
        public const string DYNAMO_DB_TABLE_LATEST_ASSETS = "DYNAMO_DB_TABLE_LATEST_ASSETS";
        public const string ES_HOST = "ES_HOST";
        public const string ES_INDEX = "ES_INDEX";
        public const string ES_INDEX_TYPE = "ES_INDEX_TYPE";
        public const string S3_BUCKET = "S3_BUCKET";
        public const string AWS_ACCOUNT_ID = "ACCOUNT_ID";
        public const string AWS_REGION = "REGION";
        public const string AWS_ACCESS_KEY = "ACCESS_KEY";
        public const string AWS_SECRET_KEY = "SECRET_KEY";
        public const string KINESIS_DATA_STREAM_NAME = "KINESIS_DATA_STREAM_NAME";


        //Tests Environment
        //DEV
        public const string INDEX_NAME = "dev-transactions";
        public const string S3_BUCKET_NAME = "dev-transactions-bucket";
        //QA
        public const string QA_PERIODIC_METADATA_TABLE_NAME = "PeriodicMetadataTable";
        public const string QA_KINESIS_DATA_STREAM_NAME = "my-kinesis-stream";
        public const string PERIODIC_METADATA_DYNAMO_DB_TABLE_NAME = "PeriodicMetadataTable";
        public const string QA_DYNAMO_DB_TABLE_NAME = "QATransactionFiles";
        public const string QA_INDEX_NAME = "qa-transactions";
        public const string QA_S3_BUCKET_NAME = "qa-transactions-bucket";

        public const string INDEX_TYPE = "TransactionFields";
        public const string ACCESS_KEY = "AKIAJAOGGOPNYW7WJUUQ";
        public const string SECRET_KEY = "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";
        public const string REGION = "us-east-2";
        public const string ACCOUNT_ID = "753274046439";
        //QA
        //public const string INDEX_NAME = "qa-transactions";
        //public const string S3_BUCKET_NAME = "qa-transactions-bucket";
        //public const string INDEX_TYPE = "TransactionFields";

        public const string HOST_ENDPOINT = "https://search-transactions-nnjzqt3kllfbjiybwoltpjlway.us-east-2.es.amazonaws.com";
        public const string DYNAMO_DB_TABLE_NAME = "TransactionFiles";

        //Query Fields
        public const string CREATION_DATE = "creationDate";
        public const string MODIFIED_DATE = "modifiedDate";
        public const int DEFAULT_PAGE_SIZE = 100; //int.MaxValue;

        public const int DEFAULT_EXPIRATION_TIME_IN_MINUTES = 1440;//24 * 60;

        //Query Function Types
        public const string GET_ALL_TRANSACTIONS = "getAllTransactions";
        public const string GET_TRANSACTIONS_PAGE = "getTransactionsPage";
        public const string GET_TRANSACTION_BY_ID = "getTransactionById";
        public const string GET_TRANSACTION_BY_ID_AND_RELATIVE_PATHS = "getTransactionByIdAndRelativePaths";
        public const string QUERY_BY_ALL_FIELDS = "queryByAllFields";
        public const string QUERY_BY_ANY_FIELDS = "queryByAnyFields";
        public const string DATE_RANGE_QUERY = "dateRangeQuery";
        public const string GET_STATUS = "getStatus";

        //QueryByGet Keys
        public const string DATE_FIELD = "dateField";
        public const string GREATER_THAN = "gt";
        public const string GREATER_THAN_OR_EQUAL_TO = "gte";
        public const string LESS_THAN = "lt";
        public const string LESS_THAN_OR_EQUAL_TO = "lte";

        //Delete Function Types
        public const string DELETE_INDEX = "deleteIndex";
        public const string DELETE_DOCUMENT = "deleteDocument";

        public const int STATUS_OK = 200;
    }
}
