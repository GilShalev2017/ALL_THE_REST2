﻿using System.Collections.Generic;

namespace Common.DTO
{
    public class NotificationMessage
    {
        public NotificationType NotificationType { get; set; }
        public string NotificationTypeText { get; set; }
        public string TransactionID { get; set; }
        public string StadiumID { get; set; }
        public string GameID { get; set; }
        public string EventID { get; set; }
        public string TransactionType { get; set; }
        public object Metadata { get; set; }
        public string CreationDate { get; set; }
        public string ModifiedDate { get; set; }
        public string RelativePath { get; set; }
        //public string PreSignedUrl { get; set; }
        public Dictionary<string, string> PreSignedUrlDictionary { get; set; }
    }
}
