﻿namespace Common.DTO
{
    public class QueryPayload
    {
        public string operation { get; set; }
        public string transactionID { get; set; }
        public TransactionFields TransactionFields { get; set; }
        //Find presignedUrls
        public string[] relativeFilePaths { get; set; }
        //Range Query
        public string queryField { get; set; }
        public string fromDate { get; set; }
        public string toDate { get; set; }
        //Pagination
        public bool isPaging { get; set; }
        public int offsetFromFirstResult { get; set; }
        public int amountOfHits { get; set; }
        //Sorting
        public bool isSorting { get; set; }
        public string sortByField { get; set; }
        public bool isSortDescending { get; set; }
    }
}