﻿namespace Common.DTO
{
    public class DeletePayload
    {
        public string operation { get; set; }
        public string documentId { get; set; }
    }
}
