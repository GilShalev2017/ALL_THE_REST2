﻿namespace Common.DTO
{
    public class SubscribePayload
    {
        public string protocol { get; set; }
        public string httpEndpoint { get; set; }
        public string transactionId { get; set; }
    }
}
