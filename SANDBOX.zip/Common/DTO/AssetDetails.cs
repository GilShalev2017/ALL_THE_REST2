﻿namespace Common.DTO
{
    public class AssetDetails
    {
        public string TopicName { get; set; }
        public string EffectiveFrameID { get; set; }
        public string EventTime { get; set; }
        public string AssetKey { get; set; }
    }
}
