﻿namespace Common.DTO
{
    public class ApiGatewayEndpoints
    {
        public string secret { get; set; }
        public string creatorEndPoint { get; set; }
        public string removerEndPoint { get; set; }
        public string subscriberEndPoint { get; set; }
        public string researcherEndPoint { get; set; }
        public string proxyEndPoint { get; set; }
    }
}
