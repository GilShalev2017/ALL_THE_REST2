﻿using System.Collections.Generic;

namespace Common.DTO
{
    public class TransactionFields
    {
        public string transactionID { get; set; }
        public string status { get; set; }
        public string stadiumID { get; set; }
        public string eventID { get; set; }
        public string gameID { get; set; }
        public string transactionType { get; set; }
        public string creationDate { get; set; }
        public string modifiedDate { get; set; }
        public object Metadata { get; set; }
        public int expectedUploadedCounter { get; set; }
        public string bucket { get; set; }
        public Dictionary<string, string> presignedUrlDictionary { get; set; }
        public string loadedFilesString { get; set; }
        public int dynamoActual { get; set; }
        public bool isSubscribed { get; set; }
    }
}
