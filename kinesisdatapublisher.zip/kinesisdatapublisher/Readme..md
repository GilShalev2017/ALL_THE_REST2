# Kinesis Data Publisher
This program allows you to read a JSON formatted file as data records and insert them into Kinesis Data Stream.
## Expected JSON File
Here is an example of how the records need to be formatted in Json so that the program can read them and add them as Kinesis Data Stream records.

>[
>
>   {
>     "acceleration": -0.277,
>     "teamConfidence": 0.967,
>     "movingOrientation": [
>       -0.01,
>       1.0
>     ],
>      "team": "1",
>      "jerseyConfidence": 0.967,
>      "velocity": 3.865,
>      "position": [
>        60.69,
>        9.23,
>        -248.006
>      ],
>      "movingOrientationConfidence": 0.967,
>      "id": "151",
>      "jersey": "15",
>      "positionConfidence": 0.967
>    },
>
>    {
>      "acceleration": 0.036,
>      "teamConfidence": 0.867,
>      "movingOrientation": [
>        0.344,
>        -0.939
>      ],
>      "team": "1",
>      "jerseyConfidence": 0.867,
>      "velocity": 1.203,
>      "position": [
>        -9.67,
>        8.654,
>        -276.896
>      ],
>      "movingOrientationConfidence": 0.867,
>      "id": "621",
>      "jersey": "62",
>     "positionConfidence": 0.867
>   }
>
>]

Please note that each json object in this example, will be converted to a binary blob and added to Kinesis Data Stream as one single record.

## How to build on windows
1. Clone the repository : git clone https://jdaka@bitbucket.il.alm-sg.com/scm/rp/kinesisdatapublisher.git
1. cd kinesisdatapublisher
1. Execute the command : dotnet restore
1. Execute the command : dotnet publish -c release -r win10-x64      
1. Copy the entire folder ~\KinesisDataPublisher\bin\Release\netcoreapp2.1\win10-x64\publish to your desired location
1. To call the program, execute "KinesisDataPublisher.exe"
1. Note that KinesisDataPublisher.exe logs all erros in "KinesisDataPublisher.txt"

## How to configure Kinesisdatapublisher
To configure kinesisdatapublisher, open the Json file file kinesisdatapublisher.json which should look like the following file and change the keys to your own keys. The keys are self-explanatory

{
    "AppSettings": {
        "KinesisDataFile": "D:\\Data\\inputfilejson",
        "kinesisStreamName": "Kinesis Stream Name",
        "Partition": "myParition1",
        "AWSAccessKey": "Your AWS Access Key",
        "AWSSecretkey": "Your AWS Secret Key",
        "AWSRegion": "eu-west-1",
        "LogFileName": "KinesisDataPublisher.txt"
    }
}


## Ready Binaries
If you do not want to build the program, you can simply downlad the binaries from the S3 bucket named "fd-19-binaries" under the folder "kinesisDataPublisher" on AWS account number "753274046439" (Jay's account). Download all files to your desired location and simply execute "KinesisDataPublisher.exe"

## Data Sample
You can use the file "cvt-fixed.json" to experiment with Kinesisdatapublisher.exe. The file should be in the cloned "Kinesisdatapublisher" directory
