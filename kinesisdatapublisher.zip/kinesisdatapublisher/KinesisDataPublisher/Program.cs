﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Amazon.Kinesis.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NLog;
using LogLevel = NLog.LogLevel;

namespace KinesisDataPublisher
{
    class Program
    {
        static void Main(string[] args)
        {
            Logger logger = null;
            try
            {
                //  Read Json Configuration file
                IConfiguration config = new ConfigurationBuilder().AddJsonFile("KinesisDataPublisher.json", true, true).Build();

                Console.WriteLine("after ConfigurationBuilder");

                //  Add logging
                var logConfig = new NLog.Config.LoggingConfiguration();
                var logfile = new NLog.Targets.FileTarget("logfile") { ArchiveAboveSize = 2*1024*1024, FileName = config.GetSection("AppSettings")["LogFileName"],
                                                                       ArchiveNumbering = NLog.Targets.ArchiveNumberingMode.DateAndSequence };  
                
                logConfig.AddRule(LogLevel.Info, LogLevel.Fatal, logfile);
                NLog.LogManager.Configuration = logConfig;
                logger = NLog.LogManager.GetCurrentClassLogger();

                Console.WriteLine("after Logger");
                
                //  Read all configuration keys from Json File                
                string fileName = config.GetSection("AppSettings")["KinesisDataFile"];

                if (!File.Exists(fileName))
                {
                    Console.WriteLine("Can't find the file " + fileName);
                    return;
                }
                string streamName = config.GetSection("AppSettings")["kinesisStreamName"];
                string partition = config.GetSection("AppSettings")["Partition"];
                string accessKey = config.GetSection("AppSettings")["AWSAccessKey"];
                string secretKey = config.GetSection("AppSettings")["AWSSecretkey"];
                Amazon.RegionEndpoint region = Amazon.RegionEndpoint.USEast1;// Amazon.RegionEndpoint.GetBySystemName(config.GetSection("AppSettings")["AWSRegion"].ToString());

                Console.WriteLine("after Read all configuration");
                
                // Create KinesisDataPublisher to publish data retrieved from Json file 
                IKinesisDataPublisher publisher = new KinesisDataPublisher(accessKey, secretKey, region, streamName);

                //  Read Json file containing the data that needs to be published
                JArray records = JsonConvert.DeserializeObject<JArray>(File.ReadAllText(fileName));
                List<Task<PutRecordResponse>> responses = new List<Task<PutRecordResponse>>();
                int count = 0;
                bool addedAllSuccessfully = true;
                foreach (object record in records)
                {
                   Console.WriteLine("Added new record");
                    Task<PutRecordResponse> putRecordTask = publisher.AddRecord(record.ToString(), partition);
                    responses.Add(putRecordTask);
                    putRecordTask.ContinueWith(
                    addRecordTask => 
                    {

                        if (addRecordTask.IsCompletedSuccessfully && addRecordTask.Result.HttpStatusCode == System.Net.HttpStatusCode.OK)
                        {
                            count++;
                        }
                        else
                        {
                            addedAllSuccessfully = false;
                        }

                    }
                    );
                }
                Task.WaitAll(responses.ToArray());

                if (addedAllSuccessfully)
                {
                    logger.Info("Added " + count + " records");
                    Console.WriteLine("Total records added is: " + count);
                    logger.Info("Completed Successfully!");
                }
                else
                {
                    logger.Info("One or more records did not get added successfully. Please review the log for more details.");
                }

                Console.ReadLine();
            }
            catch (Exception exc)
            {
                logger.Error(exc);
            }
        }        
    }
}
