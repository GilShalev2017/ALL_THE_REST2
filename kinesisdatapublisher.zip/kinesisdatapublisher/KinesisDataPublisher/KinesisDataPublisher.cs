﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Amazon.Kinesis;
using Amazon.Kinesis.Model;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace KinesisDataPublisher
{
    public class KinesisDataPublisher : IKinesisDataPublisher
    {
        private readonly ILogger<IKinesisDataPublisher> logger;
        protected AmazonKinesisClient client = null;
        public string StreamName { get; set; }
        public KinesisDataPublisher(string awsAccessKeyId, string awsSecretAccessKey, Amazon.RegionEndpoint awsRegion, string streamName)
        {
            this.StreamName = streamName;
            client = new AmazonKinesisClient(awsAccessKeyId, awsSecretAccessKey, awsRegion);        
        }

        public async Task<PutRecordResponse> AddRecord(string JsonObject, string partition)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(JsonObject));

            using (MemoryStream ms = new MemoryStream(bytes))
            {

                PutRecordRequest requestRecord = new PutRecordRequest();
                requestRecord.StreamName = StreamName;

                requestRecord.PartitionKey = partition;
                requestRecord.Data = ms;

                return await client.PutRecordAsync(requestRecord);

            }
        }
    }
}
