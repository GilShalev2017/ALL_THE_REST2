﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Amazon.Kinesis.Model;

namespace KinesisDataPublisher
{
    public interface IKinesisDataPublisher
    {
        Task<PutRecordResponse> AddRecord(string JsonObject, string partition);
    }
}
