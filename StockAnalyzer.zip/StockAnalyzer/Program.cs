﻿using HtmlAgilityPack;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace StockAnalyzer
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            //ParseHtml();

            ZacksParser();

            //BarchartParser();

            //GetPlainTextFromHtml("ynet.co.il");
        }

        //static void ParseHtml()
        //{
        //    HtmlDocument doc = new HtmlDocument();
        //    doc.Load("file.htm");
        //    foreach (HtmlNode link in doc..SelectNodes("//a[@href"])
        //    {
        //        HtmlAttribute att = link["href"];
        //        att.Value = FixLink(att);
        //    }
        //    doc.Save("file.htm");
        //}

        public static void ZacksParser()
        {
            string[] stocks = { "AAPL", "MSFT", "INTC", "CAR", "NVDA" };

            var lines = File.ReadLines("nasdaq_screener.csv");

            List<string> stockList = new List<string>();

            foreach (string line in lines)
            {
                string stockSymbol = line.Split(",")[0];

                if (stockSymbol == "Symbol")
                    continue;

                stockList.Add(stockSymbol);
            }

            var web = new HtmlAgilityPack.HtmlWeb();

            string stockStatistics = "zacks_stock_statistics.csv";

            string headers = "STOCK, RANK_ZACKS" + Environment.NewLine;

            File.WriteAllText(stockStatistics, headers);

            var watch = System.Diagnostics.Stopwatch.StartNew();

            string[] stockArray = stockList.ToArray();

            ConcurrentBag<string> bag = new ConcurrentBag<string>();

            //ConcurrentDictionary<string, string> dictionaryZacks = new ConcurrentDictionary<string, string>();
            //ConcurrentDictionary<string, string> dictionaryBarchart = new ConcurrentDictionary<string, string>();

            Parallel.ForEach(stockArray, stockSymbol =>
            {
                if (stockSymbol.Contains("^"))
                {
                    stockSymbol = stockSymbol.Split("^")[0];
                }
           
                string zacksStockUrl = "https://www.zacks.com/stock/quote/" + stockSymbol;

                //string barchartStockUrl = "https://www.barchart.com/stocks/quotes/" + stockSymbol;

                Console.WriteLine("Checking Stock: " + stockSymbol);

                try
                {
                    HtmlDocument zacksStockDoc = web.Load(zacksStockUrl);

                    //bool zackExist = false;

                    if (zacksStockDoc.DocumentNode.SelectNodes("//*[@id=\"quote_ribbon_v2\"]/div[2]/div[1]/p/text()") != null && zacksStockDoc.DocumentNode.SelectNodes("//*[@id=\"quote_ribbon_v2\"]/div[2]/div[1]/p/text()").Count != 0)
                    {
                        string zackStockRankView = zacksStockDoc.DocumentNode.SelectNodes
                            ("//*[@id=\"quote_ribbon_v2\"]/div[2]/div[1]/p/text()")[0].InnerText
                            .Replace(" ", "").Replace("\n", "");
                        
                        string stockData = stockSymbol + ", " + zackStockRankView + Environment.NewLine;

                        bag.Add(stockData);
                        //dictionaryZacks.TryAdd(stockSymbol, stockData);

                        //zackExist = true;
                    }

                    //HtmlDocument barChartStockDoc = web.Load(barchartStockUrl);

                    ////*[@id="bc-main-content-wrapper"]/div/div[2]/div[2]/div/div[2]/div/div[2]/div[1]/div/div[2]/p[1]/b[1]
                    //if (barChartStockDoc.DocumentNode.SelectNodes("//*[@id=\"bc-main-content-wrapper\"]/div/div[2]/div[2]/div/div[2]/div/div[2]/div[1]/div/div[2]/p[1]/b[1]/text()") != null && barChartStockDoc.DocumentNode.SelectNodes("//*[@id=\"bc-main-content-wrapper\"]/div/div[2]/div[2]/div/div[2]/div/div[2]/div[1]/div/div[2]/p[1]/b[1]/text()").Count != 0)
                    //{
                    //    string barChartStockRankView = barChartStockDoc.DocumentNode.SelectNodes
                    //        ("//*[@id=\"bc-main-content-wrapper\"]/div/div[2]/div[2]/div/div[2]/div/div[2]/div[1]/div/div[2]/p[1]/b[1]/text()")[0].InnerText
                    //        .Replace("\r\n", "").Trim();

                    //    if (zacksStockUrl.ContainsKey(stockSymbol)) //both exist
                    //    {
                    //        string zacksValue = zacksStockUrl[stockSymbol];
                            
                    //        string stockDataWithBarChart = zacksValue + ", " + barChartStockRankView + Environment.NewLine;

                    //        dictionary[stockSymbol] = stockDataWithBarChart;
                    //    }
                    //    else //only barchart exist
                    //    {
                    //        string stockDataWithBarChart = " ,, " + barChartStockRankView + Environment.NewLine; 

                    //        dictionary[stockSymbol] = stockDataWithBarChart;
                    //    }
                    //}
                    //else if(zackExist) //only zackExist
                    //{
                    //    dictionary[stockSymbol] = dictionary[stockSymbol] + ", " + Environment.NewLine;
                    //}
                }
                catch (Exception xcp)
                {
                    Console.WriteLine(xcp);
                }
            });

           
            foreach (string stockData in bag)
            {
                File.AppendAllText(stockStatistics, stockData);
            }

            watch.Stop();

            var elapsedMs = watch.ElapsedMilliseconds;

            Console.WriteLine("elapsedMs" + elapsedMs);
        }

        public static void BarchartParser()
        {
            string[] stocks = { "AAPL", "MSFT", "INTC", "CAR", "NVDA" };

            var lines = File.ReadLines("nasdaq_screener.csv");

            List<string> stockList = new List<string>();

            foreach (string line in lines)
            {
                string stockSymbol = line.Split(",")[0];

                if (stockSymbol == "Symbol")
                    continue;

                stockList.Add(stockSymbol);
            }

            var web = new HtmlAgilityPack.HtmlWeb();

            string stockStatistics = "barchart_stock_statistics.csv";

            string headers = "STOCK, RANK_BARCHART" + Environment.NewLine;

            File.WriteAllText(stockStatistics, headers);

            var watch = System.Diagnostics.Stopwatch.StartNew();

            string[] stockArray = stockList.ToArray();

            ConcurrentBag<string> bag = new ConcurrentBag<string>();

            //ConcurrentDictionary<string, string> dictionaryZacks = new ConcurrentDictionary<string, string>();
            //ConcurrentDictionary<string, string> dictionaryBarchart = new ConcurrentDictionary<string, string>();

            //Parallel.ForEach(stockArray, stockSymbol =>
            foreach(string stockSymbol in stockArray)
            {
                var modifiedStockSymbol = stockSymbol;

                if (stockSymbol.Contains("^"))
                {
                    modifiedStockSymbol = stockSymbol.Split("^")[0];
                }

                //string zacksStockUrl = "https://www.zacks.com/stock/quote/" + stockSymbol;

                string barchartStockUrl = "https://www.barchart.com/stocks/quotes/" + modifiedStockSymbol;

                Console.WriteLine("Checking Stock: " + modifiedStockSymbol);

                try
                {
                    //HtmlDocument zacksStockDoc = web.Load(zacksStockUrl);

                    //bool zackExist = false;

                    //if (zacksStockDoc.DocumentNode.SelectNodes("//*[@id=\"quote_ribbon_v2\"]/div[2]/div[1]/p/text()") != null && zacksStockDoc.DocumentNode.SelectNodes("//*[@id=\"quote_ribbon_v2\"]/div[2]/div[1]/p/text()").Count != 0)
                    //{
                    //    string zackStockRankView = zacksStockDoc.DocumentNode.SelectNodes
                    //        ("//*[@id=\"quote_ribbon_v2\"]/div[2]/div[1]/p/text()")[0].InnerText
                    //        .Replace(" ", "").Replace("\n", "");

                    //    string stockData = stockSymbol + ", " + zackStockRankView + Environment.NewLine;

                    //    dictionaryZacks.TryAdd(stockSymbol, stockData);

                    //    zackExist = true;
                    //}

                    HtmlDocument barChartStockDoc = web.Load(barchartStockUrl);
                 
                    //*[@id="bc-main-content-wrapper"]/div/div[2]/div[2]/div/div[2]/div/div[2]/div[1]/div/div[2]/p[1]/b[1]
                    if (barChartStockDoc.DocumentNode.SelectNodes("//*[@id=\"bc-main-content-wrapper\"]/div/div[2]/div[2]/div/div[2]/div/div[2]/div[1]/div/div[2]/p[1]/b[1]/text()") != null && barChartStockDoc.DocumentNode.SelectNodes("//*[@id=\"bc-main-content-wrapper\"]/div/div[2]/div[2]/div/div[2]/div/div[2]/div[1]/div/div[2]/p[1]/b[1]/text()").Count != 0)
                    {                                              
                        string barChartStockRankView = barChartStockDoc.DocumentNode.SelectNodes
                            ("//*[@id=\"bc-main-content-wrapper\"]/div/div[2]/div[2]/div/div[2]/div/div[2]/div[1]/div/div[2]/p[1]/b[1]/text()")[0].InnerText
                            .Replace("\r\n", "").Trim();

                        string stockData = modifiedStockSymbol + ", " + barChartStockRankView + Environment.NewLine;

                        bag.Add(stockData);

                        //if (zacksStockUrl.ContainsKey(stockSymbol)) //both exist
                        //{
                        //    string zacksValue = zacksStockUrl[stockSymbol];

                        //    string stockDataWithBarChart = zacksValue + ", " + barChartStockRankView + Environment.NewLine;

                        //    dictionary[stockSymbol] = stockDataWithBarChart;
                        //}
                        //else //only barchart exist
                        //{
                        //    string stockDataWithBarChart = " ,, " + barChartStockRankView + Environment.NewLine;

                        //    dictionary[stockSymbol] = stockDataWithBarChart;
                        //}
                    }
                    //else if (zackExist) //only zackExist
                    //{
                    //    dictionary[stockSymbol] = dictionary[stockSymbol] + ", " + Environment.NewLine;
                    //}
                }
                catch (Exception xcp)
                {
                    Console.WriteLine(xcp);
                }
            };


            foreach (string stockData in bag)
            {
                File.AppendAllText(stockStatistics, stockData);
            }

            watch.Stop();

            var elapsedMs = watch.ElapsedMilliseconds;

            Console.WriteLine("elapsedMs" + elapsedMs);
        }
        public static void ParseHtml()
        {
            string html;
            // obtain some arbitrary html....
            using (var client = new WebClient())
            {
                html = client.DownloadString("http://ynet.co.il");// http://stackoverflow.com/questions/2038104");
            }
            // use the html agility pack: http://www.codeplex.com/htmlagilitypack
            HtmlDocument doc = new HtmlDocument();
            doc.LoadHtml(html);
            StringBuilder sb = new StringBuilder();
            foreach (HtmlTextNode node in doc.DocumentNode.SelectNodes("//text()"))
            {
                sb.AppendLine(node.Text);
            }
            string final = sb.ToString();
            var splits = final.Split("למה כדאי להכניס");
        }
        private static string GetPlainTextFromHtml(string htmlString)
        {
            string htmlTagPattern = "<.*?>";
            var regexCss = new Regex("(\\<script(.+?)\\</script\\>)|(\\<style(.+?)\\</style\\>)", RegexOptions.Singleline | RegexOptions.IgnoreCase);
            htmlString = regexCss.Replace(htmlString, string.Empty);
            htmlString = Regex.Replace(htmlString, htmlTagPattern, string.Empty);
            htmlString = Regex.Replace(htmlString, @"^\s+$[\r\n]*", "", RegexOptions.Multiline);
            htmlString = htmlString.Replace("&nbsp;", string.Empty);

            return htmlString;
        }
    }
}


//string url = "https://www.zacks.com/stock/quote/AAPL?q=AAPL";// "http://www.metacritic.com/game/pc/halo-spartan-assault";
//HtmlDocument doc = web.Load(url);
//string rank_view_AAPL = doc.DocumentNode.SelectNodes("//*[@id=\"quote_ribbon_v2\"]/div[2]/div[1]/p/text()")[0].InnerText;

//string url2 = "https://www.zacks.com/stock/quote/MSFT";
//HtmlDocument doc2 = web.Load(url2);
//string rank_view_MSFT = doc2.DocumentNode.SelectNodes("//*[@id=\"quote_ribbon_v2\"]/div[2]/div[1]/p/text()")[0].InnerText;

//string url3 = "https://www.zacks.com/stock/quote/INTC";
//HtmlDocument doc3 = web.Load(url3);
//string rank_view_INTC = doc3.DocumentNode.SelectNodes("//*[@id=\"quote_ribbon_v2\"]/div[2]/div[1]/p/text()")[0].InnerText;

//string url4 = "https://www.zacks.com/stock/quote/CAR";
//HtmlDocument doc4 = web.Load(url4);
//string rank_view_CAR = doc4.DocumentNode.SelectNodes("//*[@id=\"quote_ribbon_v2\"]/div[2]/div[1]/p/text()")[0].InnerText;

//string url5 = "https://www.zacks.com/stock/quote/NVDA";
//HtmlDocument doc5 = web.Load(url5);
//string rank_view_NVDA = doc5.DocumentNode.SelectNodes("//*[@id=\"quote_ribbon_v2\"]/div[2]/div[1]/p/text()")[0].InnerText.Replace(" ","").Replace("\n","");


//string metascore = doc.DocumentNode.SelectNodes("//*[@id=\"main\"]/div/div[1]/div[1]/div[3]/div/div/div[2]/div[1]/div[1]/div/div/a/div/span")[0].InnerText;
//string userscore = doc.DocumentNode.SelectNodes("//*[@id=\"main\"]/div/div[1]/div[1]/div[3]/div/div/div[2]/div[1]/div[2]/div[1]/div/a/div")[0].InnerText;
//string summary = doc.DocumentNode.SelectNodes("//*[@id=\"main\"]/div/div[1]/div[1]/div[3]/div/div/div[2]/div[2]/div[1]/ul/li/span[2]/span/span[1]")[0].InnerText;