﻿namespace Common.DTO
{
    public class LambdaResult
    {
        //[JsonProperty("ResultCode")]
        public int ResultCode { get; set; }

        //[JsonProperty("Total")]
        public long Total { get; set; }

        //[JsonProperty("body")]
        public object Body { get; set; }
        
    }
}
