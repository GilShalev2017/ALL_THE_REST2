﻿namespace Common.DTO
{
    public class CreationPayload
    {
        public TransactionFields transactionFields { get; set; }
        public string[] relativeFilePaths { get; set; }
        public SubscribePayload[] subscribers { get; set; }
    }
}
