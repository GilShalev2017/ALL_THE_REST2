﻿namespace Common.DTO
{
    public class PeriodicMetadataPayload
    {
        //public string Operation { get; set; }
        public AssetDetails AssetDetails { get; set; }
    }
}
