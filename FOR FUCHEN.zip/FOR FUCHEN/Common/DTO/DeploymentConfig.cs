﻿namespace Common.DTO
{
    public class DeploymentConfig
    {
        public PeriodicMetadata periodic_metadata { get; set; }
        //public PeriodicMetadataSqsPuller periodic_metadata_sqs_puller { get; set; }
    }

    public class PeriodicMetadata
    {
        public string shared_storage_root { get; set; }
        public string dynamo_db_table { get; set; }
        public string kinesis_data_stream { get; set; }
        public string sqs_queue_url { get; set; }
        public string s3_bucket { get; set; }
        public string region { get; set; }
    }

    public class PeriodicMetadataSqsPuller
    {
        public int wait_time_in_seconds { get; set; }
        public int max_num_of_messages { get; set; }
        public int parallel_sessions { get; set; }
    }
}
