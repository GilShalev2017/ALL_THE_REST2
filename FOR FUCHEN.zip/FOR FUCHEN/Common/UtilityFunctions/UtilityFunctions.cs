﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.Kinesis;
using Amazon.Kinesis.Model;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.SimpleNotificationService;
using Amazon.SimpleNotificationService.Model;
using Common.DTO;
using Nest;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using GetShardIteratorRequest = Amazon.Kinesis.Model.GetShardIteratorRequest;
using GetShardIteratorResponse = Amazon.Kinesis.Model.GetShardIteratorResponse;
using ShardIteratorType = Amazon.Kinesis.ShardIteratorType;

namespace Common.UtilityFunctions
{
    public class UtilityFunctions
    {
        public static List<TransactionFields> GetTransactionsWithId(ISearchResponse<TransactionFields> searchResponse)
        {
            var transactions = new List<TransactionFields>();

            if (searchResponse.HitsMetaData == null)
                return null;

            foreach (var hit in searchResponse.HitsMetaData.Hits)
            {
                var transactionFields = hit.Source;

                transactionFields.transactionID = hit.Id;

                transactions.Add(transactionFields);
            }

            return transactions;
        }

        public static LambdaResult SetLambdaResult(int statusCode, int total, object transactions)
        {
            return new LambdaResult
            {
                ResultCode = statusCode,
                Total = total,
                Body = transactions
            };
        }

        public static string GetS3FilePath(string transactionID, string stadiumID, string gameID, string eventID, string relativePath)
        {
            //"AWCc134v_XH21TaORcdM/Oracle Arena/Cardinals_Vs_Saints/c123b80c-c82c-d17b-a627-2662c58205ce/folderXXX/fgc03.png"
            return string.Format("{0}/{1}/{2}/{3}/{4}", transactionID,
                                                        stadiumID,
                                                        gameID,
                                                        eventID,
                                                        relativePath);
        }

        public static string GetFormattedUtcTime(DateTime dateTime)
        {
            return dateTime.ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'");
        }

        public static void CreateTopicAndSubscribe(TransactionFields transactionDocument, SubscribePayload[] subscribers)//string protocol, string httpEndpoint)
        {
            var snsClient = ClientFactory.ClientFactory.GetSnsClient();

            CreateTopicRequest request = new CreateTopicRequest { Name = string.Format("Transaction_Topic_{0}", transactionDocument.transactionID) };

            var topicArn = snsClient.CreateTopicAsync(request).Result.TopicArn;

            foreach (var subscriber in subscribers)
            {
                var subscription = snsClient.SubscribeAsync(new SubscribeRequest
                {
                    TopicArn = topicArn,
                    Protocol = subscriber.protocol,
                    Endpoint = subscriber.httpEndpoint
                }).Result;
            }
        }

        //public static void CreateTopicSubscribeAndNotifyBegin(TransactionFields transactionDocument, SubscribePayload[] subscribers)//string protocol, string httpEndpoint)
        //{
        //    var snsClient = ClientFactory.ClientFactory.GetSnsClient();

        //    CreateTopicRequest request = new CreateTopicRequest { Name = string.Format("Transaction_Topic_{0}", transactionDocument.transactionID) };

        //    var topicArn = snsClient.CreateTopicAsync(request).Result.TopicArn;

        //    foreach (var subscriber in subscribers)
        //    {
        //        var subscription = snsClient.SubscribeAsync(new SubscribeRequest
        //        {
        //            TopicArn = topicArn,
        //            Protocol = subscriber.protocol,
        //            Endpoint = subscriber.httpEndpoint
        //        }).Result;
        //    }

        //    PublishTransactionNotification(topicArn,
        //                                    NotificationType.TransactionStarted,
        //                                    transactionDocument.transactionID,
        //                                    transactionDocument.stadiumID,
        //                                    transactionDocument.gameID,
        //                                    transactionDocument.eventID,
        //                                    transactionDocument.transactionType,
        //                                    transactionDocument.creationDate,
        //                                    transactionDocument.modifiedDate,
        //                                    transactionDocument.Metadata);
        //}

        public static string CreateTransactionTopicAndSubscribe(string transactionId, string protocol, string httpEndpoint)
        {
            var snsClient = ClientFactory.ClientFactory.GetSnsClient();

            try
            {
                CreateTopicRequest request = new CreateTopicRequest { Name = string.Format("Transaction_Topic_{0}", transactionId) };

                var topicArn = snsClient.CreateTopicAsync(request).Result.TopicArn;

                //var subscriptionLambda = snsClient.SubscribeAsync(new SubscribeRequest
                //{
                //    TopicArn = topicArn,
                //    Protocol = "lambda",
                //    Endpoint = "arn:aws:lambda:us-east-2:753274046439:function:Listener"
                //}).Result;

                var subscription = snsClient.SubscribeAsync(new SubscribeRequest
                {
                    TopicArn = topicArn,
                    Protocol = protocol,
                    Endpoint = httpEndpoint
                }).Result;

                return topicArn;
            }
            catch (AmazonSimpleNotificationServiceException ex)
            {

            }

            return string.Empty;
        }

        private static string GetNotificationTypeText(NotificationType notificationType)
        {
            switch (notificationType)
            {
                case NotificationType.TransactionStarted:
                    return "TRANSACTION STARTED";
                case NotificationType.TransactionUpdate:
                    return "TRANSACTION UPDATE";
                case NotificationType.TransactionEnded:
                    return "TRANSACTION ENDED";
            }

            return "UNDEFINED";
        }

        public static void PublishTransactionNotification(string topicArn,
                                                          NotificationType notificationType,
                                                          string transactionID,
                                                          string stadiumID,
                                                          string gameID,
                                                          string eventID,
                                                          string transactionType,
                                                          string creationDate,
                                                          string modifiedDate,
                                                          object metadata,
                                                          string relativePath = null)
        {
            var snsClient = ClientFactory.ClientFactory.GetSnsClient();

            string preSignedUrl = null;

            Dictionary<string, string> preSignedUrlDictionary = null;

            if (notificationType == NotificationType.TransactionUpdate)
            {
                preSignedUrl = GetPreSignedURL(ClientFactory.ClientFactory.GetS3Client(),
                                               ClientFactory.ClientFactory.S3Bucket,
                                               GetS3FilePath(transactionID, stadiumID, gameID, eventID, relativePath),
                                               HttpVerb.GET);

                preSignedUrlDictionary = new Dictionary<string, string>
                {
                    { relativePath, preSignedUrl }
                };
            }
            else if (notificationType == NotificationType.TransactionEnded)
            {
                preSignedUrlDictionary = GetDownloadingPreSignedUrlDictionary(transactionID);
            }

            var notificationMessage = new NotificationMessage()
            {
                NotificationType = notificationType,
                NotificationTypeText = GetNotificationTypeText(notificationType),
                TransactionID = transactionID,
                StadiumID = stadiumID,
                GameID = gameID,
                EventID = eventID,
                TransactionType = transactionType,
                CreationDate = creationDate,
                ModifiedDate = modifiedDate,
                Metadata = metadata,
                RelativePath = relativePath,
                //PreSignedUrl = preSignedUrl,
                PreSignedUrlDictionary = preSignedUrlDictionary
            };

            var settings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Include
            };

            //var serializedNotificationString = JsonConvert.SerializeObject(notificationMessage, settings);
            var serializedNotificationString = JsonConvert.SerializeObject(notificationMessage, notificationMessage.GetType(),settings);

            var result = snsClient.PublishAsync(new PublishRequest
            {
                Subject = string.Format("{0} - {1}", notificationType, transactionID),
                Message = serializedNotificationString,
                TopicArn = topicArn
            }).Result;
        }

        public static string GetPreSignedURL(IAmazonS3 s3Client, string bucketName, string key, HttpVerb httpVerb)
        {
            var request = new GetPreSignedUrlRequest
            {
                BucketName = bucketName,
                Key = key,
                Verb = httpVerb,
                Expires = DateTime.Now.AddMinutes(Constants.DEFAULT_EXPIRATION_TIME_IN_MINUTES)
            };

            var urlString = s3Client.GetPreSignedURL(request);

            return urlString;
        }

        public static void DeleteTopicAndSubscribers(string transactionID)
        {
            var snsClient = ClientFactory.ClientFactory.GetSnsClient();

            var topicArn = GetTransactionTopicArn(transactionID);

            if (!string.IsNullOrEmpty(topicArn))
            {
                ListSubscriptionsByTopicResponse listSubscriptionsByTopicResponse = snsClient.ListSubscriptionsByTopicAsync(topicArn).Result;

                foreach (var subscription in listSubscriptionsByTopicResponse.Subscriptions)
                {
                    if (subscription.SubscriptionArn != Constants.PENDING_CONFIRMATION)
                    {
                        UnsubscribeResponse unsubscribeResponse = snsClient.UnsubscribeAsync(subscription.SubscriptionArn).Result;
                    }
                }

                DeleteTopicResponse deleteTopicResponse = snsClient.DeleteTopicAsync(topicArn).Result;
            }
        }

        public static string GetTransactionTopicArn(string transactionID)
        {
            var transactionTopic = string.Format(string.Format("arn:aws:sns:{0}:{1}:Transaction_Topic_{2}",
                                                               ClientFactory.ClientFactory.AwsRegion,
                                                               ClientFactory.ClientFactory.AwsAccountID,
                                                               transactionID));

            return transactionTopic;
        }

        public static List<string> FindTransactionFileKeys(IAmazonS3 s3Client, string bucketName, string transactionId)
        {
            List<String> keys = new List<String>();

            ListObjectsRequest listObjectsRequest = new ListObjectsRequest() { BucketName = bucketName, Prefix = transactionId };

            ListObjectsResponse response = s3Client.ListObjectsAsync(listObjectsRequest).Result;

            foreach (var s3Object in response.S3Objects)
            {
                keys.Add(s3Object.Key);
            }

            return keys;
        }

        public static int GetTransactionUploadedFilesNumber(IAmazonS3 s3Client, string bucketName, string transactionId)
        {
            ListObjectsRequest listObjectsRequest = new ListObjectsRequest() { BucketName = bucketName, Prefix = transactionId };

            ListObjectsResponse response = s3Client.ListObjectsAsync(listObjectsRequest).Result;

            return response.S3Objects.Count;
        }

        public static Dictionary<string, string> GetDownloadingPreSignedUrlDictionary(string transactionID)
        {
            var bucketName = ClientFactory.ClientFactory.S3Bucket;

            var s3Client = ClientFactory.ClientFactory.GetS3Client();

            Dictionary<string, string> dictionary = new Dictionary<string, string>();

            var keys = FindTransactionFileKeys(s3Client, bucketName, transactionID);

            for (int i = 0; i < keys.Count; i++)
            {
                string presignedUrl = GetPreSignedURL(s3Client, bucketName, keys[i], HttpVerb.GET);

                string relativePath = GetRelativePathFromKey(keys[i]);

                dictionary.Add(relativePath, presignedUrl);
            }

            return dictionary;
        }

        public static string GetRelativePathFromKey(string key)
        {
            string beginOfRelative = key.Split('/')[4];

            string relativePath = key.Substring(key.IndexOf(beginOfRelative));

            return relativePath;
        }

        public static void AddDebugIndex(string method, IUpdateResponse<TransactionFields> updateResult, Exception xcp = null)
        {
            TransactionFields fields;

            if (updateResult == null)
            {
                fields = new TransactionFields()
                {
                    stadiumID = "EXCEPTION",
                    gameID = xcp.Message,
                    eventID = "EXCEPTION",
                    transactionType = "EXCEPTION",
                    Metadata = method
                };
            }
            else
            {
                fields = new TransactionFields()
                {
                    stadiumID = "UPDATE FAILED",
                    gameID = "UPDATE FAILED",//updateResult.DebugInformation,
                    eventID = "UPDATE FAILED",//updateResult.OriginalException.Message,
                    transactionType = "UPDATE FAILED",//updateResult.ServerError.ToString(),
                    Metadata = method
                };
            }

            var client = ClientFactory.ClientFactory.GetElasticClient();

            IIndexResponse response = client.Index(fields, c => c.Type(ClientFactory.ClientFactory.DefaultIndexType));
        }
        
        public static void AddRecordToSummarizeDynamoDb(string transactionID, string relativePath, string dateTime, string expectedFiles)
        {
            IAmazonDynamoDB client = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();

            Dictionary<string, AttributeValue> dic = new Dictionary<string, AttributeValue>();

            var pk = string.Format("{0}-{1}", transactionID, relativePath);
            dic.Add(Constants.COLUMN_PK, new AttributeValue(pk));
            dic.Add(Constants.COLUMN_TRANSACTION_ID, new AttributeValue(transactionID));
            dic.Add(Constants.COLUMN_RELATIVE_PATH, new AttributeValue(relativePath));
            dic.Add(Constants.COLUMN_EVENT_TIME, new AttributeValue(dateTime));
            dic.Add(Constants.COLUMN_EXPECTED_FILES, new AttributeValue(expectedFiles));

            PutItemResponse response = client.PutItemAsync(ClientFactory.ClientFactory.DynamoDbTable, dic).Result;
        }
        
        public static ScanResponse ScanSummarizeDynamoDb(string transactionID)
        {
            IAmazonDynamoDB client = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();
            ScanResponse result;

            var req = new ScanRequest
            {
                TableName = ClientFactory.ClientFactory.DynamoDbTable,
                ProjectionExpression = string.Format("{0},{1},{2},{3},{4}", Constants.COLUMN_PK,
                                                                            Constants.COLUMN_TRANSACTION_ID,
                                                                            Constants.COLUMN_EXPECTED_FILES,
                                                                            Constants.COLUMN_EVENT_TIME,
                                                                            Constants.COLUMN_RELATIVE_PATH),//"PK,TransactionID,ExpectedFiles,EventTime,RelativePath",
                ExpressionAttributeValues = new Dictionary<string, AttributeValue> {
                      {":val", new AttributeValue { S = transactionID }}
                },
                FilterExpression = "TransactionID = :val",
            };

            result = client.ScanAsync(req).Result;

            return result;
        }

        public static void CleanSummarizeDynamoDb(string transactionID)
        {
            IAmazonDynamoDB client = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();
            
            ScanResponse response = ScanSummarizeDynamoDb(transactionID);

            foreach (var item in response.Items)
            {
                var pk = item["PK"].S;

                var key = new Dictionary<string, AttributeValue>();
                Dictionary<string, AttributeValue> KeyDic = new Dictionary<string, AttributeValue>();
                key.Add("PK", new AttributeValue { S = pk });

                // Create DeleteItem request
                DeleteItemRequest request = new DeleteItemRequest
                {
                    TableName = ClientFactory.ClientFactory.DynamoDbTable,
                    Key = key
                };
                var result = client.DeleteItemAsync(request).Result;
            }
        }

        public static AssetDetails AddAssetToDynamoDb(AssetDetails assetDetails)
        {
            IAmazonDynamoDB client = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();

            Dictionary<string, AttributeValue> dic = new Dictionary<string, AttributeValue>();

            var pk = string.Format("{0}_{1}", assetDetails.TopicName, assetDetails.EffectiveFrameID);
            dic.Add(Constants.COLUMN_PK, new AttributeValue(pk));
            dic.Add(Constants.COLUMN_TOPIC_NAME, new AttributeValue(assetDetails.TopicName));
            dic.Add(Constants.COLUMN_ASSET_KEY, new AttributeValue(assetDetails.AssetKey));
            dic.Add(Constants.COLUMN_EFFECTIVE_FRAME_ID, new AttributeValue(assetDetails.EffectiveFrameID));
            dic.Add(Constants.COLUMN_EVENT_TIME, new AttributeValue(assetDetails.EventTime));

            PutItemResponse response = client.PutItemAsync(ClientFactory.ClientFactory.DynamoDbTable, dic).Result;

            return response.HttpStatusCode == System.Net.HttpStatusCode.OK ? assetDetails: null;
        }

        public static AssetDetails GetAssetFromDynamoDb(string assetName)
        {
            var dynamoDBClient = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();

            //var pk = string.Format("{0}-{1}", cameraID, frameID);

            var key = new Dictionary<string, AttributeValue>();

            Dictionary<string, AttributeValue> KeyDic = new Dictionary<string, AttributeValue>();

            key.Add(Constants.COLUMN_ASSET_NAME, new AttributeValue { S = assetName });
            
            //// Create GetItem request
            GetItemRequest request = new GetItemRequest
            {
                TableName = ClientFactory.ClientFactory.DynamoDbTable,
                Key = key,
            };

            // Issue request
            GetItemResponse response = dynamoDBClient.GetItemAsync(request).Result;

            Dictionary<string, AttributeValue> item = response.Item;

            AssetDetails result = new AssetDetails();

            foreach (var keyValuePair in item)
            {
                switch (keyValuePair.Key) 
                {
                    case Constants.COLUMN_TOPIC_NAME:
                        result.TopicName = keyValuePair.Value.S;
                        break;
                    case Constants.COLUMN_EFFECTIVE_FRAME_ID:
                        result.EffectiveFrameID = keyValuePair.Value.S;
                        break;
                    case Constants.COLUMN_ASSET_KEY:
                        result.AssetKey = keyValuePair.Value.S;
                        break;
                    case Constants.COLUMN_EVENT_TIME:
                        result.EventTime = keyValuePair.Value.S;
                        break;
                }
            }

            return result;
        }

        public static ScanResponse ScanPeriodicMetadataDynamoDb(string topicName)
        {
            IAmazonDynamoDB client = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();
            ScanResponse result;

            var req = new ScanRequest
            {
                TableName = ClientFactory.ClientFactory.DynamoDbTable,
                ExpressionAttributeValues = new Dictionary<string, AttributeValue> {
                      {":val", new AttributeValue { S = topicName }}
                },
                FilterExpression = "TopicName = :val",
            };

            result = client.ScanAsync(req).Result;

            return result;
        }

        public static string GetLatestAssetName(string topicName)
        {
            ScanResponse response = ScanPeriodicMetadataDynamoDb(topicName);

            var latestItem = response.Items.OrderByDescending(item => Convert.ToInt32(item["EffectiveFrameID"].S)).First();

            return latestItem["AssetName"].S;

            //response.Items.MaxBy(x => x.Height);
            //response.Items.Find(x => Max(x.Values["EffectiveFrameID"]));
        }

        public static PutRecordResponse AddAssetDetailsToKinesisStream(AssetDetails assetDetails)
        {
            IAmazonKinesis amazonKinesisClient = ClientFactory.ClientFactory.GetKinesisClient();

            string partitionKey = string.Format("{0}_$_{1}", assetDetails.TopicName, assetDetails.EffectiveFrameID);
            
            string data = string.Format("{0}${1}${2}",assetDetails.TopicName, assetDetails.AssetKey, assetDetails.EffectiveFrameID);

            PutRecordRequest putRecordRequest = new PutRecordRequest
            {
                StreamName = ClientFactory.ClientFactory.KinesisDataStreamName,
                Data = new MemoryStream(Encoding.UTF8.GetBytes(data)),
                PartitionKey = partitionKey
            };
          
            PutRecordResponse putRecordResponse = amazonKinesisClient.PutRecordAsync(putRecordRequest).Result;

            return putRecordResponse;
        }

        public static void ReadKinesisStreamMessages(string streamName)
        {
            IAmazonKinesis amazonKinesisClient = ClientFactory.ClientFactory.GetKinesisClient();

            //var getShardIteratorRequest = new Amazon.Kinesis.Model.GetShardIteratorRequest
            //{
            //    StreamName = "myTestStream"
            //};

            //var id = getShardIteratorRequest.ShardId;

            //GetShardIteratorResponse getShardIteratorResponse = amazonKinesisClient.GetShardIteratorAsync(getShardIteratorRequest).Result;

            var listShardsRequest = new ListShardsRequest
            {
                StreamName = streamName
            };

            ListShardsResponse listShardsResponse = amazonKinesisClient.ListShardsAsync(listShardsRequest).Result;

            var getShardIteratorRequest = new GetShardIteratorRequest
            {
                StreamName = streamName,
                ShardId = listShardsResponse.Shards[0].ShardId,
                ShardIteratorType = ShardIteratorType.TRIM_HORIZON
            };

            GetShardIteratorResponse getShardIteratorResponse = amazonKinesisClient.GetShardIteratorAsync(getShardIteratorRequest).Result;

            var getRecordsRequest = new Amazon.Kinesis.Model.GetRecordsRequest
            {
                ShardIterator = getShardIteratorResponse.ShardIterator,
                Limit = 10
            };

            Amazon.Kinesis.Model.GetRecordsResponse getRecordsResponse = amazonKinesisClient.GetRecordsAsync(getRecordsRequest).Result;

            List<Amazon.Kinesis.Model.Record> records = getRecordsResponse.Records;
        }

        public static DeploymentConfig LoadDeploymentJsonConfig(string jsonFile)
        {
            DeploymentConfig config;

            using (StreamReader r = new StreamReader(jsonFile))
            {
                string json = r.ReadToEnd();

                config = JsonConvert.DeserializeObject<DeploymentConfig>(json);
            }

            return config;
        }
    }
}

//public static void DeleteDynamoDb(string transactionID)
//{
//    IAmazonDynamoDB client = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();
//    client.DeleteTableAsync(new DeleteTableRequest() { TableName = transactionID });
//}

//public static ScanResponse ScanDynamoDb(string transactionID)
//{
//    IAmazonDynamoDB client = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();
//    ScanResponse result;
//    var req = new ScanRequest
//    {
//        TableName = transactionID,
//        ProjectionExpression = "ExpectedFiles,EventTime,RelativePath"
//    };
//    result = client.ScanAsync(req).Result;
//    return result;
//}

//public static void CreateDynamoDBTable(string transactionID)
//{
//    IAmazonDynamoDB dynamoDbClient = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();

//    var response = dynamoDbClient.CreateTableAsync(new CreateTableRequest
//    {
//        TableName = transactionID,
//        ProvisionedThroughput = new ProvisionedThroughput
//        {
//            ReadCapacityUnits = 5,
//            WriteCapacityUnits = 5
//        },
//        KeySchema = new List<KeySchemaElement>
//        {
//            new KeySchemaElement
//            {
//                AttributeName = "RelativePath",
//                KeyType = KeyType.HASH
//            }
//        },
//        AttributeDefinitions = new List<AttributeDefinition>
//        {
//            new AttributeDefinition {
//                AttributeName = "RelativePath",
//                AttributeType =ScalarAttributeType.S
//            }
//        }
//    });

//    bool isTableAvailable = false;
//    while (!isTableAvailable)
//    {
//        Thread.Sleep(5000);
//        var tableStatus = dynamoDbClient.DescribeTableAsync(transactionID).Result;
//        isTableAvailable = tableStatus.Table.TableStatus == "ACTIVE";
//    }
//}

//public static void UpdateRecordInTotalTransactionFilesTable(string transactionID, string actual)
//{
//    IAmazonDynamoDB client = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();
//    string tableName = "ProductCatalog";

//    var request = new UpdateItemRequest
//    {
//        TableName = tableName,
//        Key = new Dictionary<string, AttributeValue>() { { "ID", new AttributeValue { N = transactionID } } },
//        ExpressionAttributeNames = new Dictionary<string, string>()
//        {
//            {"#A", "Authors"},
//            {"#P", "Price"},
//            {"#NA", "NewAttribute"},
//            {"#I", "ISBN"}
//        },
//        ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
//        {
//            {":ActualNumber",new AttributeValue { S = actual}}
//        },

//        // This expression does the following:
//        // 1) Adds two new authors to the list
//        // 2) Reduces the price
//        // 3) Adds a new attribute to the item
//        // 4) Removes the ISBN attribute from the item
//        UpdateExpression = "ADD #A :auth SET #P = #P - :p, #NA = :newattr REMOVE #I"
//    };
//    var response = client.UpdateItem(request);

//    PutItemResponse response = client.UpdateItemAsync("TotalNumberOfItemsPerTransactionTable", dic, dic).Result;
//}

//public static void AddMessageToSqs(string message)
//{
//    var client = ClientFactory.ClientFactory.GetSqsClient();

//    var response = client.SendMessageAsync(ClientFactory.ClientFactory.SqsUrl, message).Result;
//}

//public static int ReadAllSqsMessages(string transactionID)
//{
//    var client = ClientFactory.ClientFactory.GetSqsClient();

//    int count = 0;

//    ReceiveMessageResponse receiveMessageResponse = null;

//    do
//    {
//        var request = new ReceiveMessageRequest
//        {
//            AttributeNames = new List<string>() { "All" },
//            MaxNumberOfMessages = 10,
//            QueueUrl = ClientFactory.ClientFactory.SqsUrl
//            //VisibilityTimeout = (int)TimeSpan.FromMinutes(10).TotalSeconds,
//            //WaitTimeSeconds = (int)TimeSpan.FromSeconds(5).TotalSeconds
//        };

//        var response = client.ReceiveMessageAsync(request).Result;

//        count += response.Messages.Count(x => x.Body.Contains(transactionID));
//    }
//    while (receiveMessageResponse.Messages.Count > 0);

//    return count;
//}

//private static Lazy<ConnectionMultiplexer> lazyConnection = new Lazy<ConnectionMultiplexer>(() =>
//{
//    return ConnectionMultiplexer.Connect("gilsredis.rbpbi1.ng.0001.use2.cache.amazonaws.com:6379");
//});

//public static ConnectionMultiplexer Connection
//{
//    get
//    {
//        return lazyConnection.Value;
//    }
//}

//public static void ReadFromRedis()
//{
//    ConnectionMultiplexer redis = ConnectionMultiplexer.Connect("test-redis.rbpbi1.0001.use2.cache.amazonaws.com:6379");

//    IDatabase db = redis.GetDatabase();

//    string value = "abcdefg";

//    db.StringSet("mykey", value);

//    value = db.StringGet("mykey");

//    Console.WriteLine(value); // writes: "abcdefg"
//}

//public static void AddRecordToDynamoDb(string transactionID, string relativePath, string dateTime, string expectedFiles, string bucket)
//{
//    IAmazonDynamoDB client = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();

//    //long totalItemCount = 0;
//    //ScanResponse result;

//    //do
//    //{
//    //    ScanRequest req = new ScanRequest();

//    //    req.TableName = "Transactions";

//    //    //if (result != null)
//    //    //{
//    //    //    req.setExclusiveStartKey(result.getLastEvaluatedKey());
//    //    //}

//    //    result = client.ScanAsync(req).Result;

//    //    totalItemCount += result.Count;

//    //} while (result != null);
//    var primaryKey = string.Format("{0}-{1}", transactionID, relativePath);

//    Dictionary<string, AttributeValue> dic = new Dictionary<string, AttributeValue>();
//    dic.Add("ID", new AttributeValue(primaryKey));
//    dic.Add("RelativePath", new AttributeValue(relativePath));
//    dic.Add("DateTime", new AttributeValue(dateTime));
//    dic.Add("TransactionID", new AttributeValue(transactionID));
//    dic.Add("ExpectedFiles", new AttributeValue(expectedFiles));
//    dic.Add("Bucket", new AttributeValue(bucket));
//    //dic.Add("CurrentFiles", new AttributeValue(totalItemCount.ToString()));

//    //PutItemResponse response = client.PutItemAsync("LambdaTable", dic).Result;
//    PutItemResponse response = client.PutItemAsync("Transactions", dic).Result;
//}

//public static void GetRecordsByTransactionID(string transactionID)
//{
//    IAmazonDynamoDB client = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();

//    //QueryRequest request = new QueryRequest() {TableName= "Transactions" };

//    var request = new QueryRequest
//    {
//        TableName = "Transactions",
//        KeyConditionExpression = "TransactionID = :v_Id",
//        ExpressionAttributeValues = new Dictionary<string, AttributeValue> {
//            {":v_Id", new AttributeValue { S =  transactionID }}}
//    };

//    var response = client.QueryAsync(request).Result;
//}

//public static string FindTransactionTopicArn(string transactionID)
//{
//    var snsClient = ClientFactory.ClientFactory.GetSnsClient();

//    var listTopicsRequest = new ListTopicsRequest();

//    ListTopicsResponse listTopicsResponse;

//    do
//    {
//        listTopicsResponse = snsClient.ListTopicsAsync(listTopicsRequest).Result;

//        foreach (var topic in listTopicsResponse.Topics)
//        {
//            string topicArnPrefix = string.Format("Transaction_Topic_{0}", transactionID);

//            if (topic.TopicArn.Contains(topicArnPrefix))
//                return topic.TopicArn;
//        }

//        listTopicsRequest.NextToken = listTopicsResponse.NextToken;

//    } while (listTopicsResponse.NextToken != null);

//    return string.Empty;
//}

//string tableName = "TransactionFiles";
//Table ThreadTable = Table.LoadTable(client, tableName);
//ScanFilter scanFilter = new ScanFilter();
//scanFilter.AddCondition("TransactionID", ScanOperator.Equal, transactionID);
//Search search = ThreadTable.Scan(scanFilter);

//public static void UpdateTotalTransactionFilesTable(string transactionID, string actual, string expected)
//{
//    IAmazonDynamoDB client = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();

//    var primaryKey = transactionID;

//    Dictionary<string, AttributeValue> dic = new Dictionary<string, AttributeValue>
//                                                {
//                                                    { Constants.PRIMARY_KEY_COLUMN, new AttributeValue(primaryKey) },
//                                                    { Constants.ACTUAL_UPLOADED_FILES_NUMBER, new AttributeValue(actual) },
//                                                    { Constants.EXPECTED_UPLOADED_FILES_NUMBER, new AttributeValue(expected) }
//                                                };

//    PutItemResponse response = client.PutItemAsync(Constants.TOTAL_NUMBER_OF_FILES_PER_TRANSACTION_TABLE, dic).Result;
//}

//public static Dictionary<string, AttributeValue> GetTotalTransactionFilesTable(string transactionID)
//{
//    IAmazonDynamoDB client = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();

//    string tableName = Constants.TOTAL_NUMBER_OF_FILES_PER_TRANSACTION_TABLE;

//    var request = new GetItemRequest
//    {
//        TableName = tableName,
//        Key = new Dictionary<string, AttributeValue>() { { Constants.PRIMARY_KEY_COLUMN, new AttributeValue { S = transactionID } } },
//    };

//    var response = client.GetItemAsync(request).Result;

//    var result = response.Item;

//    return result;
//}

//public static void AddRecordToDynamoDb(string transactionID, string relativePath, string dateTime, string expectedFiles)
//{
//    IAmazonDynamoDB client = ClientFactory.ClientFactory.GetAmazonDynamoDBClient();

//    Dictionary<string, AttributeValue> dic = new Dictionary<string, AttributeValue>();

//    dic.Add(Constants.COLUMN_RELATIVE_PATH, new AttributeValue(relativePath));
//    dic.Add(Constants.COLUMN_EVENT_TIME, new AttributeValue(dateTime));
//    dic.Add(Constants.COLUMN_EXPECTED_FILES, new AttributeValue(expectedFiles));

//    PutItemResponse response = client.PutItemAsync(transactionID, dic).Result;
//}