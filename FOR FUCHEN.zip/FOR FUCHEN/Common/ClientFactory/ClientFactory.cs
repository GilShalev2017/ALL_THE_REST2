﻿using Amazon;
using Amazon.APIGateway;
using Amazon.DynamoDBv2;
using Amazon.Kinesis;
using Amazon.S3;
using Amazon.SimpleNotificationService;
using Amazon.SQS;
using Common.DTO;
using Nest;
using System;
namespace Common.ClientFactory
{
    public class ClientFactory
    {
        //TODO consider turn into an instance object and not a static

        public static IAmazonAPIGateway GetApiGatewayClient()
        {
            var amazonApiGatewayClient = new AmazonAPIGatewayClient(RegionEndpoint.GetBySystemName(AwsRegion));

            return amazonApiGatewayClient;
        }

        public static IAmazonKinesis GetKinesisClient()
        {
            var amazonKinesisClient = new AmazonKinesisClient(RegionEndpoint.GetBySystemName(AwsRegion));

            return amazonKinesisClient;
        }

        public static IAmazonSQS GetSqsClient()
        {
            var amazonSQSClient = new AmazonSQSClient(RegionEndpoint.GetBySystemName(AwsRegion));

            return amazonSQSClient;
        }

        public static IAmazonSimpleNotificationService GetSnsClient()
        {
            var snsClient = new AmazonSimpleNotificationServiceClient(RegionEndpoint.GetBySystemName(AwsRegion));

            return snsClient;
        }

        public static IElasticClient GetElasticClient()
        {
            var node = new Uri(EsHost);

            var settings = new ConnectionSettings(node);

            settings.DefaultIndex(DefaultIndex);

            settings.MapDefaultTypeNames(m => m.Add(typeof(TransactionFields), DefaultIndexType));

            var elasticClient = new ElasticClient(settings);

            return elasticClient;
        }

        public static IAmazonS3 GetS3Client()
        {
            var s3Client = new AmazonS3Client(RegionEndpoint.GetBySystemName(AwsRegion));

            return s3Client;
        }

        public static IAmazonDynamoDB GetAmazonDynamoDBClient()
        {
            var dynamoDbClient = new AmazonDynamoDBClient(RegionEndpoint.GetBySystemName(AwsRegion));

            return dynamoDbClient;
        }

        private static string _dynamoDbTable;
        public static string DynamoDbTable
        {
            get
            {
                if (string.IsNullOrEmpty(_dynamoDbTable))
                {
                    _dynamoDbTable = Environment.GetEnvironmentVariable(Constants.DYNAMO_DB_TABLE);
                }
                return _dynamoDbTable;
            }
        }

        private static string _defaultIndex;
        public static string DefaultIndex
        {
            get
            {
                if (string.IsNullOrEmpty(_defaultIndex))
                {
                    _defaultIndex = Environment.GetEnvironmentVariable(Constants.ES_INDEX);
                }
                return _defaultIndex;
            }
        }

        private static string _defaultIndexType;
        public static string DefaultIndexType
        {
            get
            {
                if (string.IsNullOrEmpty(_defaultIndexType))
                {
                    _defaultIndexType = Environment.GetEnvironmentVariable(Constants.ES_INDEX_TYPE);
                }
                return _defaultIndexType;
            }
        }

        private static string _S3Bucket;
        public static string S3Bucket
        {
            get
            {
                if (string.IsNullOrEmpty(_S3Bucket))
                {
                    _S3Bucket = Environment.GetEnvironmentVariable(Constants.S3_BUCKET);
                }
                return _S3Bucket;
            }
        }

        private static string _esHost;
        public static string EsHost
        {
            get
            {
                if (string.IsNullOrEmpty(_esHost))
                {
                    _esHost = Environment.GetEnvironmentVariable(Constants.ES_HOST);
                }
                return _esHost;
            }
        }

        private static string _awsAccountID;
        public static string AwsAccountID
        {
            get
            {
                if (string.IsNullOrEmpty(_awsAccountID))
                {
                    _awsAccountID = Environment.GetEnvironmentVariable(Constants.AWS_ACCOUNT_ID);
                }
                return _awsAccountID;
            }
        }

        private static string _awsRegion;
        public static string AwsRegion
        {
            get
            {
                if (string.IsNullOrEmpty(_awsRegion))
                {
                    _awsRegion = Environment.GetEnvironmentVariable(Constants.AWS_REGION);
                }
                return _awsRegion;
            }
        }

        private static string _kinesisDataStreamName;
        public static string KinesisDataStreamName
        {
            get
            {
                if (string.IsNullOrEmpty(_kinesisDataStreamName))
                {
                    _kinesisDataStreamName = Environment.GetEnvironmentVariable(Constants.KINESIS_DATA_STREAM_NAME);
                }
                return _kinesisDataStreamName;
            }
        }

        //private static string _awsAccessKey;
        //public static string AwsAccessKey
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(_awsAccessKey))
        //        {
        //            _awsAccessKey = Environment.GetEnvironmentVariable(Constants.AWS_ACCESS_KEY);
        //        }
        //        return _awsAccessKey;
        //    }
        //}

        //private static string _awsSecretKey;
        //public static string AwsSecretKey
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(_awsSecretKey))
        //        {
        //            _awsSecretKey = Environment.GetEnvironmentVariable(Constants.AWS_SECRET_KEY);
        //        }
        //        return _awsSecretKey;
        //    }
        //}
    }
}
//private static string _sqsUrl;
//public static string SqsUrl
//{
//    get
//    {
//        if (string.IsNullOrEmpty(_sqsUrl))
//        {
//            _sqsUrl = Environment.GetEnvironmentVariable(Constants.SQS_URL);
//        }
//        return _sqsUrl;
//    }
//}

/*
private static ElasticClient _elasticClient;

public static IElasticClient GetElasticClient()
{
    if (_elasticClient == null)
    {
        var settings = new ConnectionSettings(new Uri(EsHost))
                         .DefaultIndex(DefaultIndex)
                         .DefaultTypeName(DefaultIndexType);

        _elasticClient = new ElasticClient(settings);
    }

    return _elasticClient;
}
*/
