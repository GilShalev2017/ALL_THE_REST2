﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Transfer;
using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace S3FilesUploader
{
    class Program
    {
        private static StreamWriter _logFile;

        static void Main(string[] args)
        {
            StartLogging(args);

            var config = LoadJsonConfig(args);

            Log("\n" + "UPLOADER started..." + "\n");

            Log("BUCKET NAME = " + config.BucketName + "\n");

            Log("REGION = " + config.Region + "\n");

            UploadFilesToS3(config);

            Console.ReadLine();
        }

        private static void UploadFile(AmazonS3Client s3Client, string filePath, string bucketName, string cameraID, string effectiveFrameID)
        {
            try
            {
                var fileTransferUtility = new TransferUtility(s3Client);
               
                TransferUtilityUploadRequest request = new TransferUtilityUploadRequest
                {
                    BucketName = bucketName
                };

                var s3Filekey = new FileInfo(filePath).Name;

                fileTransferUtility.Upload(filePath, bucketName, s3Filekey);

                Console.WriteLine(string.Format("Upload {0} completed",filePath));
            }
            catch (AmazonS3Exception e)
            {
                Console.WriteLine("Error encountered on server. Message:'{0}' when writing an object", e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Unknown encountered on server. Message:'{0}' when writing an object", e.Message);
            }
        }

        private static void UploadFilesToS3(S3UploaderConfigFile config)
        {
            var watch = Stopwatch.StartNew();

            var s3Client = new AmazonS3Client(config.awsAccessKeyId, config.awsSecretAccessKey, RegionEndpoint.GetBySystemName(config.Region));

            string[] fileEntries = Directory.GetFiles(config.SourceDirectory);

            var cameraID = 1;
            var frameID = 1;

            //Parallel.ForEach(fileEntries, new ParallelOptions { MaxDegreeOfParallelism = config.ThreadsNumber }, fileName =>
            foreach (string fileName in fileEntries)
            {
                //Thread.Sleep(Convert.ToInt32(config.SleepTimeBetweenUploads));
                
                UploadFile(s3Client, fileName, config.BucketName, cameraID.ToString(), frameID.ToString());

                Interlocked.Increment(ref cameraID);

                if (cameraID == 21)
                {
                    Interlocked.Add(ref cameraID, -20);
                    Interlocked.Increment(ref frameID);
                }
            };
            //});

            watch.Stop();

            Log("=== Done uploading ===");

            Log($"Elapsed {watch.ElapsedMilliseconds / 1000} seconds");

        }

        private static S3UploaderConfigFile LoadJsonConfig(string[] args)
        {
            var configFile = args[0];

            using (StreamReader r = new StreamReader(configFile))
            {
                string json = r.ReadToEnd();

                var config = JsonConvert.DeserializeObject<S3UploaderConfigFile>(json);

                return config;
            }
        }

        private static void StartLogging(string[] args)
        {
            string logFileName = "S3FilesUploader.log";

            if (args.Length > 1)
            {
                logFileName = args[1];
            }

            try
            {
                _logFile = new StreamWriter(logFileName, false);//true=for append, false=new file
            }
            catch (Exception e)
            {
                _logFile = new StreamWriter(Console.OpenStandardOutput());
                Console.SetOut(_logFile);
                Log("Redirecting log to console; Logfile opening error :" + e.Message);
            }
            _logFile.AutoFlush = true;
        }

        private static void Log(string message)
        {
            //Write both to console & to log
            Console.WriteLine(message);

            lock (_logFile)
            {
                _logFile.WriteLine("[" + DateTime.Now.ToString() + "] " + message);
            }
        }
    }
}

//public static string CalculateMD5Hash(string input)
//{
//    // step 1, calculate MD5 hash from input
//    MD5 md5 = MD5.Create();

//    byte[] inputBytes = Encoding.ASCII.GetBytes(input);

//    byte[] hash = md5.ComputeHash(inputBytes);

//    // step 2, convert byte array to hex string
//    StringBuilder sb = new StringBuilder();

//    for (int i = 0; i < hash.Length; i++)
//    {
//        sb.Append(hash[i].ToString("x2"));
//    }

//    return sb.ToString();
//}


//for (int j = 0; j < fileEntries.Length; j++)
//{
//    PutRecordRequest putRecordRequest = new PutRecordRequest();
//    putRecordRequest.StreamName = "flink-poc-stream";

//    byte[] arr = new byte[] { 1,2,3,4,5,6,7,8,9,10,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 };

//    putRecordRequest.Data = new MemoryStream(arr) ;// (ByteBuffer.wrap(String.format("testData-%d", j).getBytes()));
//    putRecordRequest.PartitionKey = "ABC";// (String.format("partitionKey-%d", j / 5));
//    //putRecordRequest.setSequenceNumberForOrdering(sequenceNumberOfPreviousRecord);
//    PutRecordResponse putRecordResponse = amazonKinesisClient.PutRecordAsync(putRecordRequest).Result;
//    string sequenceNumber = putRecordResponse.SequenceNumber;
//}

//AmazonKinesisClientBuilder clientBuilder = AmazonKinesisClientBuilder.standard();

//clientBuilder.setRegion(regionName);
//clientBuilder.setCredentials(credentialsProvider);
//clientBuilder.setClientConfiguration(config);

//AmazonKinesis kinesisClient = clientBuilder.build();

//PutRecordsRequest putRecordsRequest = new PutRecordsRequest();
//putRecordsRequest.setStreamName(streamName);
//List<PutRecordsRequestEntry> putRecordsRequestEntryList = new ArrayList<>();
//for (int i = 0; i < 100; i++)
//{
//    PutRecordsRequestEntry putRecordsRequestEntry = new PutRecordsRequestEntry();
//    putRecordsRequestEntry.setData(ByteBuffer.wrap(String.valueOf(i).getBytes()));
//    putRecordsRequestEntry.setPartitionKey(String.format("partitionKey-%d", i));
//    putRecordsRequestEntryList.add(putRecordsRequestEntry);
//}

//putRecordsRequest.setRecords(putRecordsRequestEntryList);
//PutRecordsResult putRecordsResult = kinesisClient.putRecords(putRecordsRequest);

/*
          request.Metadata["GameID"] = gameID;

          //DateTime now = DateTime.Now;
          var assetName = string.Format("LUT_Camera_{0}", cameraID);
          var fileType = "png";
          var s3Filekey = string.Format("{0}/{1}_#_{2}.{3}",gameID, assetName, effectiveFrameID, fileType);
          fileTransferUtility.Upload(filePath, bucketName, s3Filekey);

          assetName = string.Format("Calibration_Camera_{0}", cameraID);
          fileType = "txt";
          s3Filekey = string.Format("{0}/{1}_#_{2}.{3}", gameID, assetName, effectiveFrameID, fileType);
          fileTransferUtility.Upload(filePath, bucketName, s3Filekey);

          assetName = string.Format("ClearBG_Camera_{0}", cameraID);
          fileType = "xml";
          s3Filekey = string.Format("{0}/{1}_#_{2}.{3}", gameID, assetName, effectiveFrameID, fileType);
          fileTransferUtility.Upload(filePath, bucketName, s3Filekey);

          assetName = string.Format("CalibartionBlob_Camera_{0}", cameraID);
          fileType = "txt";
          s3Filekey = string.Format("{0}/{1}_#_{2}.{3}", gameID, assetName, effectiveFrameID, fileType);
          fileTransferUtility.Upload(filePath, bucketName, s3Filekey);

          assetName = string.Format("CVT_Camera_{0}", cameraID);
          fileType = "json";
          s3Filekey = string.Format("{0}/{1}_#_{2}.{3}", gameID, assetName, effectiveFrameID, fileType);
          fileTransferUtility.Upload(filePath, bucketName, s3Filekey);

          //fileName = CalculateMD5Hash(string.Format("Camera_{0}_Lut_{1}", cameraID, now));
          //request.FilePath = filePath;
          //request.Key = gameID + "/" + fileName;
          //request.Metadata["AssetName"] = string.Format("Camera_{0}_Calibration", cameraID);
          //request.Metadata["EffectiveFrameID"] = "1";
          //request.TagSet = new System.Collections.Generic.List<Amazon.S3.Model.Tag>();
          //request.TagSet.Add(new Amazon.S3.Model.Tag { Key ="AssetName", Value = string.Format("Camera_{0}_Calibration", cameraID) });

          //fileTransferUtility.Upload(request);

          ////fileTransferUtility.Upload(filePath, bucketName, gameID + "/" + fileName);

          //fileName = CalculateMD5Hash(string.Format("Camera_{0}_Calibration_{1}", cameraID, now));

          //fileTransferUtility.Upload(filePath, bucketName, gameID + "/" + fileName);

          //fileName = CalculateMD5Hash(string.Format("Blob_{0}_Calibration_{1}", cameraID, now));

          //fileTransferUtility.Upload(filePath, bucketName, gameID + "/" + fileName);

          //fileName = CalculateMD5Hash(string.Format("Camera_{0}_ClearBG_{1}", cameraID, now));

          //fileTransferUtility.Upload(filePath, bucketName, gameID + "/" + fileName);

          //fileTransferUtility.Upload(filePath, bucketName, "ClearBG/" + new FileInfo(filePath).Name);// string.Format("{0}_{1}.bg",cameraID,frameID));// new FileInfo(filePath).Name);
          //fileTransferUtility.Upload(filePath, bucketName, "Calibration/" + new FileInfo(filePath).Name);//string.Format("{0}_{1}.cal", cameraID, frameID)); //new FileInfo(filePath).Name);
          //fileTransferUtility.Upload(filePath, bucketName, "Lut/" + new FileInfo(filePath).Name);//string.Format("{0}_{1}.lut", cameraID, frameID)); //new FileInfo(filePath).Name);
          */
